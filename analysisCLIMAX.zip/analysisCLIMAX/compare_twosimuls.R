# This script compares the skill of two or more
#    variables, of hindcasts with and without bias correction, 
#    in different terciles (ROC), for different types of 
#    hydrological hindcasts and precipitation, of detrended versus
#    undetrended data, for different hydrological models and
#    for pseudo- and real observations 
# Examples are figure 6c, 8 and 10 in Greuell et al. (2018),
#    Figures 2c, 3, 4, 5, 9b and c in Greuell et al. (2019).
# First make_verif_plots.R must be runned to generate the
#    data for the actual plot.

rm(list=ls())	#remove all the variables from the workspace
source ("../functions/ccAtPValue.R")

max_aapfd <- 999999.0

# Hier begint de input, die loopt tot ### Einde input. 
# Je kunt ver komen door alleen hier te variëren

compwhat <- "precFullInitMeteo"   # Most important parameter!
                           # Determines what will be compared
                           # See list of options below

toscreen <- F              # Output naar het scherm (T) of naar een file (F)
publication <- T           # Output voor publicatie (T) of eigen gebruik (F)
legends <- F               # Normally T but if legends should not be plotted F
domain <- "SA"
version <- "v1"
#ireg <- 1                  # Nummer van de subregio (1 = hele domein)
#regname <- "Amazonia-Guianas"
#regname <- "Southeast South America Cfa"
regname <- "South America"
#regname <- "North Chile"
title_plotted <- F

# Meestal (maar soms niet) moeten de volgende parameter ook bepaald worden
varhere <- "runoff"        # Variabele: "dis", "runoff", "evap", etc.
modhere <- "VIC"           # Can be "seas15", "LPJ", "VIC", "ecmwf_5"
forcing <- "ecmwf_5"
runhere <- "noBC"          # Can be "BC" or "noBC"
spec_run   <- c("Full")    # "noESP" (= Full Hindcasts), "ESPall", "ESPsnow", 
                           #    "ESPsoilm", "revESP", "Full"
typebasin = "allcells"     # "subcell", "largebasins" of "allcells"
obshere = "pseudo"         # "pseudo"or "real"
thr_aapfd <- max_aapfd     # Drempelwaarde voor de AAPFD
#thr_aapfd <- 0.3          # Drempelwaarde voor de AAPFD
                           # Is alleen van toepassing op discharge
                           # Voorlopig is alleen beschikbaar
                           #    0.3  voor typebasin = "largebasins"
                           #    0.05 voor typebasin = "subcell"
comp_num <- F              # vergelijk getallen van simul 1 en 2                        
stathere <- "ccmean"       # Welke domein-gemiddelde statistiek wordt geplot
                           # ccmean, percANsign, percrpssign, percccsign,  
                           # meancc, meanBNarea, meanNNarea, meanANarea,
                           # meanrpss, etc.
                           
### Einde input 

resol_str <- "halfdegree"

allstats <- c("ccmean", "percccsign", "percrpssign", "percANsign", "percBNsign",   
              "meancc",     "meanANarea",  "meanBNarea", "meanrpss")
              
if (modhere == "ecmwf_5") mod_title <- "SEAS5"

# Load data for sub-regions
# The first is the whole region                     
# Provide boundaries (N,E,S,W) of the sub-regions in coor_reg
dirlustre <- "/lustre/backup/WUR/ESG/greue002/"
dirreg <- paste (dirlustre, "CLIMAX/", domain, "/static_data/", sep = "")
filereg <- paste (dirreg, "regboundaries.rds", sep = "")
load (filereg)

# regname <- regnames[ireg]
ireg <- which (regnames == regname)
             
for (stathere in allstats) {
	
if (thr_aapfd == max_aapfd) {
   text_aapfd <- ""
} else {
   text_aapfd <- paste ("_AAPFD", thr_aapfd, sep = "")
}

# thr_aapfd moet gelijk zijn aan max_aapfd
# tenzij je bij vergelijking real met pseudo-observaties voor discharge
# een selectie wil maken beneden een bepaalde grens van AAPFD 

if (compwhat == "allESPexps") {
   if (varhere == "runoff") {
	  expall = c("ESPall", "ESPsnow", "ESPsoilm", "revESP" )
	  expall = c("Full", "Init", "Meteo" )
   } else if (varhere == "evap") {
	  expall = c("noESP", "ESPsnow", "ESPsoilm", "revESP" )
   }
   nsimuls <- length(expall)
   leadsplot = c(2,4,6) }

if (compwhat == "ESPallrev") {
   expall = c("noESP", "revESP")
   nsimuls <- length(expall)
   leadsplot = c(1,2,3) }

if (compwhat == "ESPallsnowsoilm") {
   expall = c("ESPall", "ESPsnow", "ESPsoilm")
   nsimuls <- length(expall)
   leadsplot = c(1,2,3) }

if (compwhat == "evapdetrended") {
   varall = c("evap", "evap_detr")
   nsimuls <- length(varall) 
   leadsplot = c(1,2,3) }

if (compwhat == "FullInitESP") {
   expall = c("noESP", "ESPall", "InWFDEI")
   # expall = c("ESPall", "InWFDEI")
   nsimuls <- length(expall)
   leadsplot = c(1,3,5) }

if (compwhat == "models") {
   modall = c("VIC", "LPJ")
   nsimuls <- length(modall) 
   leadsplot = c(1,2,3) }

if (compwhat == "noESP-ESPall") {
   expall = c("noESP", "ESPall")
   nsimuls <- length(expall)
   # Lead months to be plotted (1 = first lead month)
   if (obshere == "pseudo") {
	  leadsplot = c(1,2,3,5) }
   else {
	  leadsplot = c(1,3,5) }
}

if (compwhat == "noESP-specESP") {
   expall = c("noESP", "ESPsnow", "ESPsoilm", "revESP" )
   nsimuls <- length(expall)
   leadsplot = c(1,3) }

if (compwhat == "precFullInitMeteo") {
   expall = c("std", "Meteo", "Init", "Full")
   nsimuls <- length(expall)
   leadsplot = c(5)
   }

if (compwhat == "precipdetrended") {
   varall = c("precip", "precip_detr")
   nsimuls <- length(varall) 
   leadsplot = c(1,2,3,4,5) }

if (compwhat == "runoffdetrended") {
   varall = c("runoff", "runoff_detr")
   nsimuls <- length(varall) 
   leadsplot = c(1,2,3,4,5) }

if (compwhat == "shortindetrended") {
   varall = c("shortin", "shortin_detr")
   nsimuls <- length(varall) 
   leadsplot = c(1,2,3) }

if (compwhat == "tempdetrended") {
   varall = c("airtemp", "airtemp_detr")
   nsimuls <- length(varall) 
   leadsplot = c(1,2,3) }

if (compwhat == "typeobs") {
   typeobsall = c("pseudo", "real")
   nsimuls <- length(typeobsall) 
   # leadsplot = c(1,3,7) }
   leadsplot = c(1,3) }

if (compwhat == "typeROCs") {
   statall = c("percBNsign", "percANsign")
   partfileout = "percrocsignBNAN"
   # statall = c("meanBNarea", "meanANarea")
   # partfileout = "meanrocareaBNAN"
   nsimuls <- length(statall)
   leadsplot = c(1,2,3,5) }

if (compwhat == "typerun") {
   runall = c("noBC", "BC")
   nsimuls <- length(runall)
   leadsplot = c(1,2,3) }

if (compwhat == "variables") {
   # varall = c("airtemp", "potevap", "evap")
   varall = c("runoff", "dis")
   nsimuls <- length(varall) 
   leadsplot = c(1,2,3,4,5) }
               
mthnames <- c("J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D")
dirroot <- paste (dirlustre, "verif_seas/", domain, "/", sep = "")
dirinroot   <- paste (dirroot, "statdata/", sep = "")
diroutroot  <- paste (dirroot, "figures/",  sep = "")

catstr <- c("BN", "NN", "AN")

widthscreen = 7.5
widthpng = 500
rathw = 5.5 / 7.5

xlegsim = 1.5
dylegsim = 0.8
xleglead = 7.5
dyleglead = 0.8

if (compwhat == "typerun" & varhere == "airtemp") {
   dylegsim = 0.0
   dyleglead = -1.5
} else if (compwhat == "evapdetrended") {
   dylegsim = -1.7
   dyleglead = -2.5
} else if (compwhat == "tempdetrended") {
   dylegsim = -0.7
   dyleglead = -2.5
}		
	
if (compwhat == "allESPexps") {
   dirout = paste (diroutroot, varhere, "/compESPs/", sep = "")
   fileoutbase = paste (dirout, "allESPexps_", varhere, "_summary_", 
                        runhere, "_", stathere, "_", sep = "")
   titplot = paste (varhere, runhere, sep = " ")
   if (varhere == "runoff") {
	  if (stathere == "percccsign") {
	     xleglead = 7.5
         dyleglead = -6.0
         xlegsim = 0.4
         dylegsim = -4.0
      } else {
	     xleglead = 6.8
         dyleglead = 1.0
         xlegsim = 0.8
         dylegsim = -0.3
      }
   } else if (varhere == "evap") {
	  xleglead = 5.5
      dyleglead = -0.5
      xlegsim = 1.0
      dylegsim = -1.2
   }     
}

if (compwhat == "ESPallrev") {
   dirout = paste (diroutroot, varhere, "/compESPs/", sep = "")
   fileoutbase = paste (dirout, "ESPallrev_", varhere, "_summary_", 
                        runhere, "_", stathere, "_", sep = "")
   titplot = paste (varhere, runhere, sep = " ")
}

if (compwhat == "ESPallsnowsoilm") {
   dirout = paste (diroutroot, varhere, "/compESPs/", sep = "")
   fileoutbase = paste (dirout, "ESPallsnowsoilm_", varhere, "_summary_", 
                        runhere, "_", stathere, "_", sep = "")
   titplot = paste (varhere, runhere, sep = " ")
}

if (compwhat == "evapdetrended") {
   dirout = paste (diroutroot, "evap/", sep = "")
   fileoutbase = paste (dirout, "effect_detrending", modhere, "_summary_", 
                        runhere, "_", stathere, "_", sep = "")
   titplot = paste ("evap", runhere, sep = " ")
}

if (compwhat == "FullInitESP") {
   dirout = paste (diroutroot, varhere, "/compESPs/", sep = "")
   fileoutbase = paste (dirout, "FullInitESP_", varhere, "_summary_", 
                        runhere, "_", stathere, "_", sep = "")
   titplot = paste (varhere, runhere, sep = " ")
   if (varhere == "runoff") {
	  if (stathere == "percccsign") {
	     xleglead = 4.2
         dyleglead = -6.7
         xlegsim = 0.7
         dylegsim = 0.9
      } else {
	     xleglead = 6.8
         dyleglead = 1.0
         xlegsim = 0.8
         dylegsim = -0.3
      }
   } else if (varhere == "evap") {
	  xleglead = 5.5
      dyleglead = -0.5
      xlegsim = 1.0
      dylegsim = -1.2
   }     
}

if (compwhat == "models") {
   dirout = paste (diroutroot, varhere, "/compmodels/", sep = "")
   fileoutbase = paste (dirout, "compmodels_", varhere, "_summary_", 
                        runhere, "_", stathere, "_", typebasin, 
                        "_", obshere, "_", sep = "")
   titplot = paste (varhere, runhere, typebasin, obshere, sep = " ")
}

if (compwhat == "noESP-ESPall") {
   dirout = paste (diroutroot, varhere, "/compESPs/", sep = "")
   fileoutbase = paste (dirout, "noESPvsESPall_", varhere, "_summary_", 
                        runhere, "_", stathere, "_", 
                        obshere, "_", typebasin, text_aapfd, "_", sep = "")
   titplot = paste (varhere, runhere, obshere, typebasin, sep = " ")
   if (stathere == "percccsign") {
	  xleglead = 4.0
      dyleglead = -6.0
      xlegsim = 0.8
      dylegsim = -7.7
   } else {
	  xleglead = 6.8
      dyleglead = 1.0
      xlegsim = 0.8
      dylegsim = -0.3
   }

}

if (compwhat == "noESP-specESP") {
   dirout = paste (diroutroot, varhere, "/compESPs/", sep = "")
   fileoutbase = paste (dirout, "noESP-specESP_", varhere, "_summary_", 
                        runhere, "_", stathere, "_", sep = "")
   titplot = paste (varhere, runhere, sep = " ")
}

if (compwhat == "precipdetrended") {
   dirout = paste (diroutroot, "precip/", sep = "")
   fileoutbase = paste (dirout, "effect_detrending", modhere, "_summary_", 
                        runhere, "_", stathere, "_", sep = "")
   titplot = paste ("Precipitation", mod_title, regname, sep = "  ")
}

if (compwhat == "precFullInitMeteo") {
   dirout = paste (diroutroot, varhere, "/compESPs/", sep = "")
   fileoutbase = paste (dirout, "precip_Full_Init_Meteo", modhere, 
                        "_summary_", runhere, "_", stathere, "_", 
                        regname, sep = "")
   titplot = paste ("Prec and SpecHC", regname, sep = "  ")
}

if (compwhat == "runoffdetrended") {
   dirout = paste (diroutroot, "runoff/", sep = "")
   # fileoutbase = paste (dirout, "compvariables_", modhere, "_summary_", 
   #                      runhere, "_", stathere, "_", sep = "")
   # fileoutbase = paste (dirout, "comptemppotevap_", modhere, "_summary_", 
   #                      runhere, "_", stathere, "_", sep = "")
   # titplot = paste ("T, potET and ET", runhere, sep = " ")
   fileoutbase = paste (dirout, "effect_detrending", modhere, "_summary_", 
                        runhere, "_", stathere, "_", sep = "")
   titplot = paste ("runoff", runhere, sep = " ")
}

if (compwhat == "shortindetrended") {
   dirout = paste (diroutroot, "shortin/", sep = "")
   fileoutbase = paste (dirout, "effect_detrending", modhere, "_summary_", 
                        runhere, "_", stathere, "_", sep = "")
   titplot = paste ("shortin", runhere, sep = " ")
}

if (compwhat == "tempdetrended") {
   dirout = paste (diroutroot, "airtemp/", sep = "")
   fileoutbase = paste (dirout, "effect_detrending", modhere, "_summary_", 
                        runhere, "_", stathere, "_", sep = "")
   titplot = paste ("airtemp", runhere, sep = " ")
}

if (compwhat == "typeobs") {
   dirout = paste (diroutroot, varhere, "/comptypeobs/", sep = "")
   fileoutbase = paste (dirout, "comptypeobs_", varhere, "_summary_", 
                        modhere, "_", runhere, "_", typebasin, "_",
                        stathere, text_aapfd, "_", sep = "")
   titplot = paste (varhere, modhere, runhere, typebasin, text_aapfd, sep = " ")
   if (typebasin == "largebasins") {
	  xlegsim = 1.5
      dylegsim = -0.5
      xleglead = 8.5
      dyleglead = -1.0}
   if (typebasin == "subcell") {
	  xlegsim = 1.5
      dylegsim = -1.5
      xleglead = 6.5
      dyleglead = -3.5}
}

if (compwhat == "typeROCs") {
   dirout = paste (diroutroot, varhere, "/compstats/", sep = "")
   fileoutbase = paste (dirout, partfileout, "_", varhere, "_summary_", 
                        runhere, "_", typebasin, 
                        "_", obshere, "_", sep = "")
   titplot = paste (varhere, runhere, typebasin, obshere, sep = " ")
}

if (compwhat == "typerun") {
   dirout = paste (diroutroot, varhere, "/comptyperun/", sep = "")
   fileoutbase = paste (dirout, "comptyperun_", varhere, "_summary_", 
                        modhere, "_", stathere, "_", sep = "")
   titplot = paste (varhere, sep = " ")
}

if (compwhat == "variables") {
   dirout = paste (diroutroot, "compvariables/", sep = "")
   # fileoutbase = paste (dirout, "compvariables_", modhere, "_summary_", 
   #                      runhere, "_", stathere, "_", sep = "")
   # fileoutbase = paste (dirout, "comptemppotevap_", modhere, "_summary_", 
   #                      runhere, "_", stathere, "_", sep = "")
   # titplot = paste ("T, potET and ET", runhere, sep = " ")
   fileoutbase = paste (dirout, "comprunoffdis_", modhere, "_summary_", 
                        runhere, "_", stathere, "_", sep = "")
   titplot = paste ("runoff and dis", runhere, sep = " ")
}

if (publication) titplot <- " "

if (publication) { titpubl <- "_publ"
} else { titpubl <- "_nopubl" }

system (paste ("mkdir -p ", dirout, sep = ""))

fileout = paste (fileoutbase, titpubl, ".png", sep = "")

if (toscreen) {
   dev.new (width = widthscreen, height = rathw * widthscreen)
} else {
   png (file = fileout, width = widthpng, height = rathw * widthpng,
	    pointsize =12, bg = "white")}
	    
colsimul = c("blue", "purple", "orange", "red")

legsimul = vector ("character", nsimuls)

for (simul in (1:nsimuls)) {

   modfile <- modhere      
      	
   if (compwhat == "allESPexps") {
	  spec_run = expall[simul]
	  legsimul = spec_run
   }

   if (compwhat == "ESPallrev") {
	  spec_run = expall[simul]
	  legsimul = spec_run
   }

   if (compwhat == "ESPallsnowsoilm") {
	  spec_run = expall[simul]
	  legsimul = spec_run
   }

   if (compwhat == "evapdetrended") {
	  varhere = varall[simul]
	  runhere = "BC"
	  if (simul == 1) {
		 legsimul <- "no detrending"
	  } else if (simul == 2) {
		 legsimul <- "with detrending"
      }
   }

   if (compwhat == "FullInitESP") {
	  spec_run = expall[simul]
	  legsimul = spec_run
   }

   if (compwhat == "models") {
	  modhere = modall[simul]
	  legsimul = modhere
   }

   if (compwhat == "noESP-ESPall") {
	  spec_run = expall[simul]
	  legsimul = spec_run
   }

   if (compwhat == "noESP-specESP") {
	  spec_run = expall[simul]
	  legsimul = spec_run
   }

   if (compwhat == "precFullInitMeteo") {
	  spec_run <- expall[simul]
	  if (spec_run == "std") {
		 varhere <- "precip"
		 modfile <- "ecmwf_5"
	     legsimul <- varhere
	  } else {
		 varhere <- "runoff"
	     legsimul <- spec_run
	  }
   }

   if (compwhat == "precipdetrended") {
	  varhere = varall[simul]
	  runhere = "noBC"
	  legsimul = varhere
   }

   if (compwhat == "runoffdetrended") {
	  varhere = varall[simul]
	  runhere = "BC"
	  legsimul = varhere
   }

   if (compwhat == "shortindetrended") {
	  varhere = varall[simul]
	  runhere = "BC"
	  if (simul == 1) {
		 legsimul <- "no detrending"
	  } else if (simul == 2) {
		 legsimul <- "with detrending"
      }
   }

   if (compwhat == "tempdetrended") {
	  varhere = varall[simul]
	  runhere = "BC"
	  if (simul == 1) {
		 legsimul <- "no detrending"
	  } else if (simul == 2) {
		 legsimul <- "with detrending"
      }
   }

   if (compwhat == "typerun") {
	  runhere = runall[simul]
	  legsimul = runhere
   }

   if (compwhat == "typeobs") {
	  obshere = typeobsall[simul]
	  legsimul = obshere
   }

   if (compwhat == "typeROCs") {
	  stathere = statall[simul]
	  if (stathere == "percBNsign" | stathere == "meanBNarea") legsimul = "BN"
	  if (stathere == "percNNsign" | stathere == "meanNNarea") legsimul = "NN"
	  if (stathere == "percANsign" | stathere == "meanANarea") legsimul = "AN"
   }
   if (compwhat == "variables") {
	  varhere = varall[simul]
	  #runhere = "empty"
	  #if (varhere == "airtemp") runhere = "noBC"
	  #if (varhere == "dis") runhere = "BC"
	  #if (varhere == "evap") runhere = "BC"
	  #if (varhere == "potevap") runhere = "BC"
	  #if (varhere == "runoff") runhere = "BC"
	  legsimul = varhere
   }
   
   if (legsimul == "noESP")    legsimul = "FullSH"
   if (legsimul == "ESPall")   legsimul = "InitSH"
   if (legsimul == "ESPsoilm") legsimul = "SMInitSH"
   if (legsimul == "ESPsnow")  legsimul = "SnInitSH"
   if (legsimul == "revESP")   legsimul = "MeteoSH"
   if (legsimul == "InWFDEI")  legsimul = "ESP"
   
   expfile = ""
   if (spec_run != "noESP") expfile = paste (spec_run, "_", sep = "")

   statfile <- stathere
   if (stathere == "percBNsign") {
	  statfile <- "percrocsign"
	  indroc <- 1}
   else if (stathere == "percNNsign") {
	  statfile <- "percrocsign"
	  indroc <- 2}
   else if (stathere == "percANsign") {
	  statfile <- "percrocsign"
	  indroc <- 3}
   else if (stathere == "meanBNarea") {
	  statfile <- "meanrocarea"
	  indroc <- 1}
   else if (stathere == "meanNNarea") {
	  statfile <- "meanrocarea"
	  indroc <- 2}
   else if (stathere == "meanANarea") {
	  statfile <- "meanrocarea"
	  indroc <- 3}

   # Als de forcering van speciale hindcasts uit WFDEI data bestaat,
   #    dan is forcering nooit voor bias gecorrigeerd.	  		
   runfilenm <- runhere
   if (spec_run == "InWFDEI") runfilenm <- "noBC"

   if (varhere == "airtemp")   type_data <- "meteo"   
   if (varhere == "evap")      type_data <- "hydro"   
   if (varhere == "dis")       type_data <- "hydro"   
   if (varhere == "precip")    type_data <- "meteo"   
   if (varhere == "qs")        type_data <- "hydro"   
   if (varhere == "qsb")       type_data <- "hydro"   
   if (varhere == "runoff")    type_data <- "hydro"   
   if (varhere == "shortin")   type_data <- "meteo"   
   if (varhere == "soilmoist") type_data <- "hydro"   
   if (varhere == "swe")       type_data <- "hydro"   
   
   dirinbase <- paste (dirinroot, varhere, "/", modfile, "/", forcing, "/", sep = "")
   if (type_data == "meteo") {                  
      dirin <- paste (dirinbase, resol_str, "_", runhere, "/", sep = "")
   } else if (type_data == "hydro") {
      dirin <- paste (dirinbase, resol_str, "_", spec_run, "_SH_", runhere, "_", 
                      version, "/", sep = "")
   }                    

   if (varhere != "dis") {filein = paste (dirin, statfile, "_", modfile,
	                      "_", expfile, runfilenm, "_", 
	                      varhere, ".txt", sep = "")}
   else {filein = paste (dirin, statfile, "_", modfile, 
	                     "_", expfile, runfilenm, "_", varhere, "_", 
	                     obshere, "_obs_",
	                     typebasin, text_aapfd, ".txt", sep = "")}
   print (filein)
   fileex <- file.exists (filein)
   # if (fileex == F) next
   load (file = filein)

   if (stathere == "ccmean") {
      varplot = cc_mean_arr
      ytit = "Correlation coefficient"
      limyaxis = c(-0.1, 1.0)
      noskill <- ccAtPValue (nYearSyn, 0.05, one_sided = T)
      zeroline = 0.0
   } 
   if (stathere == "meancc") {
      varplot = mean_cc_arr
      ytit = "Domain mean correlation coefficient"
      limyaxis = c(-0.1, 1.0)
      noskill <- ccAtPValue (nYearSyn, 0.05, one_sided = T)
      zeroline = 0.0
   } 
   else if (stathere == "meanBNarea" | stathere == "meanNNarea" | stathere == "meanANarea") {
      varplot = mean_area_arr[indroc,,,]
      ytit = "Domain mean ROC area"
      limyaxis = c(0.4, 1.0)
      noskill = 0.686 
      zeroline = 0.5 
   } 
   else if (stathere == "meanrpss") {
      varplot = mean_rpss_arr
      ytit = "Domain mean Ranked PSS" 
      limyaxis = c(-0.2, 1.0)
      noskill = -999.0  
      zeroline = 0.0 
   } 
   else if (stathere == "percccsign") {
      varplot = perc_cc_sign
      ytit = "Cells with significant R (%)"
      limyaxis = c(0.0, 100.0)
      noskill = 5.0  
      zeroline = -999.0 
   } 
   else if (stathere == "percBNsign" | stathere == "percNNsign" | stathere == "percANsign") {
      varplot = perc_roc_sign[indroc,,,]
      ytit = "Cells with significant ROC (%)"
      limyaxis = c(0.0, 100.0)
      noskill = 5.0  
      zeroline = -999.0 
   } 
   else if (stathere == "percrpssign") {
      varplot = perc_rps_sign
      ytit = "Cells with significant RPSS (%)"
      limyaxis = c(0.0, 100.0)
      noskill = 5.0  
      zeroline = -999.0 
   }

   # The anchors of the y-legends are limyaxis[2]
   yleganchsim  <- limyaxis[2]    
   yleganchlead <- limyaxis[2]    
   if (compwhat == "precFullInitMeteo") {
      if (stathere == "ccmean") {
         if (regname == "North Amazonia") {
		    xlegsim <- 3.5
         } else if (regname == "North Chile") {
		    yleganchsim <- 0.75
		    xleglead <- 5.0
		 }
      } else if (stathere == "percccsign") {
 		 xlegsim <- 3.5
 		 yleganchsim <- 0.75
		 xleglead <- 5.0
	  }
   }
   
   # Vergelijk getallen 
   if (comp_num) {
	  if (simul == 1) {varplot1 <- varplot
      } else if (simul == 2) {
		   varplot2 <- varplot
		   vardiff <- varplot2 - varplot1
		   print (vardiff)
		   stop ("hgj")
	  }
   }
     
   dimplot <- dim(varplot)
   nmth = dimplot[1]
   nlead = dimplot[2]
   mreg <- dimplot[3]

   # Voor tekst Sectie 3.2.2.   
   if (compwhat == "precFullInitMeteo") {
      meanFigSect322 <- mean (varplot [ , (2:nlead), 1])
      print (paste (spec_run, meanFigSect322, sep = "   "))
   }
   
   if (mreg != nreg) stop ("nreg and mreg are not equal")
      
   totnummth = nmth 
   limxaxis = c(0.8, totnummth + 0.2)
   all_xplot = seq(1, totnummth, length.out = totnummth)
   
   par (cex.lab = 1.3)
   par (mar = c(3, 6, 4, 2))
   par (lwd = 2.5)
   
   rangey = limyaxis[2] - limyaxis[1] 
   ilead = 0 
   linetype = 0 
   for (lead in leadsplot) {
	  ilead = ilead + 1
      varlead = varplot[ , lead, ireg]
	  if (lead > 1) varlead = c(varlead[(nmth-lead+2):nmth], varlead[1:(nmth-lead+1)])
      xplot = seq(1, nmth, length.out = nmth)
      par (lty = lead + 1)
      linetype = linetype + 1
	  if (compwhat == "noESP-ESPall" & obshere == "real" & ilead == 2) 
		 linetype = linetype + 1
      if (lead == leadsplot[1] & simul == 1) {
         plot  (xplot, varlead, ylab = ytit, xaxt = "n", xlab = "", 
                type = "b", xlim = limxaxis, xaxs = "i",
	            ylim = limyaxis, yaxs = "i", col = colsimul[simul],
    	        lty = linetype)
    	        # main = titplot, lty = linetype)
		 if (title_plotted) title (titplot, line = 1.0, cex.main = 1.3)
         axis (at = all_xplot, labels = mthnames[1:nmth], side = 1)} 
	  else {
		 lines (xplot, varlead, type = "b", lty = linetype, col = colsimul[simul])
      }
      print (paste (lead, simul, mean(varlead), sep = "   ")) 

      if (legends) {
	     # De legenda voor de lead month
	     par (cex = 1.3)
	     if (simul == 1) {
	        yleg = yleganchlead - (ilead - dyleglead) / 12.0 * rangey
	        tleg = paste ("lead month ", round (lead - 1), sep = "")
		    legend (xleglead, yleg, tleg, lty = linetype, 
		            bty = "n", col = "black")
         }

	     # De legenda voor simulatie / variabele
	     if (ilead == 1) { 
	        yleg = yleganchsim - (simul - dylegsim) / 12.0 * rangey
	        tleg = paste (legsimul)
	        if (compwhat == "allESPexps" | compwhat == "FullInitSH") {
			   legend (xlegsim, yleg, tleg, lty = linetype, bty = "n", 
	                   text.col = colsimul[simul], col = colsimul[simul],
	                   seg.len = 1.0)
	        } else {
			   legend (xlegsim, yleg, tleg, lty = linetype, bty = "n", 
	                   text.col = colsimul[simul], col = colsimul[simul])
	        }
	     }
	  }
	  
   }  

   if (simul == 1) {
	  par (lty = 1)
      abline (h = noskill, lwd = 3.0) 
      abline (h = zeroline, col = "grey", lwd = 1.5)
   }
      
} # Einde loop over de simulaties

if (toscreen) {
   print ("Enter something to continue")
   entval <- scan (file = "", what = "", nmax = 1) }

dev.off ()
   
} # Einde van de loop over de verschillende metrics

      
     	
