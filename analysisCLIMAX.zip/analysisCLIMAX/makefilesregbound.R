rm(list=ls())	#remove all the variables from the workspace

   domain <- "SA"
   
   if (domain == "SA") {
      westb  = -83.5
      eastb  = -32.5
      southb = -58.0
      northb =  14.5
	  regnames <- c ("South America", "coast Ecuador", "coast North Peru",
                     "Northwest Columbia", "North Chile", "Mid Chile", 
                     "Patagonia", "Southeast South America Aw",
                     "Southeast South America Cfa", "Amazonia-Guianas", 
                     "rio Paraná", "rio São Francisco",
                     "Northeast Brazil", "Caatinga")
   }

   nreg <- length (regnames)
   # Boundaries of sub-regions: north, east, south, west
   coor_reg <- array (0, dim = c (4, nreg))
   coor_reg[ , 1] <- c (northb, eastb, southb, westb)    # whole domain
   
   if (domain == "SA") {
      coor_reg[ , 2] <- c (  1.0, -79.0,  -4.5, -81.0)   # coast Ecuador
      coor_reg[ , 3] <- c ( -4.5, -79.0,  -7.0, -81.0)   # coast North Peru
      coor_reg[ , 4] <- c ( 12.5, -73.0,   5.0, -76.0)   # NW Colombia
      coor_reg[ , 5] <- c (-25.0, -69.5, -31.0, -72.0)   # N Chile
      coor_reg[ , 6] <- c (-31.0, -69.5, -34.0, -72.0)   # Mid Chile
      coor_reg[ , 7] <- c (-40.5, -63.5, -49.0, -69.5)   # Patagonia
      coor_reg[ , 8] <- c (-22.0, -49.5, -23.5, -59.0)   # SESA Aw
      coor_reg[ , 9] <- c (-23.5, -49.5, -31.5, -59.0)   # SESA Cfa
      coor_reg[ ,10] <- c (  9.5, -53.5,  -4.0, -65.0)   # Amazonia-Guianas
      coor_reg[ ,11] <- c (-19.0, -51.0, -25.0, -55.0)   # rio Paraná
      coor_reg[ ,12] <- c (-15.0, -44.0, -21.0, -47.0)   # rio São Francisco
      coor_reg[ ,13] <- c ( -0.5, -35.0,  -7.0, -50.0)   # NE Brazil
      coor_reg[ ,14] <- c ( -5.0, -35.5,  -9.0, -42.0)   # Caatinga
   }

   dirlustre <- "/lustre/backup/WUR/ESG/greue002/"

   dirout   <- paste (dirlustre, "CLIMAX/", domain, "/static_data/", sep = "")

   # create .rds file
   Rfileout <- paste (dirout, "regboundaries.rds", sep = "")
   save (northb, eastb, southb, westb, regnames, nreg, coor_reg, file = Rfileout)
   
   # create .txt file to be read by bash scripts
   txtfileout <- paste (dirout, "regboundaries.txt", sep = "")
   cat (paste (nreg), file = txtfileout, append = F, sep = "\n")
   for (ireg in (1:nreg)) {
	   reg_name <- gsub (' ', '_', regnames[ireg])
	   text_reg <- paste (reg_name)
       cat (text_reg, file = txtfileout, append = T, sep = "\n")
       for (idir in (1:4)) {
          cat (paste (coor_reg[idir,ireg]), file = txtfileout, 
               append = T, sep = "\n")
       }
   }  
   
   
   
       
   
