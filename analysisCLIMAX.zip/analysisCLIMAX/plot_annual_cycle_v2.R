# Dit script plot de jaarlijkse cyclus van hydrologische variabelen
#    voor de referentierun voor deelgebieden

rm(list=ls())	#remove all the variables from the workspace

library (ncdf4)

typedata    <- "hydroflux"      # hydroflux, soilmoist or meteo         
domain      <- "SA"
hydmodel    <- "VIC"            # ecmwf_5 voor SEAS5
forcing     <- "WFDEI"
forc_vers   <- "aug2018"
str_resol   <- "halfdegree"
spec_run    <- "std"           
version     <- "v1"
begyear     <- 1981
endyear     <- 2015
toscreen    <- T
plot_legend <- T
plot_title  <- F

dirlustre <- "/lustre/backup/WUR/ESG/greue002/"
dirdomain <- paste (dirlustre, "CLIMAX/", domain, "/", sep = "")
dirclimhyd <- paste (dirdomain, hydmodel, "/", forcing, "_", forc_vers, "/", 
              str_resol, "_", spec_run, "_SREF_noBC_", version, 
              "/climate/", sep = "")
dirfigs <- paste (dirclimhyd, "figures/", sep = "") 
system (paste ("mkdir -p ", dirfigs, sep = ""))
                             
nmth <- 12
mthnames <- c ("J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D")
ndaymth <- c (31, (28 + 8/35), 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
# Compute the length in days between the middle of the 12 months
#    This is used to compute change in soil moisture in mm/d
dmidmth <- vector (mode = "double", length = nmth)
for (imth in (1:nmth)) {
   if (imth == 1) {
	  dmidmth[imth] <- 0.5 * (ndaymth[imth] + ndaymth[nmth])
   } else {
	  dmidmth[imth] <- 0.5 * (ndaymth[imth] + ndaymth[(imth-1)])
   }
}

# Load data for sub-regions
# The first is the whole region                     
# Provide boundaries (N,E,S,W) of the sub-regions in coor_reg
dirreg <- paste (dirlustre, "CLIMAX/", domain, "/static_data/", sep = "")
filereg <- paste (dirreg, "regboundaries.rds", sep = "")
load (filereg)

xplotlab <- seq(1, nmth, length.out = nmth)
if (typedata == "soilmoist") {
   xplot <- seq(0.5, (nmth+0.5), length.out = (nmth+1))
} else {
   xplot <- xplotlab
}
xlegplot <- 1.0

if (typedata == "hydroflux") {
   #vars <- c ("prec", "evap", "qs", "qsb", "runoff")
   vars <- c ("prec", "evap", "net_prec", "runoff")
} else if (typedata == "soilmoist") {
   vars <- c ("soilmoist")
}

nvar <- length (vars)
if (typedata == "hydroflux") {
   nvarall <- nvar   
   varsall <- vars
} else if (typedata == "soilmoist") {
   nvarall <- 3
   varsall <- c ("dSM1", "dSM2", "dSM3")
}    	
allvar <- array (NA, dim = c (nvarall, nmth))

if (typedata == "meteo") {
   dirdata <- paste (dirdomain, "forcing/", forcing, "_", 
                     forc_vers, "/", str_resol, "_noBC_climate/data/",
                     sep = "") 
} else if (typedata == "hydroflux" | typedata == "soilmoist") {
   dirdata <- paste (dirclimhyd, "data/", sep = "") 
} 

for (regname in regnames) {

   reg_name <- gsub (" ", "_", regname)
   
   # Read the data	
   ivar <- 0

   for (var in vars) {

      ivar <- ivar + 1

      if (var != "net_prec") {      	   
         filedata <- paste (dirdata, var, "_ymonavg_", begyear, "-", 
                            endyear, "_", reg_name, "_mean.nc", sep = "")
         ncdata <- nc_open (filedata)
         varread <- ncvar_get (ncdata, varid = var)
         nc_close (ncdata)
      }
      
      if (typedata == "hydroflux" & var != "net_prec") {
		 allvar [ivar, ] <- varread      
         if      (var == "prec")   { prec   <- varread }
         else if (var == "evap")   { evap   <- varread }
         else if (var == "runoff") { runoff <- varread }
      } else if (typedata == "soilmoist") {
		 for (imth in (1:nmth)) {
			if (imth == 1) {
			   allvar[ , imth] <- (varread[ , imth] - varread[ , nmth]) / 
			                      dmidmth[imth]
			} else {
			   allvar[ , imth] <- (varread[ , imth] - varread[ , (imth-1)]) /
			                      dmidmth[imth]
			}
	     }
	  }
	  
   }
   
   if (typedata == "hydroflux") {
      allvar [(nvarall-1), ] <- prec - evap
      mthbal <- prec - evap - runoff
      annbal <- sum (ndaymth * mthbal) 
      annprec <- sum (ndaymth * prec) 
      print (regname)   
      print (annbal)
      print (annprec)
   }

   maxallvar <- max (allvar)  
   minallvar <- min (allvar)
   rangey <- maxallvar - minallvar
   ylegplot <- maxallvar - 0.1 * rangey
   dylegplot <- 0.08 * rangey 

   rathw = 5.5 / 6.5
   if (toscreen) {
      widthscreen = 7.5
      dev.new (width = widthscreen, height = rathw * widthscreen) 
   } else {
	  filefigs <- paste (dirfigs, typedata, "_", reg_name, 
	                     ".png", sep = "")
      widthpng = 500
 	  png (file = filefigs, width = widthpng, height = rathw * widthpng,
		      pointsize =12, bg = "white")
   }

   if (typedata == "hydroflux") {
	  ytitle <- "Flux (mm/d)" 
   } else if (typedata == "soilmoist") {
	  ytitle <- "Change in soil moisture (mm/d)"
   }
   
   if (plot_title) {
	  title <- regname
   } else {
	  title <- ""
   }

   plot (1, type = "n", ylab = ytitle, xaxt = "n", xlab = "", 
		 xlim = c (0.5, 12.5), xaxs = "i", main = title, 
		 ylim = c (minallvar, maxallvar), cex.lab = 1.3,
		 mgp = c(2.5, 1, 0), cex.main = 1.3)
   axis (at = xplotlab, labels = mthnames, side = 1) 
   
   for (ivar in (1:nvarall)) {

      textleg <- varsall[ivar]	   
	  if      (varsall[ivar] == "prec")     { 
		 colorvar <- "purple"
		 textleg  <- "precip" } 
	  else if (varsall[ivar] == "evap")     { 
		 colorvar <- "red" 
		 textleg  <- "evaptr" } 
	  else if (varsall[ivar] == "runoff")   { 
		 colorvar <- "blue" }
	  else if (varsall[ivar] == "qs")       {
	     colorvar <- "lightblue" 
		 textleg  <- "surface ro" } 
	  else if (varsall[ivar] == "qsb")      { 
		 colorvar <- "purple" 
		 textleg  <- "basal ro" } 
	  else if (varsall[ivar] == "net_prec") { 
		 colorvar <- "black" 
		 textleg  <- "net precip" } 
	  else if (varsall[ivar] == "dSM1")     { 
		 colorvar <- "black" 
		 textleg  <- "change in SM1" } 
	  else if (varsall[ivar] == "dSM2")     { 
		 colorvar <- "red" 
		 textleg  <- "change in SM2" } 
	  else if (varsall[ivar] == "dSM3")     { 
		 colorvar <- "blue" 
		 textleg  <- "change in SM3" } 
		  
      varhere <- allvar [ivar, ]
      if (typedata == "soilmoist") varhere <- c (varhere, varhere[1])
      lines (xplot, varhere, type = "b", lwd = 3, col = colorvar)
      if (plot_legend) {
         yleghere <- ylegplot - (ivar - 1) * dylegplot
         legend (xlegplot, yleghere, textleg, cex = 1.3, col = colorvar, 
                 lty = 1, lwd = 3, bty = "n")
      }       
   }

   abline (h = 0.0, lwd = 1.0) 
       	
   if (toscreen) {
      print ("Enter something to continue")
      entval <- scan (file = "", what = "", nmax = 1) }

   dev.off ()
          
}

