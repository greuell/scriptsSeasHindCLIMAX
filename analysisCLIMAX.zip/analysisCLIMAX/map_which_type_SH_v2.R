# Dit programma maakt een kaart met voor elke cel 
# of deze onvoldoende skill heeft
# of kennis van initiele condities voldoet
# of kennis van de forcering voldoet

rm(list=ls())	#remove all the variables from the workspace

library (fields)
library (RColorBrewer)
library (ncdf4)
library (psych)

domain <- "SA"
var <- "dis"                 # runoff, precip, evap, qs, qsb, airtemp, dis
hydmodel <- "VIC"            # ecmwf_5 voor SEAS5
metric <- "cc"               # cc, area_roc_AN area_roc_BN area_roc_NN or rps 
biascorr <- "noBC"
forcing <- "ecmwf_5"
str_resol <- "halfdegree"
version <- "v1"
typeobs <- "pseudo_obs"      # has only effect for dis (real_obs or pseudo_obs)
 
toscreen <- F

# values in bar
# 4: less than thr_frac_skill of the cases in the FullSH has significant skill
# 1: other cases
# 3: 1 but in at least thr_frac_restr_e of the cases the MeteoSH are not worse than
#    FullSH
# 6: 1 but in at least thr_frac_restr_b of the cases the MeteoSH are not worse than
#    FullSH
# 2: 1 but in at least thr_frac_restr_e of the cases the InitSH are not worse than
#    FullSH
# 5: 1 but in at least thr_frac_restr_b of the cases the InitSH are not worse than
#    FullSH
thr_frac_skill   <- 0.4
thr_frac_restr_e <- 0.75
thr_frac_restr_b <- 0.3

# End of setting variable variables

dirlustre <- "/lustre/backup/WUR/ESG/greue002/"
dirstatsbase <- paste ("verif_seas/", domain, "/statdata/", var, "/",
                       hydmodel, "/", forcing, "/", sep = "")
dirout <- paste (dirlustre, "verif_seas/", domain, 
                 "/figures/annmeanskill/", var, "/",
                 hydmodel, "/", forcing, "/", sep = "")

# Load the data for the different specific hindcasts
spec_runs <- c ("Full", "Init", "Meteo")
nSH <- length (spec_runs)
iFull  <- which (spec_runs == "Full")
iInit  <- which (spec_runs == "Init")
iMeteo <- which (spec_runs == "Meteo")

for (iSH in (1:nSH)) {                                        

   spec_run <- spec_runs[iSH]   
   dirstats <- paste (dirstatsbase, str_resol, "_", spec_run, "_SH_", 
                      biascorr, "_", version, "/", sep = "")

   if (var != "dis") {
      exttypeobs <- ""
   } else {
      exttypeobs <- paste ("_", typeobs, "_allcells", sep = "")
   }

   # Load the data of the metric
   filemetrin <- paste (dirlustre, dirstats, metric, "_", hydmodel,
                 "_", spec_run, "_", biascorr, "_", var, exttypeobs, 
                 ".txt", sep = "")
   load (file = filemetrin)
   
   # Load the p-value of the metric   
   filepvaluein <- paste (dirlustre, dirstats, "p_", metric, "_", hydmodel,
                 "_", spec_run, "_", biascorr, "_", var, exttypeobs, 
                 ".txt", sep = "")
   load (file = filepvaluein)

   # For calculating whether the metrics for the different SH differ,
   #    the original data from which the metric have been computed
   #    must be loaded. Their mutual dependence (correlation coefficient)
   #    must be computed. 
   if (metric == "cc") {
	   # Begin with the observations
	   fileobs <- paste (dirlustre, dirstats, "obsall_", hydmodel,
                         "_", spec_run, "_", biascorr, "_", var, exttypeobs, 
                         ".txt", sep = "")
       load (file = fileobs)
	   # Read the hindcasts
	   filehind <- paste (dirlustre, dirstats, "hindall_", hydmodel,
                         "_", spec_run, "_", biascorr, "_", var, exttypeobs, 
                         ".txt", sep = "")
       load (file = filehind)
	  
	   read_metric <- corr_coeff_all
	   read_pvalue <- pvalue_cc_all
	   
   }
       
   if (spec_run == spec_runs[1]) {	   

	  dimarr <- dim (read_metric)
      nlat  <- dimarr[1]
      nlon  <- dimarr[2]
      nmth  <- dimarr[3]
      nlead <- dimarr[4]
      metric_allSH <- array (NA, dim = c(dimarr, nSH))
      pvalue_allSH <- array (NA, dim = c(dimarr, nSH))

      # The number of years in the loaded arrays is needed to determine
      #    whether skill is significant and to determine the size of new arrays
      fileccmean <- paste (dirlustre, dirstats, "ccmean_", hydmodel, 
                           "_", spec_run, "_", biascorr, "_", var, exttypeobs, 
                           ".txt", sep = "")
      load (file = fileccmean)
      nyear <- nYearSyn

      hind_allSH   <- array (NA, dim = c(nlat, nlon, nyear, nmth, nlead, nSH)) 
   }

   metric_allSH [ , , , ,   iSH] <- read_metric   
   pvalue_allSH [ , , , ,   iSH] <- read_pvalue   
   hind_allSH   [ , , , , , iSH] <- all_medianhind   

} 

typeSH <- array (NA, dim = c (nlat, nlon))                     

# Determine which cells have less than thr_frac_skill 
pvalueFull <- pvalue_allSH [ , , , 2:nlead, iFull]

sign <- pvalueFull
val  <- pvalueFull
sign[] <- NA
val[] <- 0
	   
# sign is 1  if the correlation is significant
#         0  if it is not significant and
#         NA if it is not computed
sign [which ((pvalueFull >= 0.0 & pvalueFull <= 0.05), arr.ind = T)] <- 1
sign [which ((pvalueFull <= 1.0 & pvalueFull >  0.05), arr.ind = T)] <- 0
val  [which (!is.na(pvalueFull), arr.ind = T)] <- 1
totsign <- apply (sign, c(1,2), sum, na.rm = T)
totval  <- apply (val,  c(1,2), sum)
fracsign <- totsign / totval

typeSH [which (fracsign < thr_frac_skill, arr.ind = T)] <- 4 

indcell <- which (fracsign >= thr_frac_skill, arr.ind = T)
typeSH [indcell] <- 1
ncell <- dim(indcell)[1]

for (icell in (1:ncell)) { 

   print (icell)
   ilat <- indcell [icell, 1]	
   ilon <- indcell [icell, 2]	
   metrcellall  <- metric_allSH [ilat, ilon, , 2:nlead, ]
   metrcellFull <- metrcellall  [ , , iFull] 
   hindcellall  <- hind_allSH   [ilat, ilon, , , 2:nlead, ]
   hindcellFull <- hindcellall  [ , , , iFull] 
   obscell      <- all_obs      [ilat, ilon, , ]
   signcellFull <- sign         [ilat, ilon, , ]
   
   for (iRestr in (1:nSH)) {

      # Perform this task for all restricted hindcasts	   
	  if (iRestr == iFull) next
	  
      nEq  <- 0
      nFullGtRestr <- 0
      nRestrGtFull <- 0
      nNA <- 0

	  metrRestrall <- metrcellall [ , , iRestr]
	  
      for (imth in (1:nmth)) {

		 obs_here <- obscell [ , imth] 

         for (ilead in (1:(nlead-1))) {
		  
	   	    metrFull  <- metrcellFull [imth, ilead] 
		    metrRestr <- metrRestrall [imth, ilead] 
		    hindhere     <- hindcellall [ , imth, ilead, iSH]
		    hindFullhere <- hindcellall [ , imth, ilead, iFull]
		    R_restr_Full <- cor (hindhere, hindFullhere)
		    signhere     <- signcellFull [imth, ilead] 
		    
            # Fractions are calculated only for cells with valid metrics
            #    for both types of hindcasts and with significant skill		    
            if (!is.na (metrFull) & !is.na (metrRestr) & signhere == 1) {
		       statis <- paired.r (metrFull, metrRestr, R_restr_Full, nyear)
               pvalue_pair <- statis$p
               if (is.na (pvalue_pair)) {
				  #if (R_restr_Full < 0.99) {
					# print (paste (metrFull, metrRestr, R_restr_Full, sep = "   "))
				  #}
				  pvalue_pair <- 0.001
			   }
               # The resulting p-value is the chance that,
               #    if two R's are equal in reality (the null-hypothesis),
               #    they have the actual values or are further apart
               # if TRUE, the metrics are different at 95% confidence
               if (pvalue_pair >= 0.0 & pvalue_pair <= 0.05) {
			      if (metrFull > metrRestr) {
			         nFullGtRestr <- nFullGtRestr + 1
			      } else {
			         nRestrGtFull <- nRestrGtFull + 1
			      }
		       # if FALSE, equality cannot be excluded
		       } else {
		          nEq <- nEq + 1
	           }
	        } else {
		       nNA <- nNA + 1
	        }
      	   
         }
      }

      # Calculate fraction of cases for which restricted hindcasts are enough    
      fracRestrEnough <- (nRestrGtFull + nEq) / (nRestrGtFull + nEq + nFullGtRestr)
      fracRestrBetter <- nRestrGtFull / (nRestrGtFull + nEq + nFullGtRestr)
      if (fracRestrEnough > thr_frac_restr_e) {
		 if (iRestr == iInit)  typeSH [ilat, ilon] <- 2
		 if (iRestr == iMeteo) typeSH [ilat, ilon] <- 3
	  } 
      #if (fracRestrBetter > thr_frac_restr_b) {
		 #if (iRestr == iInit)  typeSH [ilat, ilon] <- 5
		 #if (iRestr == iMeteo) typeSH [ilat, ilon] <- 6
	  #} 
   
   }  # End of the loop over the types of restricted hindcasts

}  # End of the loop over the cells of the domain 

dirdom <- paste (dirlustre, "VIC/paramfiles/", sep = "") 
filedom <- paste (dirdom, "domain_", domain, "_maskCorr.nc", sep = "")
ncdom <- nc_open (filedom)
lon <- ncvar_get (ncdom, varid = "lon")
lat <- ncvar_get (ncdom, varid = "lat")
nc_close (ncdom)

dist_ns_dom <- nlat
mid_lat <- 0.5 * (lat[1] + lat[nlat])
dist_we_dom <- nlon * cos (mid_lat / 180 * pi)
w_map <- 500
h_map <- w_map * dist_ns_dom / dist_we_dom

pix_bot     <-  50
pix_left    <-  50
pix_top     <-  30
pix_right   <-  30

w_image <- pix_left + w_map + pix_right
h_image <- pix_bot + h_map + pix_top

relc_big <- c ((pix_left / w_image), 
               ((pix_left + w_map) / w_image), 
               (pix_bot / h_image), 
               ((pix_bot + h_map) / h_image))
               
bps <- seq (0.5, 4.5, length.out = 5)

coltype <- c("red", "orange", "purple", "blue", "green", "yellow")
coltype <- c("red", "orange", "purple", "blue")

# Load data for sub-regions
# The first is the whole region                     
# Provide boundaries (N,E,S,W) of the sub-regions in coor_reg
dirlustre <- "/lustre/backup/WUR/ESG/greue002/"
dirreg <- paste (dirlustre, "CLIMAX/", domain, "/static_data/", sep = "")
filereg <- paste (dirreg, "regboundaries.rds", sep = "")
load (filereg)

if (nreg > 0) {
   xline_arr <- array (0, dim = c(5, nreg))
   yline_arr <- array (0, dim = c(5, nreg))
   for (ireg in (1:nreg)) {
      coor <- coor_reg[ ,ireg]
      xline_reg <- c(coor[4], coor[4], coor[2], coor[2], coor[4]) 
      yline_reg <- c(coor[3], coor[1], coor[1], coor[3], coor[3])
      xline_arr[ ,ireg] <- xline_reg 
      yline_arr[ ,ireg] <- yline_reg
   }
}
              
if (toscreen) {
   w_cm <- 7.0
   h_cm <- w_cm * h_image / w_image
   dev.new (width = w_cm, height = h_cm)
}

plotvar <- aperm (typeSH)

if (!toscreen) {
   fileout <- paste (dirout, "summary_skill_specSH.png", sep = "") 
   png (file = fileout, width = w_image, height = h_image, pointsize = 12, 
        bg = "white")
}
        
par (cex.main = 1.6, cex.axis = 1.1, las = 1, mgp = c(2,1,0))
par (xpd = F)
par (mai = c (pix_bot, pix_left, pix_top, pix_right) / 72)

title <- " "
image (lon, lat, plotvar, breaks = bps, col = coltype,
       xlab = "", ylab = "", oldstyle = F, 
       main = title,
       axis.args = list(cex.axis = 1.3))
map ("world", add = T)

# Voeg hokken toe voor de uitgelichte sub-regio's           
if (nreg > 0) {
   for (ireg in (1:nreg)) {
      xline <- xline_arr[ ,ireg]
      yline <- yline_arr[ ,ireg]
	  if (regnames[ireg] == "Amazonia-Guianas" |
         regnames[ireg] == "North Chile" |
	     regnames[ireg] == "Southeast South America Cfa") {
	     lines (xline, yline, lty = 1, lwd = 3)
	  }
   }
}
      
if (toscreen) {
   print ("Enter something to continue")
   entval <- scan (file = "", what = "", nmax = 1)
} else {
   dev.off ()
}
      



