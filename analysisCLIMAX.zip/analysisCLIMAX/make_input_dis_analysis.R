rm(list=ls())	#remove all the variables from the workspace

# Aim of the script:
# produce data sets (monthly means) for analysis of discharge 
#    computed with a reference simulation

library (ncdf4)

Domain <- "SA"
Version <- "v0"
ForcRef <- "WFDEI_aug2018" 

DirLustre <- "/lustre/backup/WUR/ESG/greue002/"
FileSim <- paste (DirLustre, "CLIMAX/", Domain, "/VIC/", ForcRef, 
                  "/halfdegree_std_SREF_noBC_", Version, 
                  "/allmonthavg.nc", sep = "")
FileObs <- paste (DirLustre, "dischargedata/netcdf/",
                  "global_latlon_res_halfdegr_LargestArea_withONS_MON.nc",
                  sep = "")
FileOut <- paste (DirLustre, "verif_ref/data/dis_", Domain, "_",
                  ForcRef, "_", Version, ".rds", sep = "")
                  
CommDate <- paste ("cdo -s showdate ", FileSim, sep = "")
DatesSim1S <- system (CommDate, intern = T)
DatesSim <- strsplit (DatesSim1S, "  ")
nSimF <- length (DatesSim[[1]]) - 1
FYearSim <- strtoi (substr (DatesSim[[1]] [2],       1, 4))
LYearSim <- strtoi (substr (DatesSim[[1]] [nSimF+1], 1, 4))

CommDate <- paste ("cdo -s showdate ", FileObs, sep = "")
DatesObs1S <- system (CommDate, intern = T)
DatesObs <- strsplit (DatesObs1S, "  ")
nObsF <- length (DatesObs[[1]]) - 1
FYearObs <- strtoi (substr (DatesObs[[1]] [2],       1, 4))
LYearObs <- strtoi (substr (DatesObs[[1]] [nObsF+1], 1, 4))

FYearCom <- max (FYearObs, FYearSim)
LYearCom <- min (LYearObs, LYearSim)

nMth <- 12

# Open file with simulations
NcSim   <- nc_open (FileSim)
DisSim  <- ncvar_get (NcSim, "dis")
LonSim  <- ncvar_get (NcSim, "lon")
LatSim  <- ncvar_get (NcSim, "lat")
nc_close (NcSim)

LonMin <- min(LonSim)
LonMax <- max(LonSim)
LatMin <- min(LatSim)
LatMax <- max(LatSim)

FSim <- (FYearCom - FYearSim) * nMth + 1
LSim <- (LYearCom - FYearSim + 1) * nMth
nSim <- LSim - FSim + 1
DisSimCom <- DisSim [ , , FSim:LSim]
TimeCom <- DatesSim [[1]] [(FSim+1):(LSim+1)]

# Open file with discharge observations
NcObs   <- nc_open (FileObs)
DisObs  <- ncvar_get (NcObs, "dis")
LonObs  <- ncvar_get (NcObs, "lon")
LatObs  <- ncvar_get (NcObs, "lat")
                  
indLonObs <- which (LonObs >= LonMin & LonObs <= LonMax)
indLatObs <- which (LatObs >= LatMin & LatObs <= LatMax)

FObs <- (FYearCom - FYearObs) * nMth + 1
LObs <- (LYearCom - FYearObs + 1) * nMth
nObs <- LObs - FObs + 1
DisObsRegCom <- DisObs [indLonObs, indLatObs, FObs:LObs]

NObsAll <- ncvar_get (NcObs, "months_WFDEI_obs")
NObsReg <- NObsAll [indLonObs, indLatObs]
indStats <- which (NObsReg > 0, arr.ind = T)
nLoc <- dim (indStats) [1]

DisObsSave <- array (NA, dim = c (nLoc, nObs))
DisSimSave <- array (NA, dim = c (nLoc, nObs))
for (iLoc in (1:nLoc)) {
   indLoc <- indStats [iLoc, ]
   DisObsSave [iLoc, ] <- DisObsRegCom [indLoc[1], indLoc[2], ]
   DisSimSave [iLoc, ] <- DisSimCom    [indLoc[1], indLoc[2], ]
} 

RNAll <- ncvar_get (NcObs, "river_name")
RNReg <- RNAll [indLonObs, indLatObs]
RiverName <- RNReg[indStats]

SNAll <- ncvar_get (NcObs, "station_name")
SNReg <- SNAll [indLonObs, indLatObs]
StationName <- SNReg[indStats]

AOAll <- ncvar_get (NcObs, "area_observed")
AOReg <- AOAll [indLonObs, indLatObs]
AreaObserved <- AOReg[indStats]

AMAll <- ncvar_get (NcObs, "area_model")
AMReg <- AMAll [indLonObs, indLatObs]
AreaModel <- AMReg[indStats]

GRAll <- ncvar_get (NcObs, "GRDC_number")
GRReg <- GRAll [indLonObs, indLatObs]
GRDCNumber <- GRReg[indStats]

LatSAll <- ncvar_get (NcObs, "latitude_station")
LatSReg <- LatSAll [indLonObs, indLatObs]
LatStat <- LatSReg[indStats]

LonSAll <- ncvar_get (NcObs, "longitude_station")
LonSReg <- LonSAll [indLonObs, indLatObs]
LonStat <- LonSReg[indStats]

AltAll <- ncvar_get (NcObs, "altitude")
AltReg <- AltAll [indLonObs, indLatObs]
Altitude <- AltReg[indStats]

save (DisObsSave, DisSimSave, TimeCom, RiverName, StationName,
      AreaObserved, AreaModel, GRDCNumber, LatStat, LonStat,
      Altitude, nLoc, file = FileOut)




