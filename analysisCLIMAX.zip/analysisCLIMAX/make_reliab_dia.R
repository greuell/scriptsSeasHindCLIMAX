rm(list=ls())	#remove all the variables from the workspacederiv

library (SpecsVerification)
library (ncdf4)
library (fields)
library (verification)
library (RColorBrewer)
library(maps)

library(devtools)
find_rtools()

#devtools::install_github("MeteoSwiss/easyVerification")
library (easyVerification)

ls (pos = "package:easyVerification")

model = "VIC"
NWPsyst = "seas15"
domain = "EU"
typerun = "BC"
varname = "dis"            # bijv. "dis"
typeobs <- "pseudo"        # "pseudo" or "real"    
typebas <- "allcells"      # "allcells", "largebasins" or "subcell"
nmem = 15

toscreen <- F

# Analyse wordt per seizoen gedaan. Er zijn nseas seizoenen.
# Elke analyse neemt nleadana lead maanden
# En begint in de maanden leadbeg
nseas = 4
leadbeg <- c (1, 3, 5)
nleadana <- 2
nanalead <- length (leadbeg)

# Een van de make variabelen moet T zijn; de andere F
make_atdia_grp <- F         # make attribute diagrams for grid points
make_maps_or_attr_dom <- T  # make maps or attribute diagrams of the entire domain
# Een van de volgende drie volgende variabelen moet T zijn;
#    de beide andere F
maps_relsc     <- F         # make maps of reliability score
maps_slope     <- T         # make maps of slope
make_atdia_dom <- F         # make attribute diagrams for entire domain
adapted_dia <- F            # if false: usual diagram
                            # if true:  forecast probability is subtracted
                            #           mean of observations

binmid <- seq(from = 0, to = nmem, by = 1)
binmid <- seq(from = 0.5, to = (nmem - 0.5), by = 2)
binmid <- binmid / nmem
nbins <- length (binmid)
dbin <- binmid[2] - binmid[1]
lowb <- binmid - 0.5 * dbin
upb  <- binmid + 0.5 * dbin

numsam   <- vector (mode = "integer", length = nbins)
meanprob <- vector (mode = "double",  length = nbins)
meanobs  <- vector (mode = "double",  length = nbins)

months_init <- c("J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D" )
classes <- c("BN", "NN", "AN") 

if (varname == "dis") {
   if (typeobs == "real") {
	  extendname <- "_real_obs"
   } else if (typeobs == "pseudo") {
	  extendname <- "_pseudo_obs"
   }
   extendname <- paste (extendname, "_", typebas, sep = "")
   info_title <- paste (typeobs, typebas, sep = " ")
} else {
   extendname <- ""
   info_title <- ""
}

dirlustre = "/lustre/backup/WUR/ESG/greue002/"
fig.dir <- paste (dirlustre, "verif_seas/figures/", varname, "/",
                  model, "/", sep = "")
system (paste ("mkdir -p ", fig.dir, sep = "")) 

dirstats <- paste (dirlustre, "verif_seas/statdata/", varname, "/", 
                   model, "/", sep = "")

file_prob <- paste (dirstats, "prob_",     model, "_", typerun, 
                    "_", varname, extendname, ".txt", sep = "")
load (file = file_prob)
file_obs  <- paste (dirstats, "obscat_",   model, "_", typerun, 
                    "_", varname, extendname, ".txt", sep = "")
load (file = file_obs)

diminput <- dim(prob_hind_all)
nlat   = diminput[1]
nlon   = diminput[2]
maxnyr = diminput[3]
nclass = diminput[4]
nmthyr = diminput[5]
nlead  = diminput[6]

prob_cl <- 1.0 / nclass

nmthseas = nmthyr / nseas
maxmiss = nmthseas * nleadana
maxnumsam = maxnyr * nmthseas * nleadana
maxsamdom <- maxnumsam * nlat * nlon

indtake       <- array(0, dim = c(maxnyr, nmthyr, nlead))

rel_score <- array(NA, dim = c(nlat, nlon)) 
slope     <- array(NA, dim = c(nlat, nlon)) 

prob_RD       <- c(1:maxnumsam)
obs_RD_binary <- c(1:maxnumsam)

# Kleurenschaal voor de reliability score
maxvalrs = 0.027
ncol_rs = 9
nbreak_rs = ncol_rs + 1
dbreak = maxvalrs / ncol_rs
breakpsrelsc <- seq(from = 0.0, to = maxvalrs, by = dbreak)

# Kleurenschaal voor de afgeleide
ncol_der = 11
nbreak_der = ncol_der + 1
d_scale_der <- 0.3
maxder <- ncol_der * d_scale_der * 0.5
minder <- -maxder
breakpsslope <- seq(from = -maxder, to = maxder, by = d_scale_der)

ncol_der = 8
nbreak_der = ncol_der + 1
d_scale_der <- 0.2
minder <- -0.3
maxder <- minder + ncol_der * d_scale_der 
breakpsslope <- seq(from = minder, to = maxder, by = d_scale_der)
colslopes <- c("yellow", "moccasin", "goldenrod1", "darkorange",
               "red", "firebrick4", "black", "blue3")
colslopes <- c("yellow", "lemonchiffon", "goldenrod1", "darkorange",
               "red", "red3", "purple4", "blue3")
colslopes <- c("gray", "lemonchiffon", "yellow", "darkorange",
               "red", "red3", "purple4", "blue1")

# Inlezen van de WFDEI run omdat lat en lon nodig zijn
if (model == "LPJ" | model == "seas15") {
    dircoor <- paste ("/lustre/backup/WUR/ESG/data/PROJECT_DATA/",
                       "EUPORIAS/MODEL_OUTPUT/LPJml/0.50deg/", 
                       "EU_HINDCAST_BC_rev4.0/statistics/", sep = "")
    filecoor <- paste ("Outputwatermodels_stats_LPJml_",
                       "seas15_EU_BC_E01_INIT1982_12.nc4", sep = "")
} else if (model == "VIC") {
     dircoor <- paste (dirlustre, "VIC/netcdfout/seas15_EU/noESP/", 
                                    "BC/leadtime/", sep = "")
     filecoor <- "swemean_monthly_VIC_seas15_EU_BC_E14_lead7.nc4"
} # else if (model == "seas15") {
#      dircoor <- paste (dirlustre, "VIC/netcdfout/seas15_EU/noESP/", 
#                                    "BC/leadtime/", sep = "")
#    filecoor <- "precipmean_monthly_VIC_seas15_EU_BC_E14_lead7.nc4"
# }
filecoor <- paste (dircoor, filecoor, sep = "")	
	
nccoor <- nc_open(filecoor)

lat <- ncvar_get(nccoor, varid = "lat")
lon <- ncvar_get(nccoor, varid = "lon")
nc_close(nccoor)

nlontf <- length (lon)
nlattf <- length (lat)
if (nlon != nlontf | nlat != nlattf) stop ("ho")

# Het gaat hier om het targetseizoen
# van de maanden van elk seizoen worden de indices bepaald      
for (iseas in 1:nseas) {

   # Bepaal eerste en laatste target maand 
   #    en de indices van de target maanden	
   ftargmth = 3 + (iseas - 1) * nmthseas	
   ltargmth = ftargmth + nmthseas - 1
   indtargmth = c(ftargmth:ltargmth)
   idm12 <- ifelse(indtargmth > 12, 1, 0)
   idm12 <- which(idm12 == 1)
   indtargmth[idm12] = indtargmth[idm12] - 12
   
   print (paste("Season = ", iseas))
   print (paste("Target month = ", indtargmth))
   
   seas_init = ""
   for (imth in indtargmth) 
      { seas_init <- paste (seas_init, months_init[imth], sep = "")}

   if (make_maps_or_attr_dom) {   
      # Initialize a plot to be written to a png-file
      # width en height zijn default in pixels
      # pointsize bepaalt de grootte van letters
 
      if (maps_relsc) {
		 name_map <- "reliab_score"
	  } else if (maps_slope) {
		 name_map <- "slope_rel_diagr"
		 if (adapted_dia) {
			typedia <- "adapt"
		 } else {
			typedia <- "usual"
	     }
	     name_map <- paste (name_map, "_", typedia, sep = "")		  
	  } else if (make_atdia_dom) {
		 name_map <- "atdia_dom"
	  }

      if (toscreen) {
		 widthscreen <- 6.0
		 heightscreen <- 6.0
         dev.new (width = widthscreen, height = heightscreen) 
      } else {
		 if (make_atdia_dom) {
			width_pix <- 1000
			height_pix <- 1000
		 } else {
			width_pix <- 1500
			height_pix <- 1000
	     }
		 width_plot <- nclass * width_pix
         height_plot <- nanalead * height_pix  
         png (file = paste (fig.dir, model, "_", varname, "_", name_map, "_",
                            seas_init, "_", typerun, extendname, ".png", sep=""), 
                            width = width_plot, height = height_plot, pointsize =12, 
                            bg = "white")

         # Set parameters for the plot
         # oma determines size of margins
         # mar also (what is the difference with oma?)
         # cex.main: the magnification to be used for main titles  
         #           relative to the current setting of cex.
         # xpd determines clipping
         # las = 1: all axis labels horizontal
         # lheight determines space between lines of text
         # mgp determines space between axes, its labels etc. ?
         par (mfrow = c(nanalead, nclass), oma = c(5,5,5,5), mar = c(5,5,10,20))
      }

   }

   # Dit is de loop over de leadmonths. Er worden enkele samengevoegd.   
   for (ianalead in 1:nanalead) {
	   
      # Bepaal eerste en laatste lead maand 
      #    en de indices van de lead maanden
      fleadmth <- leadbeg[ianalead]
      lleadmth <- leadbeg[ianalead] + nleadana - 1	
	  indlead = c(fleadmth:lleadmth)
	  indtake[] = 0
	  
	  print (paste("Lead month = ", (indlead - 1)))

      leadmth_nrs = ""
      for (lmth in indlead) 
         { leadmth_nrs <- paste (leadmth_nrs, lmth - 1, sep = "")}
   
      # Nu wordt er bepaald welke combinaties van leadmaanden en inimaanden meedoen
      # indtake = 1 voor de arrayelementen, die voor de analysie gebruikt worden
      # ind1 zijn de indices van de elementen van indtake gelijk aan 1	  
      for (targmth in indtargmth) {
	  for (leadmth in indlead) {
		 indinimth = targmth - leadmth + 1
         if (indinimth < 1) indinimth = indinimth + 12
	     print (paste("Target month = ", targmth, " Initialization month = ", indinimth))
	     indtake[,indinimth, leadmth] = 1
	  }
      }
      ind1 <- which(indtake[,,] == 1)
      
 	  for (iclass in 1:nclass) { 
 	  # for (iclass in 1:1) { 
		  
		 print (paste ("Categorie ", iclass, sep = ""))

		 rel_score[] = NA 
		 slope[]     = NA 

         prob_RD_all    <- vector (mode = "double", length = maxsamdom)
         obs_RD_bin_all <- vector (mode = "double", length = maxsamdom)
         prob_RD_all[]    <- NA
         obs_RD_bin_all[] <- NA
         nsam_all <- 0
	  
 	     for (ilat in 1:nlat) {
		 for (ilon in 1:nlon) {

            # Per roostercel en categorie (BN, NN, AN) worden de verwachte
            #    kansen geselecteerd
            # En de waargenomen categorie (1, 2, of 3 in het geval van tercielen)
            # Dit is een 3D array (aantal jaren, aantal target, aantal lead maanden)			 
            prob_array = prob_hind_all[ilat, ilon, , iclass, , ]
            obs_array  = obs_cat_all[ilat, ilon, , , ]
            
            # Hier worden de data beperkt tot de te selecteren target en lead maanden
		    prob_RD = prob_array[ind1]
		    obs_RD  = obs_array[ind1]
		    
            # Als de waarneming nul is, is er geen waarneming
            # Sla geval (bepaalde combinatie van categorie, target en lead maand)
            #    over als er minstens een jaar waarnemingen ontbreekt		    
            ind0 <- which (obs_RD == 0)
            # prob_RD[ind0] = NA
            if (length(ind0) > maxmiss ) {
			   #if (length(ind0) != length(obs_RD)) {
			   #	  print (paste (lat[ilat], lon[ilon], length(ind0), sep = "   "))
			   #}
			   next 
			}

            # Zet de waarnemingen om in een binary, d.w.z. 0 als de waarneming
            #    in een andere categorie valt en 1 als de waarneming in de beschouwde 
            #    categorie valt
            indcl <- which (obs_RD == iclass)
            obs_RD_binary[] = 0
            obs_RD_binary[indcl] = 1
            
            nsam_RD <- length (prob_RD)
            fsam <- nsam_all + 1
            lsam <- nsam_all + nsam_RD
            prob_RD_all[fsam:lsam] <- prob_RD
            obs_RD_bin_all[fsam:lsam] <- obs_RD_binary
            nsam_all <- lsam
            
            # ReliabilityDiagram (prob_RD, obs_RD_binary, bins = breakp, plot = 1)
            
		    rs_loc     = 0.0
		    totnumval  = 0
		    numsam[]   = 0
		    meanprob[] = 0.0
		    meanobs[]  = 0.0

            # Bin de verwachtingen en bepaal de bijbehorende fractie van de
            #    waarnemingen		    
		    for (ibin in 1:nbins) {
			   indbin1 <- which (prob_RD >= lowb[ibin] & prob_RD < upb[ibin])
			   numsam[ibin] <- length(indbin1)
			   totnumval = totnumval + numsam[ibin]
			   if (numsam[ibin] != 0) {
				  meanprob[ibin] = mean(prob_RD[indbin1])
				  meanobs[ibin]  = mean(obs_RD_binary[indbin1])
				  rs_loc = rs_loc + numsam[ibin] * (meanprob[ibin] - meanobs[ibin]) ^ 2 }
			}

            diff_prob_obs <- abs( sum(numsam * meanprob) - sum(numsam * meanobs))
            rel_diff <- diff_prob_obs / sum(numsam * meanobs)			
			if (rel_diff > 0.1) {
			   print (paste (lat[ilat], lon[ilon], diff_prob_obs, sep = "   "))
			   next 
			}
			
			if (totnumval < (maxnumsam - maxmiss)) stop (paste ("There are only", 
			                                         totnumval, "samples", sep = " "))
			# Bereken de reliability score
			rs_loc = rs_loc / totnumval
			rel_score [ilat, ilon] = rs_loc

            # Trek een regressielijn door de punten (x = verwachte kans,
            #    y = waargenomen - verwachte kans)
            indbin <- which (numsam > 0)			
			if (adapted_dia) {
			   yvar <- meanobs[indbin] - meanprob[indbin]
			} else {
			   yvar <- meanobs[indbin] 
			}   
			regress <- lm (yvar ~ meanprob[indbin], weight = numsam[indbin])

            # Sla de helling van de regressielijn op			
			slope[ilat, ilon] = regress$coefficients[[2]]
			
            if (make_atdia_grp) {
               A <- verify(obs_RD_binary, prob_RD, frcst.type = "prob", 
                           obs.type = "binary", thresholds = c(lowb, upb[nbins]),
                           bins = T)
               dev.new ()			
			   attribute (A) 
			   # Met confidence intervals: attribute (A, CI = T) 
			
			   # Het volgende statement maakt de plot rechtstreeks uit mijn data
			   #     zonder gebruik van de verify functie
			   # Plot is identiek aan plot gemaakt m.b.v. verify
			   # Echter de relatieve frequentie van de samples is onjuist
			   # attribute (binmid, meanobs, meanprob, prob_cl) 
		       print ("Enter something to continue")
               entval <- scan (file = "", what = "", nmax = 1) 
            }
			
	     } # Einde loop over longitudes
	     } # Einde loop over latitudes
	     
         if (make_maps_or_attr_dom & make_atdia_dom) {
            # A <- verify(obs_RD_bin_all[1:nsam_all], 
            #             prob_RD_all[1:nsam_all], frcst.type = "prob", 
            #             obs.type = "binary", thresholds = c(lowb, upb[nbins]),
            #             bins = T)

            x_prob <- prob_RD_all[1:nsam_all] 
            y_obs  <- obs_RD_bin_all[1:nsam_all]
		    totnumval  = length (x_prob)
		    numsam[]   = 0
		    meanprob[] = 0.0
		    meanobs[]  = 0.0

            
            title <- paste (model, varname, typerun, 
                            info_title, "tar", seas_init, "lead", leadmth_nrs,
                            "cat", classes[iclass], sep=" ")
            valmin <- -0.05
            valmax <-  1.05 
            valran <- c( valmin, valmax)
 
            if (toscreen) {
               par (mar = c(4,4,2,2))     # Size of margins
               par (cex.lab = 1.3)        # Size of axes labels
               par (mgp = c (2, 0.8, 0))  # The first value represents the location 
                                          #    of the labels (i.e. xlab and ylab 
                                          #    in plot), the second the tick-mark 
                                          #    labels, and third the tick marks. 
                                          # The default is c(3, 1, 0).
		    } else {
               par (mar = c(12,14,8,6))   # Size of margins
               par (cex.main = 5, cex.axis = 5, cex.lab = 5,
                    mgp = c(9,4,0), lwd = 3, tck = -0.015)
            }

            x_title <- "Forecasted probability"
            y_title <- "Fraction of observations"                          
            plot (NULL, xlim = valran, ylim = valran,
                  xlab = x_title, ylab = y_title, main = title) 

            # Bin de verwachtingen en bepaal de bijbehorende fractie van de
            #    waarnemingen		    
		    for (ibin in 1:nbins) {
			   indbin1 <- which (x_prob >= lowb[ibin] & x_prob < upb[ibin])
			   numsam[ibin] <- length(indbin1)
			   if (numsam[ibin] != 0) {
				  meanprob[ibin] = mean(x_prob[indbin1])
				  meanobs[ibin]  = mean(y_obs[indbin1])
				  if (toscreen) {
					 sizesym <- sqrt (numsam[ibin] / totnumval) * 7
				  } else {
					 sizesym <- sqrt (numsam[ibin] / totnumval) * 21
			      }
				  points (meanprob[ibin], meanobs[ibin], pch = 1, cex = sizesym) 
			   }
			}
			
			xline <- valran
			yline <- valran
			lines (xline, yline)

			regress <- lm (meanobs ~ meanprob, weight = numsam)
			xline <- c( 0, 1)
			asafsn <- regress$coefficients[[1]]
			slopet <- regress$coefficients[[2]]
			yline <-  asafsn + slopet * xline
			lines (xline, yline, lty = 2)
			strslope <- format (slopet, digits = 3)
			if (toscreen) {
			   cex_text <- 1.5
			} else {
			   cex_text <- 5.0
			}
			text (0.45, 0.03, labels = c (paste ("slope. = ", strslope, sep = "")), 
			      cex = cex_text, pos = 4)
            print (regress)
            
            xline <- c( prob_cl, prob_cl)
            yline <- valran
			lines (xline, yline, lty = 3)

            xline <- valran
            yline <- c( prob_cl, prob_cl)
			lines (xline, yline, lty = 3)

            # par (cex.sub = 5) 
			# attribute (A, main = title)
         }
			
         if (make_maps_or_attr_dom & maps_relsc) {
			
			# zlim: the minimum and maximum z values for which colors should be plotted
            # smallplot gaat over de positie van de kleurenschaal
            title <- c (paste ("Reliab.sc.", model, varname, typerun, 
                               info_title, "tar", seas_init, "lead", leadmth_nrs,
                               "cat", classes[iclass], sep=" "))

            # Het gemiddelde over het domein van de reliability score
    	    mean_rel_score = mean (rel_score, na.rm = T)
    	    strrelsc <- format (mean_rel_score, digits = 2)

            # Dit gaat over het inkleuren van de kaart 
            #    voor het geval de reliability score hoger is dan het 
            #    maximum van de schaal	
            rel_score_plot <- rel_score
            indhigh <- which(rel_score_plot >= maxvalrs, arr.ind = T)
            rel_score_plot[indhigh] = maxvalrs - 0.001
         
            par (cex.main = 5, cex.axis = 5, cex.lab = 2.5,
                 xpd = NA, las = 1, lheight = 1.2, mgp = c(3,3,0))

            # lab.breaks zorgt ervoor dat de labels in de kleurenbar
            #    bij de kleurenovergangen staan
            image.plot (lon, lat, aperm (rel_score_plot), 
                        xlab = "", breaks = breakpsrelsc, 
                        col = rev (brewer.pal (ncol_rs, "YlOrRd")),
                        smallplot = c (0.87, 0.9, 0.05, 0.9), ylab = "", 
                        lab.breaks = format (breakpsrelsc, digits = 2),   
                        oldstyle = F, main = title)
                        
            map ("world", add = T)
            text (-8, 69, labels = c (paste( "Mean reliab. sc.: ",
                                              strrelsc)), cex = 5) 

         }
         
         if (make_maps_or_attr_dom & maps_slope) {               

            if (adapted_dia) {
			   begin_tit <- "slope. diff"
			} else {
		   	   begin_tit <- "slope"
		    }
			title <- c (paste (begin_tit, model, varname, typerun, 
		                       info_title, "tar", seas_init, "lead", 
			                   leadmth_nrs, "cat", classes[iclass], 
			                   sep = " "))

    	    mean_slope = mean (slope, na.rm = T)
    	    strslope <- format (mean_slope, digits = 3)
    	     
    	    slope_plot <- slope
            indhighder <- which(slope_plot >= maxder, arr.ind = T)
            slope_plot[indhighder] = maxder - 0.1 * d_scale_der
            indlowder  <- which(slope_plot <= minder, arr.ind = T)
            slope_plot[indlowder]  = minder + 0.1 * d_scale_der
	
            par (cex.main = 5, cex.axis = 5, cex.lab = 2.5,
                 xpd = NA, las = 1, lheight = 1.2, mgp = c(3,3,0))

            image.plot (lon, lat, aperm (slope_plot), 
                        xlab = "", breaks = breakpsslope, 
                        # col = rev (brewer.pal (ncol_der, "RdYlBu")),
                        col = colslopes,
                        smallplot = c (.87,.9,0.05,0.9), ylab = "", 
                        oldstyle = F, main = title, 
                        lab.breaks = format (breakpsslope, digits = 2))

            map ("world", add = T)
            text (-8, 69, labels = c (paste( "Mean ", begin_tit, ": ",
                                             strslope, sep = "")), cex = 5)
         } 

	  } # Einde loop over classes
	  
   } # Einde van de loop over de groepen leadtimes
 
   if (toscreen) {
	  print ("Enter something to continue")
      entval <- scan (file = "", what = "", nmax = 1) }
  
   dev.off ()
         
} # Einde van de loop over de seizoenen   
  
      







