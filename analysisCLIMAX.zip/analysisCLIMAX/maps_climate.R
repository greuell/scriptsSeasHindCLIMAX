# Dit programma maakt kaartjes van het klimaat

rm(list=ls())	#remove all the variables from the workspace

library (ncdf4)
library (fields)
library (RColorBrewer)
library (maps)
library (mapdata)

library(devtools)
find_rtools()

toscreen <- F
datatype <- "obs"           # obs or hdc (hindcasts)
domain <- "SA"
varname <- "Precip"
resolution <- "halfdegree"
period <- "1981-2015"
hydmod <- "VIC"
version <- "v1"
specrun <- "std"
biascorr <- "noBC"
annsum <- T                 # plot annual sum instead of monthly means
Itaipu <- T                 # mark location of Itaipu

if (datatype == "obs") {
   forcing <- "WFDEI"
   forc_vers <- "aug2018"
   nleads <- 1
} else if (datatype == "hdc") {
   forcing <- "ecmwf"
   forc_vers <- "5"
   nleads <- 7
}

if (varname == "Precip") vartype <- "meteo"
if (varname == "swe")    vartype <- "hydro"

npixwidth <- 4500
if (domain == "EU") {
   npixheight <- 4000
} else if (domain == "SA") {
   npixheight <- 7500
   xleg <- -48.0
   yleg <- 11.0
   full_dom_name <- "South_America"
}

if (varname == "Precip") {
   unit <- "mm/d"
   vartitle <- "precipitation"
} else if (varname == "swe") {
   unit <- "mm w.e."
   vartitle <- "snow"
}

if (annsum) {
   fileper <- "ann"
   if (varname == "Precip") unit <- "mm"
} else {
   fileper <- "mth"
   if (varname == "Precip") unit <- "mm/d"
}

mthname <- c("Jan", "Feb", "Mar", "Apr", "May", "June",
             "July", "Aug", "Sep", "Oct", "Nov", "Dec")
nmthyr <- length (mthname)
ndaymth <- c (31, 28.25, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)

typestats <- c("avg", "std", "cfv")

lus_backup <- "/lustre/backup/WUR/ESG/greue002/"
dir_domain <- paste (lus_backup, "CLIMAX/", domain, "/", sep = "")
if (vartype == "meteo") {
   dirbase <- paste (dir_domain, "forcing/", forcing, "_", forc_vers,
                     "/", resolution, "_noBC_climate/", sep = "")
} else if (vartype == "hydro") {
   dirbase <- paste (dir_domain, hydmod, "/", forcing, "_", 
                     forc_vers, "/", resolution, "_", 
                     specrun, "_SREF_", biascorr, "_", version, 
                     "/climate/", sep = "")
}                  
                     
dirin   <- paste (dirbase, "data/", sep = "")
dirmaps <- paste (dirbase, "maps/", sep = "")

for (lead in (0:(nleads-1))) {

   # typestat is "avg", "std" or "cfv" and determines the inputfile
   for (typestat in typestats) {

      if (datatype == "obs") {
         filein   <- paste (dirin,   varname, "_ymon", 
                            typestat, ".nc", sep = "")
         filemaps <- paste (dirmaps, varname, "_", fileper, 
                            typestat, "_", period, ".png", sep = "")
         varfile <- varname
       } else if (datatype == "hdc") {
         filein   <- paste (dirin,   varname, "_lead", lead, "_ymon", 
                            typestat, ".nc",  sep = "")
         filemaps <- paste (dirmaps, varname, "_lead", lead, "_", fileper,
                            typestat, ".png", sep = "")
         varfile <- paste (varname, "_mean", sep = "")
      }
      ncin <- nc_open (filein)
      
      if (typestat == typestats[1] & lead == 0) {
         lat <- ncvar_get(ncin, varid = "lat")
         lon <- ncvar_get(ncin, varid = "lon")
         nlat <- length(lat)
         nlon <- length(lon)

         dist_ns_dom <- nlat
         mid_lat <- 0.5 * (lat[1] + lat[nlat])
         dist_we_dom <- nlon * cos (mid_lat / 180 * pi)
         w_map <- 500
         h_map <- w_map * dist_ns_dom / dist_we_dom

         pix_bot     <-  75
         pix_left    <-  75
         pix_top     <-  50
         w_bar       <-  20
         h_bar       <- 550
         pix_map_bar <-  50
         pix_right   <- 100

         w_image <- pix_left + w_map + pix_map_bar + w_bar + pix_right
         h_image <- pix_bot + h_map + pix_top

         relc_big <- c (pix_left / w_image, 
                        (pix_left + w_map) / w_image, 
                        pix_bot / h_image, 
                        (pix_bot + h_map) / h_image)
         relc_sml <- c ((pix_left + w_map + pix_map_bar) / w_image, 
                        (pix_left + w_map + pix_map_bar + w_bar) / w_image, 
                        (0.5 * (h_image - h_bar) / h_image), 
                        (0.5 * (h_image + h_bar) / h_image))
               
         bps <- seq (0, 1, length.out = 11)

      }
   
      var <- ncvar_get(ncin, varid = varfile)
      nc_close(ncin)
      
      if (annsum & typestat == "avg") {
		 yrsum <- array (0, dim = c (nlon, nlat))
	     for (imth in (1:nmthyr)) {
			summth <- ndaymth[imth] * var [ , , imth]
			yrsum <- yrsum + summth
		 }
		 maxsum <- max (yrsum, na.rm = T)
      }	

      nfig <- nmthyr      
      if (typestat == "avg") {	
         if (annsum) {
			titlestat = "Annual"
            lowtick <- 200.0
            hightick <- maxsum
            multftick <- 1.5
            nfig <- 1
	     } else {
			titlestat = "Average"
            lowtick <- 0.25
            hightick <- 30.0
            multftick <- 2
         }
      } else if (typestat == "std") {	
         titlestat = "St.dev. of"
         lowtick <- 0.25
         hightick <- 30.0
         multftick <- 2
      } else if (typestat == "cfv") {	
         titlestat = "Coeff.var. of"
         lowtick <- 0.4
         hightick <- 6.0
         multftick <- 1.5
      }

      if (toscreen) {
         w_cm <- 7.0
         h_cm <- w_cm * h_image / w_image
         dev.new (width = w_cm, height = h_cm)
      } else {
 	     png (file = filemaps, width = w_image, height = h_image, 
 	          pointsize = 12, bg = "white")
      }

      par (cex.main = 1.6, cex.axis = 1.1, las = 1, mgp = c(2,1,0))
      par (xpd = F)

      if (datatype == "obs") {
         title <- paste (titlestat, " ", vartitle, " (", unit, ") ",
                         period, sep = "")
      } else if (datatype == "hdc") {
         title <- paste (titlestat, " ", vartitle, " (", unit, ") ",
                         "lead ", lead, " ", period, sep = "")
      }

      lasttick <- lowtick
      
      while (lasttick < hightick) {
		 if (lasttick == lowtick) {
            ticks <- lowtick
         } else {
			ticks <- c(ticks, lasttick)
	     }
		 lasttick <- multftick * lasttick
	  }
	  
      nticks <- length (ticks)
      breakpointsp <- c ((ticks[1] / multftick), ticks, (ticks[nticks] * multftick))
      nbreakp <- length (breakpointsp)
      breakpoints <- breakpointsp
      if (typestat == "avg" & annsum) {
		 for (ib in (1:nbreakp)) {
			oldbp <- breakpointsp[ib]
			if (oldbp < 175) {
			   breakpoints[ib] <- round (oldbp /   10) *   10   
			} else if (oldbp < 1750) {
			   breakpoints[ib] <- round (oldbp /  100) *  100   
			} else {
			   breakpoints[ib] <- round (oldbp / 1000) * 1000 
			}
		 }
      }   
      ncolors <- nticks + 1
      epslow <- 0.01
      
      for (mth in 1:nfig) {

         if (typestat == "avg" & annsum) {
			varfig <- yrsum
		 } else {
			varfig <- var[ , , mth]
		 }
         print (paste (mthname[mth], min (varfig, na.rm = T), 
                       mean (varfig, na.rm = T),
                       max (varfig, na.rm = T)), sep = "   ")
         varplot <- varfig
         indlow  <- which (varfig < ticks[1], arr.ind = T)
         varplot[indlow]  <- ticks[1]      - epslow
         indhigh <- which (varfig > ticks[nticks], arr.ind = T)
         varplot[indhigh] <- ticks[nticks] + epslow
      
         image.plot (lon, lat, log(varplot), main = title, 
                     #axis.args = list( at = log(ticks), labels = ticks),           
                     smallplot = relc_sml, bigplot = relc_big, ylab = "",
                     xlab = "", breaks = log (breakpoints),
                     axis.args = list(cex.axis = 1.3), 
                     col = brewer.pal (ncolors, "RdBu"), oldstyle = F, 
                     lab.breaks = c ("", 
                     format (breakpoints[2:(nbreakp-1)], digits = 2), "")) 
 
         legend (xleg, yleg, mthname[mth], cex = 7, bty = "n")

         map ("world", resolution = 0, add = T, interior = F)
         map ("rivers",  col = "black", lwd = 2, add = T)
         
         if (Itaipu) {
            latItaipu <- -25.408
            lonItaipu <- -54.589
            points (lonItaipu, latItaipu, cex = 1.5, pch = 19)
            if (toscreen) {
			   xText <- lonItaipu - 4
               yText <- latItaipu + 3
            } else {  
			   xText <- lonItaipu - 2.5
               yText <- latItaipu + 2 
            } 
            legend (xText, yText, "It", cex = 1.5, bty = "n") 
         }
         
         if (toscreen) {
            print ("Enter something to continue")
            entval <- scan (file = "", what = "", nmax = 1)
         } else {
		    dev.off ()
	     }
	     
      }   # Einde loop over de maanden

      
   }   # End of the loop over the different types of statistics
   
   stop ("pil")

}   # End of the loop over the different lead months

stop ("hhh")
    
  
   
