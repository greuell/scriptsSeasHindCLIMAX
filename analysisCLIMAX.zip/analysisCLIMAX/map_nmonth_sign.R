# Dit programma maakt een kaart met het aantal maanden
#    met significante skill

rm(list=ls())	#remove all the variables from the workspace

library (fields)
library (RColorBrewer)
library (ncdf4)
library (maps)
library (hydroGOF)
library (mapdata)

type_sim <- "hind"           # hind or ref
domain <- "SA"
var <- "runoff"              # runoff, precip, evap, qs, qsb, airtemp, dis
hydmodel <- "VIC"            # ecmwf_5 voor SEAS5
metric <- "cc"               # cc, area_roc_AN, area_roc_BN, area_roc_NN, rps,
                             # or CRPSS 
biascorr <- "noBC"           # not relevant if type_sim = "ref"
forcing <- "ecmwf_5"
str_resol <- "halfdegree"
spec_run <- "Full"           # hydro: Full, Init, Meteo
                             # meteo: std
version <- "v1"
typeobs <- "pseudo_obs"      # has only effect for dis (real_obs or pseudo_obs)
detrended <- F               # Take detrended data
 
toscreen <- T
type_av  <- "all"            # "all": Plot average over all lead and target months 
                             #       (except lead month 0)
                             # "lead": Plot averages per lead month 
                             # "target": Plot averages per target month 
                             #       (except lead month 0)
                             # "change_lead": change with a one-month step in lead time
                             # should be "all" for type_sim = "ref"
                             
# End of setting variable variables

if (type_sim == "ref") {
   spec_run <- "Reference"
   typeobs = "real_obs" 
}
nmth <- 12

dirlustre <- "/lustre/backup/WUR/ESG/greue002/"

dirdom <- paste (dirlustre, "VIC/paramfiles/", sep = "") 
filedom <- paste (dirdom, "domain_", domain, "_maskCorr.nc", sep = "")
ncdom <- nc_open (filedom)
lon <- ncvar_get (ncdom, varid = "lon")
lat <- ncvar_get (ncdom, varid = "lat")
nc_close (ncdom)
nlon <- length (lon)
nlat <- length (lat)

if (var == "precip" | var == "airtemp") {
   typedata <- "meteo"
} else if (var == "runoff" | var == "evap" | var == "qs" | var == "qsb" |
           var == "dis") {
   typedata <- "hydro"
} 

if (detrended) var <- paste (var, "_detr", sep = "")

if (type_sim == "ref") {
   dirstatsbase <- "verif_ref/data/significantR/"
   dirout <- paste (dirlustre, "verif_ref/figures/significantR/", sep = "")
} else if (type_sim == "hind") {

   dirstatsbase <- paste ("verif_seas/", domain, "/statdata/", var, "/",
                          hydmodel, "/", forcing, "/", sep = "")
   diroutbase <- paste (dirlustre, "verif_seas/", domain, 
                        "/figures/annmeanskill/", var, "/",
                        hydmodel, "/", forcing, "/", sep = "")

   if (typedata == "meteo") {
      dirstats <- paste (dirstatsbase, str_resol, "_", biascorr, "/", 
                         sep = "")
      dirout   <- diroutbase
   } else if (typedata == "hydro") {
      dirstats <- paste (dirstatsbase, str_resol, "_", spec_run, "_SH_", 
                         biascorr, "_", version, "/", sep = "")
      dirout   <- paste (diroutbase,   str_resol, "_", spec_run, "_SH_", 
                         biascorr, "_", version, "/", sep = "")
   }                      

}                      

system (paste ("mkdir -p ", dirout, sep = ""))

if (type_sim == "ref") {
   sign <- array (NA, dim = c (nlon, nlat, nmth))
   for (imth in (1:nmth)) {
	  filein <- paste (dirlustre, "verif_ref/data/significantR/signR_mth",
	                   sprintf ("%02d", imth), ".rds", sep = "")
	  sign [ , , imth] <- readRDS (filein)                 
   }
} else if (type_sim == "hind") {

   if (var != "dis") {
      exttypeobs <- ""
   } else {
      exttypeobs <- paste ("_", typeobs, "_allcells", sep = "")
   }

   if (metric == "CRPSS") {
      filein <- paste (dirlustre, dirstats, "CRPSVars_", hydmodel,
                       "_", spec_run, "_", biascorr, "_", var, exttypeobs, 
                       ".txt", sep = "")                 
	   
   } else {
      filein <- paste (dirlustre, dirstats, "p_", metric, "_", hydmodel,
                       "_", spec_run, "_", biascorr, "_", var, exttypeobs, 
                       ".txt", sep = "")                 
   }
   load (file = filein)

   if (metric == "cc" | metric == "rps") {
      str_arr_name <- paste ("pvalue_", metric, "_all", sep = "")
      arr_name <- get (str_arr_name)
   } else if (metric == "CRPSS") {
      str_arr_name <- "CRPSSpValAll"
      arr_name <- get (str_arr_name)
   } else {
      arr_name <- get ("arr_write")
   } 

   dimarr <- dim (arr_name)
   nlead <- dimarr[4]

}

dist_ns_dom <- nlat
mid_lat <- 0.5 * (lat[1] + lat[nlat])
dist_we_dom <- nlon * cos (mid_lat / 180 * pi)
w_map <- 500
h_map <- w_map * dist_ns_dom / dist_we_dom

pix_bot     <-  75
pix_left    <-  75
pix_top     <-  50
w_bar       <-  20
h_bar       <- 550
pix_map_bar <-  50
pix_right   <- 100

w_image <- pix_left + w_map + pix_map_bar + w_bar + pix_right
h_image <- pix_bot + h_map + pix_top

relc_big <- c (pix_left / w_image, 
               (pix_left + w_map) / w_image, 
               pix_bot / h_image, 
               (pix_bot + h_map) / h_image)
relc_sml <- c ((pix_left + w_map + pix_map_bar) / w_image, 
               (pix_left + w_map + pix_map_bar + w_bar) / w_image, 
               (0.5 * (h_image - h_bar) / h_image), 
               (0.5 * (h_image + h_bar) / h_image))
               
bps <- seq (0, 1, length.out = 11)
nbreaks <- length (bps)

ni <- 256
bcn <- 0
nwhbl <- 7
ndb <- 139
fbl <- 30
red   <- c(seq (ni-fbl, 0,       length.out = nwhbl), seq (0, 0, length.out = nmth - nwhbl))
green <- c(seq (ni-fbl, 0,       length.out = nwhbl), seq (0, 0, length.out = nmth - nwhbl))
blue  <- c(seq (ni-fbl, ni-fbl , length.out = nwhbl), seq (ni-1, ndb, length.out = nmth - nwhbl))
# mislukt alternatief? <- rgb(red, green, blue, names = NULL, maxColorValue = (ni-1))
colnames <- c("white", "lightblue1", "darkslategray1", "cyan", "cyan2", 
              "deepskyblue1", "blue", "orchid3", 
              "purple2", "red", "red3", "brown", "black")
colnames <- c("white", "darkslategray1", "cyan2", 
              "deepskyblue1", "blue", "orchid3", 
              "purple2", "red", "brown", "black")
colnames <- c("white", "darkslategray1", "cyan2", 
              "deepskyblue1", "blue",  
              "purple2", "red", "red3", "brown", "black")
# Color codes from https://www.rapidtables.com/web/color/RGB_Color.html             
#colnames <- c ("#FFFFFF", "#FFFFCC", "#FFFF99", "#CCFF99", 
#               "#66FFFF", "#3399FF", "#0000FF", "#000099", 
#               "#4C0099", "#99004C", "#990000", "#660000", 
#               "#000000")
#colind <- seq (from = 1, to = 0, length.out = 13)               
#colnames <- rgb(colind, colind, colind, alpha = 1, maxColorValue = 1)

# Load data for sub-regions
# The first is the whole region                     
# Provide boundaries (N,E,S,W) of the sub-regions in coor_reg
dirlustre <- "/lustre/backup/WUR/ESG/greue002/"
dirreg <- paste (dirlustre, "CLIMAX/", domain, "/static_data/", sep = "")
filereg <- paste (dirreg, "regboundaries.rds", sep = "")
load (filereg)

if (nreg > 0) {
   xline_arr <- array (0, dim = c(5, nreg))
   yline_arr <- array (0, dim = c(5, nreg))
   for (ireg in (1:nreg)) {
      coor <- coor_reg[ ,ireg]
      xline_reg <- c(coor[4], coor[4], coor[2], coor[2], coor[4]) 
      yline_reg <- c(coor[3], coor[1], coor[1], coor[3], coor[3])
      xline_arr[ ,ireg] <- xline_reg 
      yline_arr[ ,ireg] <- yline_reg
   }
}
              
if (toscreen) {
   w_cm <- 7.0
   h_cm <- w_cm * h_image / w_image
   dev.new (width = w_cm, height = h_cm)
}

totsign_alllead  <- array (NA, dim = c(nlat, nlon)) 
fracsign_alllead <- array (NA, dim = c(nlat, nlon)) 

if (type_sim == "ref") {
   ibeg <- 1
   iend <- 1
} else if (type_sim == "hind") {
   if (type_av == "all") {
      ibeg <- 1
      iend <- 1
   } else if (type_av == "change_lead") {
      ibeg <- 1
      iend <- nmth
   } else if (type_av == "lead") {
      ibeg <- 2
      iend <- nlead
   } else if (type_av == "target") {
      ibeg <- 1
      iend <- nmth
   }
}

for (i in (ibeg:iend)) {

   if (type_sim == "ref") {
	   
	  val <- sign
	  val[] <- 0
	  val  [which (!is.na(sign), arr.ind = T)] <- 1
	   
   } else if (type_sim == "hind") {	

      # Pas op, leadmth = 3 is lead month 2 in het paper, etc.
      if (type_av == "all") {
	     pvalue <- arr_name [ , , , 2:nlead]
	     pvalue <- aperm (pvalue, c(2,1,3,4)) 
      } else if (type_av == "change_lead") {
	     pvalue <- arr_name 
	     pvalue <- aperm (pvalue, c(2,1,3,4)) 
      } else if (type_av == "lead") {
	     pvalue <- arr_name [ , , , i]
	     pvalue <- aperm (pvalue, c(2,1,3)) 
         leadpap <- i - 1
      } else if (type_av == "target") {
	     pvalue <- arr_name [ , , i, 2:nlead]
	     pvalue <- aperm (pvalue, c(2,1,3)) 
      }
      
      sign <- pvalue
      val  <- pvalue
      sign[] <- NA
      val[] <- 0
	   
      # sign is 1 if the correlation is significant
      #         0 if it is not significant and
      #         NA if it is not computed
      sign [which ((pvalue >= 0.0 & pvalue <= 0.05), arr.ind = T)] <- 1
      sign [which ((pvalue <= 1.0 & pvalue >  0.05), arr.ind = T)] <- 0
      val  [which (!is.na(pvalue), arr.ind = T)] <- 1
   }
   
   if (type_av != "change_lead") {
      # totsign is the number of cases with a significant correlation
      # totval is the number of cases with a valid determination of p
      totsign <- apply (sign, c(1,2), sum, na.rm = T)
   } else {
	  change_sign <- array (NA, dim = c (nlat, nlon, (nlead-1)))
	  val         <- array (NA, dim = c (nlat, nlon, (nlead-1)))
	  for (ilead in (1:(nlead-1))) {
		 inimth <- i - ilead + 1
		 if (inimth < 1) inimth <- inimth + nmth
		 change_sign[ , , ilead] <- sign[ , , inimth, (ilead+1)] - sign[ , , inimth, ilead] 
	  } 
      val [which (!is.na(change_sign), arr.ind = T)] <- 1
      totsign <- apply (change_sign, c(1,2), sum, na.rm = T)
      print (mean (change_sign, na.rm = T))
   }

   totval  <- apply (val,  c(1,2), sum)
   fracsign <- totsign / totval 
   print (paste ("Spatial mean of the fraction = ", mean (fracsign, na.rm = T)))
   fracsign [which (totval == 0, arr.ind = T)] <- -0.01
   
   if (typeobs == "real_obs") {   
      # Verzamel roosterpunten met waarnemingen
      # Hiervoor worden cirkels geplaatst
      #if (type_sim == "ref") {
		 ind_obs <- which (totval > 0, arr.ind = T)
      #} else if (type_sim == "hind") {
	  # ind_obs <- which (aperm (totval) > 0, arr.ind = T)
	  #}
      lon_obs <- lon [ind_obs[ , 1]]
      lat_obs <- lat [ind_obs[ , 2]]
      fracsign_obs <- fracsign [ind_obs]
      nobs <- length (fracsign_obs)
      col_obs <- vector (mode = "character", length = nobs)
   
      for (iobs in (1:nobs)) {
         dstat_thr <- bps - fracsign_obs[iobs]  
         indpos <- which (dstat_thr > 0)
         if (length (indpos) > 0) {
            icol <- indpos[1] - 1
            if (icol < 1) icol <- 1
         } else {
            icol <- nbreaks - 1
         }			
         col_obs[iobs] <- colnames[icol]
      }
   }
	  
   if (var != "dis") {
	  exttypeobs <- ""
   } else {
	  exttypeobs <- paste ("_", typeobs, sep = "")
   }
      
   fileout <- paste (dirout, "nmth_sign_", metric, "_", type_av, "_", 
                     i, exttypeobs, ".png", sep = "")
   
   if (type_sim == "ref") {
	  titlead <- ""
      title <- paste (spec_run, var, metric, sep = ", ") 
   } else if (type_sim == "hind") {
	  if (type_av == "all") {   
         titlead <- paste ("lead mth 1-", (nlead-1), sep = "")                  
      } else if (type_av == "change_lead") {   
         titlead <- paste ("tarmth", i, "-", (i+1), sep = "")                  
      } else if (type_av == "lead") {
         titlead <- paste ("lead month ", leadpap, sep = "")                  
      } else if (type_av == "target") {
         titlead <- paste ("target month ", i, sep = "")                  
      }
      title <- paste (spec_run, var, titlead, metric, sep = ", ") 
    } 
   plotvar <- fracsign
  
   if (typeobs == "real_obs") plotvar[] <- -0.01

   if (!toscreen) {
 	  png (file = fileout, width = w_image, height = h_image, pointsize = 12, 
           bg = "white")
   }
        
   par (cex.main = 1.6, cex.axis = 1.6, las = 1, mgp = c(2,1,0))
   par (xpd = F)

   image.plot (lon, lat, plotvar, breaks = bps, col = colnames,
               xlab = "", ylab = "", oldstyle = F, 
               smallplot = relc_sml, bigplot = relc_big, main = title,
               axis.args = list(cex.axis = 1.7))
   box (which = "plot", lwd = 3.0)
   map ("world", add = T)
  
   if (typeobs == "real_obs") {
      map ("rivers", col = "blue", lwd = 2, add = T)
	  points (lon_obs, lat_obs, col = col_obs, lwd = 2.0, cex = 1.5,
	          pch = 19)
   }

   # Voeg hokken toe voor de uitgelichte sub-regio's           
   if (nreg > 0) {
	  for (ireg in (1:nreg)) {
         xline <- xline_arr[ ,ireg]
	     yline <- yline_arr[ ,ireg]
	     if (regnames[ireg] == "Amazonia-Guianas" |
	         regnames[ireg] == "North Chile" |
	         regnames[ireg] == "Southeast South America Cfa") {
	        lines (xline, yline, lty = 1, lwd = 2)
	     }
	  }
   }
      
   if (toscreen) {
      print ("Enter something to continue")
      entval <- scan (file = "", what = "", nmax = 1)
   } else {
      dev.off ()
   }
      
}


