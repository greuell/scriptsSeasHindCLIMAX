# Dit programma plot jaarlijkse cycli
#    en is vermoedelijk achterhaald door plot_annual_cycle_v2.R (22-9-20)

rm(list=ls())	#remove all the variables from the workspace

library (ncdf4)
library (fields)
library (RColorBrewer)

library(devtools)
find_rtools()

domain <- "SA"
varname <- "Precip"
resolution <- "halfdegree"
period <- "1981-2015"
typestat <- "std"
nleads <- 7
model <- "SEAS5"
toscreen <- T

ncurves <- nleads + 1

datatypes <- c ("obs", "hdc")

if (varname == "Precip") {
   unit <- "mm/d"
   vartitle <- "precipitation"
}

if (domain == "SA") {
   regnames <- c ("South America", "Northeast Brazil", "coast Ecuador",
                  "Northwest Colombia", "North Brazil - Guyanas",
                  "South Brazil")
}
nregs <- length (regnames) - 1 

if (typestat == "avg") {
   beg_ytekst <- "Mean"
} else if (typestat == "std") {
   beg_ytekst <- "Stdev of annual values of"
} else if (typestat == "cfv") {
   beg_ytekst <- "Coeff. of variation of"
}

mthname <- c("Jan", "Feb", "Mar", "Apr", "May", "June",
             "July", "Aug", "Sep", "Oct", "Nov", "Dec")
mthname <- c("J", "F", "M", "A", "M", "J",
             "J", "A", "S", "O", "N", "D")
nmthyr <- length (mthname)
vararr <- array (NA, dim = c(ncurves, nmthyr))

lus_backup <- "/lustre/backup/WUR/ESG/greue002/"
dir_domain <- paste (lus_backup, "CLIMAX/", domain, "/", sep = "")

for (reg in (0:nregs)) {
	 
plot_title <- paste (model, regnames[(reg+1)], period, sep = "  ")

for (datatype in datatypes) {

   if (datatype == "obs") {
      forcing <- "WFDEI"
      forc_vers <- "aug2018"
      nc_type <- 1
   } else if (datatype == "hdc") {
      forcing <- "ecmwf"
      forc_vers <- "5"
      nc_type <- nleads 
   }

   dirbase <- paste (dir_domain, "forcing/", forcing, "_", forc_vers,
                  "/", resolution, "_noBC_climate/", sep = "")
   dirin    <- paste (dirbase, "data/", sep = "")
   if (datatype == "obs") {
	  dirplot <- paste (dirbase, "plots_anncyc/", sep = "")
      fileplot <- paste (dirplot, varname, "_ymon",
                         typestat, ".png", sep = "")
   }  

   for (lead in (0:(nc_type-1))) {

      if (datatype == "obs") {
         filein   <- paste (dirin,   varname, "_ymon", 
                            typestat, "_reg", reg, "mean.nc",  sep = "")
         varfile <- varname
         icurve <- 1
      } else if (datatype == "hdc") {
         filein   <- paste (dirin,   varname, "_lead", lead, "_ymon", 
                            typestat, "_reg", reg, "mean.nc",  sep = "")
         varfile <- paste (varname, "_mean", sep = "")
         icurve <- lead + 2
      }
      ncin <- nc_open (filein)

      vararr[icurve, ] <- ncvar_get(ncin, varid = varfile)
      nc_close(ncin)
      
      #if (datatype == "obs") {
      #   title <- paste (titlestat, " ", vartitle, " (", unit, ") ",
      #                   period, sep = "")
      #} else if (datatype == "hdc") {
      #   title <- paste (titlestat, " ", vartitle, " (", unit, ") ",
      #                   "lead ", lead, " ", period, sep = "")
      #}
      
   }   # End of the loop over the different lead months
   
}   # End of the loop over the datatypes  

y_tekst <- paste (beg_ytekst, " ", vartitle, " (", unit, ") ", sep = "")
x <- seq (1, nmthyr, length.out = nmthyr)
maxvar <- max (vararr)
indmin <- which (vararr == min(vararr), arr.ind = T)

# The palette with grey:
cbbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
xleg <- indmin[1,2]

for (curve in (1:ncurves)) { 

   varcurve <- vararr[curve, ]
   if (curve == 1) {
	  par (mar = c(3,5,3,1))
	  colcurve <- "black"
	  plot (varcurve, xaxt = 'n', xlab = "", ylim = c (0, maxvar),
	        ylab = y_tekst, cex.lab = 1.3, main = plot_title,
	        cex.main = 1.4, col = colcurve, type = "b", lwd = 2)
	  axis (at = x, labels = mthname, side = 1, cex.axis = 1.15)
	  tekstleg <- "OBS" 
	  #axis (at = x, labels = mthname, side = 3, cex.axis = 1.15) 
   } else {
	  colcurve <- cbbPalette[curve]
	  lines (varcurve, col = colcurve, type = "b", lwd = 2)
	  tekstleg <- paste ("L", (curve - 2), sep = "")
   }

   yleg <- (1 - (curve - 1) * 0.06) * maxvar   
   legend (xleg, yleg, tekstleg, bty = "n", lty = 1, lwd = 2, 
           col = colcurve, cex = 1.15, xjust = 0.5) 
   
}

if (toscreen) {
   print ("Enter something to continue")
   entval <- scan (file = "", what = "", nmax = 1) }

}   # End of the loop over the regions
