rm(list=ls())	#remove all the variables from the workspace

# This scripts selects (discharge) observation stations for calibration
#     from a netcdf file with observations.

# The selection procedure consists of two steps

# First, a selection is made based on:
#    1) the area of the catchment (less than a threshold value), 
#    2) the number of daily observations since the beginning 
#       of the WFDEI dataset, 1979-01-01 (more than a threshold value) and
#    3) the time delay due to upstream reservoirs
#      (less or equal to a threshold value).

# Secondly, the stations selected in the first step are split into two groups,
#    one for calibration itself (optizing parameters) and one for 
#    testing the calibration. In this step, a given fraction of the stations 
#    selected in the first step of the procedure is selected for 
#    calibration. To obtain an optimal spread of the selected stations,
#    this is done by maximizing the distance between the stations.

library (ncdf4)

# script parameters that can be adapted to specific wishes
maxArea  <- 150.0     # maximum of the catchment area (km2)
minND    <- 3652.0    # minimum number of days with observations
                      #    since 1979-01-01
maxDel   <- 0.0       # maximum of the time delay (days) due to upstream
                      #    reservoirs based on the GranD database and 
                      #    the assumption that reservoirs are empty
                      #    and must be filled completely before the
                      #    water flows out                                            
frCal    <- 0.5       # fraction of the stations selected during step 1
                      #    to be used for calibration
areaCell <- 25.0      # area of the model cells (km2)
iMeth    <- 2         # method for step 2 of the selection; can be 1 or 2. 
                      #    Both methods give similar results in terms
                      #    of the spatial spread of the selected stations.
                      #    Since method 1 is simpler, this should be the
                      #    default.
set.seed (2300)       # the number between brackets affects the choice of
                      #    random numbers in the second method (iMeth = 2). 
                      #    Changing this number affects the selection in detail
                      #    but the quality of the spread is unaffected. 
dirIn <- "/lustre/backup/WUR/ESG/greue002/dischargedata/netcdf/"
                      # directory containing the netcdf file
fileIn <- paste (dirIn, "Rhine_EqualArea_5x5km_AllStations_GRDCRhine+Ruben_DAY.nc", sep = "")
                      # name of the netcdf file
# end of adaptable parameters 

# Read variables from the netcdf file
ncIn <- nc_open (fileIn)
areaModel <- ncvar_get (ncIn, varid = "area_model")
areaObs   <- ncvar_get (ncIn, varid = "area_observed")
latStat   <- ncvar_get (ncIn, varid = "latitude_station")
lonStat   <- ncvar_get (ncIn, varid = "longitude_station")
nrDayObs  <- ncvar_get (ncIn, varid = "days_WFDEI_obs")
resDel    <- ncvar_get (ncIn, varid = "reservoir_delay")
river     <- ncvar_get (ncIn, varid = "river_name")
station   <- ncvar_get (ncIn, varid = "station_name")
nc_close (ncIn)

# The three dimensions of many of the arrays are two spatial coordinates
#    and the station dimension (different stations) in each grid cell
dimStats <- dim (station)
nx <- dimStats[1]
ny <- dimStats[2]
ns <- dimStats[3]

# Create 3-dimensional versions of some 2-dimensional arrays
areaMod3D <- array (NA, dim = c(nx, ny, ns))
resDel3D  <- array (NA, dim = c(nx, ny, ns))
for (is in (1:ns)) {
   areaMod3D[ , , is] <- areaModel
   resDel3D [ , , is] <- resDel
}

# STEP 1

# Determine the indices of the stations selected in the first step
#    of the procedure
indSel <- which (station != " " & areaObs <= maxArea &
                 areaMod3D <= maxArea & nrDayObs > minND & 
                 resDel3D == 0, arr.ind = T)
                 
# IN FACT ALREADY THE END OF STEP 1                 

# Determine the number of stations selected in the first (nSel) and
#    the second (nCal) step of the procedure
nSel <- dim (indSel) [1]
nCal <- floor (frCal * nSel)

# lat and lon coordinates of the observation stations
#    selected in step 1
latSel  <- latStat[indSel]                 
lonSel  <- lonStat[indSel] 
rivSel  <- river  [indSel]
statSel <- station[indSel]

# Compute the distances (in degrees) between the selected (step 1) stations
dist <- array (NA, dim = c(nSel, nSel))
for (iSel in (1:nSel)) {
for (jSel in (1:nSel)) {
   # Because we are only interested in the distance BETWEEN stations, 
   #     the distance of a station to itself is not computed (remains NA)
   if (jSel == iSel) next
   dLat <- latSel[iSel] - latSel[jSel]
   dLon <- lonSel[iSel] - lonSel[jSel]
   meanLat <- 0.5 * (latSel[iSel] + latSel[jSel])
   distSq <- dLat^2 + (dLon * cos (meanLat * pi / 180)) ^2
   dist[iSel, jSel] <- sqrt (distSq)
}
}

# STEP 2

# First (default) method to select station for calibration.
if (iMeth == 1) {
	
   nElim <- nSel - nCal        # number of stations that must be eliminated.
   
   # Some initialisations
   # Initially all stations are selected for calibration (maskInd = 1)
   distSimM <- dist
   maskInd <- vector (mode = "integer", length = nSel) 
   maskInd[] <- 1

   # Loop for eliminating stations by setting maskInd = 0
   for (iElim in (1:nElim)) {
	  # Determine indices of the 2 elements of the nSel x nSel array 
	  #    dist (distance between all selected stations) with
	  #    the smallest value 
      indMin <- which (distSimM == min (distSimM, na.rm = T) ,arr.ind = T)
      # Index of the two stations that are nearest to each other
      indSt1 <- indMin[1,1] 
      indSt2 <- indMin[1,2] 
      # One of these two stations ("twins") will be eliminated (index: indRem).  
      # This is, among the twins, the one having the nearest neighbour 
      #    after excluding the other twin.  
      distSimM[indSt1, indSt2] <- NA 
      distSimM[indSt2, indSt1] <- NA 
      secMinSt1 <- min (distSimM[indSt1, ], na.rm = T) 
      secMinSt2 <- min (distSimM[indSt2, ], na.rm = T)
      if (secMinSt1 < secMinSt2) {
	     indRem <- indSt1
      } else {
	     indRem <- indSt2
      }
      # Remove the eliminated station from the distance array and the mask.
      distSimM[indRem, ] <- NA
      distSimM[ ,indRem] <- NA
      maskInd[indRem] <- 0  
   }
   
   # These are the indices of the stations selected for calibration
   #    (maskInd = 1) and testing (maskInd = 0).
   indStCalM1  <- which (maskInd == 1)
   indStTestM1 <- which (maskInd == 0)

# Alternative method to select station for calibration.
} else if (iMeth == 2) {

   # Put stations selected in the step 1 in sequence using random numbers.
   ranStat <- runif (nSel)
   rSSort <- sort.int (ranStat, index.return = T)
   indStSo <- rSSort$ix

   # To begin, take the first nCal stations from the sequence 
   indStCalM2 <- indStSo[1:nCal]
   maskTestM2 <- vector (mode = "integer", length = nSel) 
   maskTestM2[] <- 0

   # Loop over the remaining stations.
   # In each loop the next station from the sequence is added to
   #    the nCal stations and one of the (nCal+1) stations is then
   #    eliminated based on distances between stations.
   for (iSt in ((nCal+1):nSel)) {
	  # add a station to the sequence
      indStTest <- c(indStCalM2, indStSo[iSt])
      # make an array of the distances between all the station in the sequence
      distTest <- dist[indStTest, indStTest]
	  # Determine indices of the 2 elements of distTest with
	  #    the smallest value 
      indMin <- which (distTest == min (distTest, na.rm = T) ,arr.ind = T)
      # One of these two stations ("twins") will be eliminated (index: indRem).  
      # This is, among the twins, the one having the nearest neighbour 
      #    after excluding the other twin.  
      indSt1 <- indMin[1,1] 
      indSt2 <- indMin[1,2] 
      distTest[indSt1, indSt2] <- NA 
      distTest[indSt2, indSt1] <- NA 
      secMinSt1 <- min (distTest[indSt1, ], na.rm = T)
      secMinSt2 <- min (distTest[indSt2, ], na.rm = T)
      if (secMinSt1 < secMinSt2) {
	     indRem <- indSt1
      } else {
	     indRem <- indSt2
      }
      # Eliminate the station with index indRem 
      indStCalM2 <- indStTest[-indRem]
      # and add it 
      maskTestM2[indStTest[indRem]] <- 1
      
   }

   indStTestM2 <- which (maskTestM2 == 1)
   
}

# END OF STEP 2

# Determine the average (over the stations selected for calibration)
#    of the distance to the nearest neighbour
minDist <- vector (mode = "double", length = nCal)
minDist[] <- NA

if (iMeth == 1) {
   indStCal  <- indStCalM1
   indStTest <- indStTestM1
} else if (iMeth == 2) {
   indStCal  <- indStCalM2
   indStTest <- indStTestM2
}

for (iCal in (1:nCal)) {
   distTest <- dist[indStCal, indStCal]
   distStat <- distTest[iCal, ]
   minDist[iCal] <- min (distStat, na.rm = T) * 111.111
}

meanMinDist <- mean (minDist)

# generate number for printing	
iCD <- which (!is.na (areaModel))
nCD <- length (iCD)
areaDom <- nCD * areaCell
areaCal <- sum (areaMod3D [indSel [indStCal, ]])
nCC <- areaCal / areaCell
frSim <- areaCal / areaDom

print (paste ("Number of catchments used for calibration: ", nCal, sep = ""))
print (paste ("Number of cells in domain: ", nCD, sep = ""))
print (paste ("Number of simulated cells during calibration: ", 
              nCC, sep = ""))
formFr = formatC (frSim, digits = 3, format = "f")              
print (paste ("Fraction of cells used for calibration: ", 
              formFr, sep = ""))
formMD = formatC (meanMinDist, digits = 1, format = "f")              
print (paste ("Mean minimum distance between stations used for calibration: ", 
              formMD, " km", sep = ""))
              
plot (lonSel[indStCal], latSel[indStCal])

# Output for the stations to be used for calibration:
# longitude, latitude, names of river and station and
#    3D indices in the input arrays (x, y and station)
lonStCal  <- lonSel [indStCal]              
latStCal  <- latSel [indStCal]              
rivStCal  <- rivSel [indStCal]              
nameStCal <- statSel[indStCal]
indCal <- indSel[indStCal, ]

# Output for the stations to be used for testing:
# longitude, latitude, names of river and station and
#    3D indices in the input arrays (x, y and station)
lonStTest  <- lonSel [indStTest]              
latStTest  <- latSel [indStTest]              
rivStTest  <- rivSel [indStTest]              
nameStTest <- statSel[indStTest]
indTest <- indSel[indStCal, ]


               
