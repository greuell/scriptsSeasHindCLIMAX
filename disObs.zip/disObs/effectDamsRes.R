# This script generates three arrays 
#    that quantify the effect of dams and reservoirs on discharge, 
#    for the grid of the hydrological model. 
#    These arrays can then be included in the netcdf file 
#    produced by make_netcdf_discharge.R 
# If the model has a lat-lon grid, some adaptations will have to be made. 

rm(list=ls())	#remove all the variables from the workspace

library (ncdf4)

dirLustre <- "/lustre/backup/WUR/ESG/greue002/"

domain <- "Rhine"

if (domain == "Rhine") {
   typeGrid  <- "km"        # "km" or "deg"
   resGridKm <- 5.0
   dirRoutNW  <- paste (dirLustre, "VIC/grids/LisfloodRhine/", sep = "")
   fileDom <- paste (dirRoutNW, "rhine_domain.nc", sep = "")
   fileRoutNW <- paste (dirRoutNW, "rhine_lisflood_routing_params.nc", 
                        sep = "")
   dirVICSim <- paste (dirLustre, "VIC/calibration/outputRefSim20210712/",
                       sep = "")
   fileVICSim <- paste (dirVICSim, "VIC-WUR_RHINE_5km_timeavg.nc", 
                        sep = "") 
}                  
                     
# Read the GRanD database
dirGR  <- paste (dirLustre, "GRanD_database/", sep = "")
# file version 1.1
#fileGR <- paste (dirGR    , "GRanD_v1p1.csv",  sep = "")
# file with reservoirs version 1.3 
#fileGR <- paste (dirGR    , "reservoirs_GRanD13.csv",  sep = "") 
# file with dams version 1.3 
fileGR <- paste (dirGR    , "dams_GRanD13.csv",  sep = "") 

dataGR <- read.csv (fileGR)
lonGR        <- dataGR$LONG_DD
latGR        <- dataGR$LAT_DD
yearGR       <- dataGR$YEAR
altYearGR    <- dataGR$ALT_YEAR
capMaxRes    <- dataGR$CAP_MCM
disGR        <- dataGR$DIS_AVG_LS
areaCatchRes <- dataGR$CATCH_SKM
mainUseRes   <- dataGR$MAIN_USE
xGR          <- dataGR$X
yGR          <- dataGR$Y

dimGR <- dim (dataGR)
nGR <- dimGR[1]

# Read the coordinates of the grid and the mask of the catchment
ncDom <- nc_open (fileDom)
mask   <- ncvar_get (ncDom, varid = "mask")
xDom   <- ncvar_get (ncDom, varid = "x")
yDom   <- ncvar_get (ncDom, varid = "y")
lonDom <- ncvar_get (ncDom, varid = "lon")
latDom <- ncvar_get (ncDom, varid = "lat")
nc_close (ncDom)

nx <- length (xDom)
ny <- length (yDom)

# Read routing network
# downstrCellNr: number of the downstream cell
ncRNW <- nc_open (fileRoutNW)
downstrCellNr <- ncvar_get (ncRNW, varid = "downstream")
cellNr        <- ncvar_get (ncRNW, varid = "downstream_id")
nc_close (ncRNW)

# Determine range of latitudes and longitudes of the grid
if (typeGrid == "km") resGridDeg <- resGridKm / 111.111	

minLonDom <- min (lonDom) - 0.5 * resGridDeg
maxLonDom <- max (lonDom) + 0.5 * resGridDeg
minLatDom <- min (latDom) - 0.5 * resGridDeg
maxLatDom <- max (latDom) + 0.5 * resGridDeg

# capRes: sum of capacities of all reservoirs in a grid cell
#         (Mm3)
# cumCap: cumulative capacity of all upstream reservoirs,
#         including those in the actual cell (Mm3)
# timeRes: mean time delay of water due to upstream reservoirs
#          (days) 
# meanYr: mean year of construction etc., weighted by capacity
capRes  <- array (NA, dim = c (nx,ny))
cumCap  <- array (NA, dim = c (nx,ny))
timeRes <- array (NA, dim = c (nx,ny))
meanYr  <- array (NA, dim = c (nx,ny))
indMask <- which (mask == 1, arr.ind = T)
capRes [indMask] <- 0
cumCap [indMask] <- 0
timeRes[indMask] <- 0
meanYr [indMask] <- 0

# Read the average discharge computed with a VIC reference simulation
ncVIC <- nc_open (fileVICSim)
avgDis <- ncvar_get (ncVIC, varid = "OUT_DISCHARGE")
nc_close (ncVIC)

# Determine cell number of outlet op the catchment
indMax <- which (avgDis == max(avgDis, na.rm = T), arr.ind = T)
cellMax <- cellNr[indMax]

# Loop through all dams and reservoirs
for (iGR in (1:nGR)) {

   lonDR <- lonGR[iGR]
   latDR <- latGR[iGR]

   # Dams outside the grid are eliminated anyway
   if (lonDR < minLonDom | lonDR > maxLonDom | 
       latDR < minLatDom | latDR > maxLatDom) next
       
   dLon <- lonDR - lonDom
   dLat <- latDR - latDom
   distDeg <- sqrt (dLat^2 + (dLon * cos (latDR * pi / 180)) ^2)
   distKm <- distDeg * 111.111
   minDistKm <- min (distKm)
   ind <- which (distKm == minDistKm, arr.ind = T)
   if (is.na (mask[ind])) next
   
   print (paste (lonDom[ind], latDom[ind], yearGR[iGR], capMaxRes[iGR], 
                 sep = "  "))
   
   capRes[ind] <- capRes[ind] + capMaxRes[iGR]                        
   cumCap[ind] <- cumCap[ind] + capMaxRes[iGR]
   meanYr[ind] <- meanYr[ind] + yearGR[iGR] * capMaxRes[iGR]                       
   while (cellNr[ind] != downstrCellNr[ind]) {
	  newInd <- which (cellNr == downstrCellNr[ind], arr.ind = T)
	  ind <- newInd
      cumCap[ind] <- cumCap[ind] + capMaxRes[iGR]                        
      meanYr[ind] <- meanYr[ind] + yearGR[iGR] * capMaxRes[iGR]
      if (meanYr[ind] == 0 | is.na (meanYr[ind])) {
		 stop ("No year for one of the reservoirs")
	  }                       
   }
   
   if (cellNr[ind] != cellMax) stop ("not outlet")
      
}

fact <- 1000000 / (24 * 3600) 
timeRes <- fact * cumCap / avgDis
meanYr <- meanYr / cumCap

fileOut <- paste (dirRoutNW, "effectRes_", domain, ".RData", sep = "") 
save (timeRes, meanYr, capRes, file = fileOut)
