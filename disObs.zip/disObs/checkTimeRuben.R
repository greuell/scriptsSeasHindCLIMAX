rm(list=ls())	#remove all the variables from the workspace

library (ncdf4)

dirLustre <- "/lustre/backup/WUR/ESG/greue002/"
dirObsRuben <- paste (dirLustre, "dischargedata/RhineCatchRuben/", sep = "")

fileObsHr <- paste (dirObsRuben, "discharge_obs_hr_appended.nc", sep = "") 
ncObsHr   <- nc_open (fileObsHr)
statIdsRb <- ncvar_get (ncObsHr, varid = "station_id")
statNames <- ncvar_get (ncObsHr, varid = "station_names")
statLons  <- ncvar_get (ncObsHr, varid = "lon")
statLats  <- ncvar_get (ncObsHr, varid = "lat")
dis       <- ncvar_get (ncObsHr, varid = "Qm")
time      <- ncvar_get (ncObsHr, varid = "time")
nc_close (ncObsHr)

iStat <- 699
disStat <- dis [iStat, ]

# The anchor is 1989-01-01 01:00:00
# The first leap year is 1992
# hrsLeapDay is the time at the beginning of 1992-02-29
nDayLeap <- (2000 - 1989) * 365 + 31 + 28
hrsLeapDay <- 24 * nDayLeap
timeBeg <- hrsLeapDay - 240
timeEnd <- hrsLeapDay + 240

#timeBeg0 <- (3 * 365 - 10) * 24
#timeEnd0 <- (4 * 365 + 10) * 24
#timeEnd <- timeBeg + 40

dev.new (width = 23, height = 7)

#timeBeg <- 3800 + timeBeg0
#timeEnd <- 4000 + timeBeg0
nYear <- 28
for (addYears in (1:27)) {
   timeBeg <- ((0 + addYears) * 365 - 12) * 24 
   timeEnd <- ((1 + addYears) * 365 + 12) * 24 
   print (paste (addYears, timeBeg, timeEnd, sep = "   "))
   plot (time [timeBeg:timeEnd],disStat [timeBeg:timeEnd])

		 print ("Enter something to continue")
         entval <- scan (file = "", what = "", nmax = 1) 

}

#plot (time)
nTime <- length (time)
timeDiff <- time[2:nTime] - time[1:(nTime-1)]

 


