rm(list=ls())	#remove all the variables from the workspace

library (ncdf4)

year <- 2015
iAS <- 14

dirLustre <- "/lustre/backup/WUR/ESG/greue002/"
dirData   <- "/lustre/backup/WUR/ESG/data/"

dirDisObs <- paste (dirLustre, "dischargedata/netcdf/", sep = "")
fileDisObs <- paste (dirDisObs, 
   "Rhine_EqualArea_5x5km__AllStations_GRDCRhine+Ruben_DAY.nc",
   sep = "")

ncDis <- nc_open (fileDisObs)
areaObs <- ncvar_get (ncDis, varid = "area_observed")
dimArea <- dim (areaObs)
nlon  <- dimArea [1]
nlat  <- dimArea [2]
nstat <- dimArea [3]

attTimeDis <- ncatt_get (ncDis, varid = "time")
unitTimeDis <- attTimeDis$units
RefDateDis  <- substr (unitTimeDis, 12, 21)
iRefDateDis <- as.numeric (as.Date (RefDateDis))

timeDis <- ncvar_get (ncDis, varid = "time")
timeRefDis <- timeDis + iRefDateDis
ntime <- length (timeDis)

statIdArr    <- ncvar_get (ncDis, varid = "station_identifier")
firstDateObs <- ncvar_get (ncDis, varid = "first_date_obs")
lastDateObs  <- ncvar_get (ncDis, varid = "last_date_obs")
resDelayArr  <- ncvar_get (ncDis, varid = "reservoir_delay")

areaObsSort <- sort (areaObs, index.return = T, na.last = T)

indStat <- areaObsSort$ix[iAS]
statId <- statIdArr[indStat]
indStatArr <- which (statIdArr == statId, arr.ind = T)

ilon  <- indStatArr [1]
ilat  <- indStatArr [2]
istat <- indStatArr [3]
disObs  <- ncvar_get (ncDis, varid = "dis", 
                      start = c (ilon, ilat, 1, istat),
                      count = c (1, 1, ntime, 1))
latObs  <- ncvar_get (ncDis, varid = "latitude_cell", 
                      start = c (ilon, ilat), count = c (1, 1))
lonObs  <- ncvar_get (ncDis, varid = "longitude_cell", 
                      start = c (ilon, ilat), count = c (1, 1))
statId    <- statIdArr    [ilon, ilat, istat]
firstDate <- firstDateObs [ilon, ilat, istat]
lastDate  <- lastDateObs  [ilon, ilat, istat]
areaStat  <- areaObs      [ilon, ilat, istat]
resDelay  <- resDelayArr  [ilon, ilat]

nc_close (ncDis)

indVal <- which (!is.na (disObs))
disObsVal <- disObs[indVal]

dirPrec <- paste (dirData, "CLIMATE_DATA/WATCH/WFDE5/daily/",
                  "Prec_daily_WFDE5_CRU+GPCC/", sep = "")

precYear <- c ()
timeWFDYear <- c ()

for (mth in (1:12)) {

   mthStr <- sprintf ("%02d", mth) 
   filePrec <- paste (dirPrec, "Prec_WFDE5_CRU+GPCC_", year, mthStr,
                      "_v2.0.nc", sep = "")                 
   ncPrec <- nc_open (filePrec)

   if (mth == 1) {
	  lonWFD <- ncvar_get (ncPrec, varid = "lon")
      latWFD <- ncvar_get (ncPrec, varid = "lat")
      dLon <- abs (lonWFD - lonObs[1])
      indLon <- which (dLon == min(dLon))
      dLat <- abs (latWFD - latObs[1])
      indLat <- which (dLat == min(dLat))

      attTimeWFD <- ncatt_get (ncPrec, varid = "time")
      unitTimeWFD <- attTimeWFD$units
      RefDateWFD  <- substr (unitTimeWFD, 12, 21)
      iRefDateWFD <- as.numeric (as.Date (RefDateWFD))
   }

   timeWFDMth <- ncvar_get (ncPrec, varid = "time")
   nTimeWFDMth <- length (timeWFDMth)
   timeWFDYear <- c (timeWFDYear, timeWFDMth)
   precMth  <- ncvar_get (ncPrec, varid = "Prec",
                          start = c (indLon, indLat, 1),
                          count = c (1, 1, nTimeWFDMth))
   precYear <- c (precYear, precMth)                       

   nc_close (ncPrec)
   
}

timeRefWFD <- timeWFDYear + iRefDateWFD
nTimeWFDYear <- length (timeWFDYear)

begTimeWFD <- timeRefWFD[1]
endTimeWFD <- timeRefWFD[nTimeWFDYear]

indBeg <- which (timeRefDis == begTimeWFD)
indEnd <- which (timeRefDis == endTimeWFD)

scPrec <- precYear / max (precYear, na.rm = T)
plot (scPrec, type = "b", col = "red")
disObsYear <- disObs [indBeg:indEnd]
scDisObs <- disObsYear / max (disObsYear, na.rm = T)
lines (scDisObs, type = "b", col = "blue")
 

