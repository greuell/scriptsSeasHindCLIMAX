# This script generates a netcdf file with discharge observations 
#    for the grid of the hydrological model, 
#    see the document greue002\M\Documents\afvoerdata\ A netcdf file with observations of discharge.docx 

rm(list=ls())	#remove all the variables from the workspace

library (ncdf4)

# Section: variables to be set before use
   select_stat <- "all"  # Selection criterion if a cell contains more than one suitable time series.
                         # catch_area:  largest catchment area
                         # length_time: longest
                         # all:         all time series are saved 
                           
   type_grid <- "Laea"   # Can be "latlon" (resolution must be specified (res_nc))
                         #    or "Laea" (Lambert azimuthal equal area)
   regionGrid <- "Rhine" # e.g. "Europe" or "Rhine"
   effectRes <- T        # add data regarding the effect of reservoirs
                           
   # Daily or monthly data
   daily <- T

   # Spatial resolution of the netcdf file (in degrees)
   #    Should normally be equal to the spatial resolution of the
   #    model simulations  
   res_nc <- 0.5
   # Resolution in km of the Lambert azimuthal equal area grid
   res_km <- 5.0

   thr_darea <- 0.15
   minYear <- 10

   # This determines the time dimension of the produced netcdf file
   beg_year_file <- 1806
   end_year_file <- 2021
   nyear <- end_year_file - beg_year_file + 1

   # Possible datasets: "ONS", "GRDC", "GRDCRhine", "RhineRuben"
   # ONS: 5 stations in Brazil. Data acquired from ONS, 
   #      the National Electricity System Operator, Brazil.
   # GRDC: data acquired from Global Runoff Data Centre (global data)
   # GRDCRhine: data acquired from Global Runoff Data Centre 
   #            (Rhine basin only)
   # RhineRuben: data for stations in the Rhine basin 
   #             provided by Ruben Imhoff and 
   #             collected by Bart van Osnabrugge (Deltares).
   # Check whether you load the latest version
   dataSets <- c ("GRDCRhine", "RhineRuben")
   # and give a string for the name of the output file
   #    in order to describe which datasets are included
   # e.g. "withONS", "GRDCOnly", "GRDCRhine", "Ruben"
   fileoutDS <- "GRDCRhine+Ruben"

   # Skip time series for grid cells that are already occupied
   #    by time series from another dataset.
   #    This is done to avoid duplicate records.
   #    if skipDoubles <- T, the dataset with the longest records
   #    should be put before the other datasets in dataSets <- c()
   skipDoubles <- T  

   # Limit dataset to stations in a part of the domain (basin <- T)
   #    and provide the name of the corresponding mask
   basin <- T
   file_basin <- "VIC/RhineBasin/RhineMask.nc"

# End of section with variables to be set before use

nmth <- 12
missVal <- -999.0
diskm_1deglat <- 111.111
# The maximum number of stations per cell 
#    (only relevant if select_stat = "all")
maxstat <- 10

if (daily) {
   minSam <- minYear * 365.25
} else {
   minSam <- minYear * nmth
}

# Small additional difference in area acceptable for matching station 
#    with grid cell of the routing network
eps_area <- 0.01

# Maximum length of strings (river and station names)
maxstrl <- 40

varname <- "dis"
fac_spec_dis <- 24 * 3600 / 1000

if (res_nc == 0.5) str_res = "halfdegr"
intResKm <- round (res_km)

if (select_stat == "catch_area") {
   sel_crit <- "LargestArea"
   des_sel_crit <- "largest catchment area"
} else if (select_stat == "length_time") {
   sel_crit <- "LongestTime"
   des_sel_crit <- "longest time series since 1979-01-01"
} else if (select_stat == "all") {
   sel_crit <- "AllStations"
   des_sel_crit <- "all stations in cell"
}
	
# Read files with coordinates and routing network
# area_model is the area of the catchment upstream from the cell
#    including the cell itself
# nrcells_model is the number of cells contributing to the 
#    discharge in the considered cell
dir_lustre <- "/lustre/backup/WUR/ESG/greue002/"
                   
if (type_grid == "latlon") {
	
   # Parameters for the grid                       
   lonmin <- -180 + 0.5 *res_nc
   lonmax <-  180 - 0.5 *res_nc
   lon <- seq (lonmin, lonmax, res_nc)
   nlon <- length (lon)
   latmin <-  -90 + 0.5 *res_nc
   latmax <-   90 - 0.5 *res_nc
   lat <- seq (latmin, latmax, res_nc)
   nlat <- length (lat)

   dir_grids <- paste (dir_lustre, "VIC/paramfiles/", sep = "")
   file_area_network <- paste (dir_grids, "area.RDS", sep = "")
   area_model <- readRDS (file_area_network)
   area_model <- 1.0e-6 * area_model
   file_nrcells_network <- paste (dir_grids, "accumulation.RDS", sep = "")
   nrcells_model <- readRDS (file_nrcells_network)

   # Initialize output arrays
   if (select_stat != "all") {
      statId      <- array (" ", dim = c(nlon, nlat))
      rivername   <- array (" ", dim = c(nlon, nlat))
      stationname <- array (" ", dim = c(nlon, nlat))
      latstat     <- array (NA,  dim = c(nlon, nlat))
      lonstat     <- array (NA,  dim = c(nlon, nlat))
      obsarea     <- array (NA,  dim = c(nlon, nlat))
      altstat     <- array (NA,  dim = c(nlon, nlat))
      nSamObs     <- array (0,   dim = c(nlon, nlat))
      nSamObsWF   <- array (0,   dim = c(nlon, nlat))
      BegDateObs  <- array (" ", dim = c(nlon, nlat))
      EndDateObs  <- array (" ", dim = c(nlon, nlat))
   } else {
      statId      <- array (" ", dim = c(nlon, nlat, maxstat))
      rivername   <- array (" ", dim = c(nlon, nlat, maxstat))
      stationname <- array (" ", dim = c(nlon, nlat, maxstat))
      latstat     <- array (NA,  dim = c(nlon, nlat, maxstat))
      lonstat     <- array (NA,  dim = c(nlon, nlat, maxstat))
      obsarea     <- array (NA,  dim = c(nlon, nlat, maxstat))
      altstat     <- array (NA,  dim = c(nlon, nlat, maxstat))
      nSamObs     <- array (0,   dim = c(nlon, nlat, maxstat))
      nSamObsWF   <- array (0,   dim = c(nlon, nlat, maxstat))
      BegDateObs  <- array (" ", dim = c(nlon, nlat, maxstat))
      EndDateObs  <- array (" ", dim = c(nlon, nlat, maxstat))
      nStat       <- array (0,   dim = c(nlon, nlat))
   }

} else if (type_grid == "Laea") {
	
   dir_grids <- paste (dir_lustre, "VIC/grids/Lisflood", regionGrid, 
                         "/", sep = "")
                         
   # Parameters for the grid
   # The first coordinate of the grid, e.g. in lon2D and grdcnr,
   #    is roughly in the east-west direction
   #    with the first element in the west, the last in the east
   # The second is roughly in the north-south direction                       
   #    with the first element in the south, the last in the north
   if (regionGrid == "Europe") {
	  file_latlon <- paste (dir_grids, "latlon.nc", sep = "")
   } else if (regionGrid == "Rhine") {
	  file_latlon <- paste (dir_grids, "rhine_domain.nc", sep = "")
   }
   nclatlon <- nc_open (file_latlon)
   lon2D <- ncvar_get (nclatlon, varid = "lon")
   lat2D <- ncvar_get (nclatlon, varid = "lat")
   if (basin) mask_basin <- ncvar_get (nclatlon, varid = "mask")
   lon2Dmin <- min (lon2D, na.rm = T)
   lon2Dmax <- max (lon2D, na.rm = T)
   lat2Dmin <- min (lat2D, na.rm = T)
   lat2Dmax <- max (lat2D, na.rm = T)
   dimcoor <- dim (lon2D)
   nx <- dimcoor[1]
   ny <- dimcoor[2]
   nc_close (nclatlon)
   
   if (regionGrid == "Europe") {
      file_area_network <- paste (dir_grids, "upArea_invertlat.nc", sep = "")
      varArea <- "upArea"
   } else if (regionGrid == "Rhine") {
      file_area_network <- paste (dir_grids, 
                                  "rhine_lisflood_routing_params.nc", 
                                  sep = "")
      varArea <- "upstream_area"
   }
   ncarea <- nc_open (file_area_network)
   area_model <- ncvar_get (ncarea, varid = varArea)
   area_model <- 1.0e-6 * area_model
   nrcells_model <- area_model / (res_km)^2
   nc_close (ncarea)

   # Read data related to reservoirs or initialize the corresponding arrays   
   if (effectRes) {
	  fileRes <- paste (dir_grids, "effectRes_", regionGrid, ".RData", 
	                    sep = "")
	  load (fileRes)
   } else {
      timeRes     <- array ("0", dim = c(nx, ny))	   
      meanYr      <- array ("0", dim = c(nx, ny))	   
      capRes      <- array ("0", dim = c(nx, ny))	   
   }

   # Initialize output arrays
   if (select_stat != "all") {
      statId      <- array (" ", dim = c(nx, ny))
      rivername   <- array (" ", dim = c(nx, ny))
      stationname <- array (" ", dim = c(nx, ny))
      latstat     <- array (NA,  dim = c(nx, ny))
      lonstat     <- array (NA,  dim = c(nx, ny))
      obsarea     <- array (NA,  dim = c(nx, ny))
      altstat     <- array (NA,  dim = c(nx, ny))
      nSamObs     <- array (0,   dim = c(nx, ny))
      nSamObsWF   <- array (0,   dim = c(nx, ny))
      BegDateObs  <- array (" ", dim = c(nx, ny))
      EndDateObs  <- array (" ", dim = c(nx, ny))
      nrDSArr     <- array (0,   dim = c(nx, ny))
   } else {
      statId      <- array (" ", dim = c(nx, ny, maxstat))
      rivername   <- array (" ", dim = c(nx, ny, maxstat))
      stationname <- array (" ", dim = c(nx, ny, maxstat))
      latstat     <- array (NA,  dim = c(nx, ny, maxstat))
      lonstat     <- array (NA,  dim = c(nx, ny, maxstat))
      obsarea     <- array (NA,  dim = c(nx, ny, maxstat))
      altstat     <- array (NA,  dim = c(nx, ny, maxstat))
      nSamObs     <- array (0,   dim = c(nx, ny, maxstat))
      nSamObsWF   <- array (0,   dim = c(nx, ny, maxstat))
      BegDateObs  <- array (" ", dim = c(nx, ny, maxstat))
      EndDateObs  <- array (" ", dim = c(nx, ny, maxstat))
      nrDSArr     <- array (0,   dim = c(nx, ny, maxstat))
      nStat       <- array (0,   dim = c(nx, ny))
   }
   
}

# Determine directory of the observations
#    and names of the files (one file per station) containing the data
#    (input of the script)
dir_obs_bas <- paste (dir_lustre, "dischargedata/", sep = "")
if (daily) {
   text_fr1 <- "DAY"
   text_fr2 <- "days"
} else {
   text_fr1 <- "MON"
   text_fr2 <- "months"
}

# Directory and file for output
dir_netcdf <- paste (dir_obs_bas, "netcdf/", sep = "")
if (type_grid == "latlon") {
   filenamepart_grid <- paste ("global_", type_grid, "_res_", 
                               str_res, sep = "")
} else if (type_grid == "Laea") {
   strRes <- paste (intResKm, "x", intResKm, "km", sep = "") 
   filenamepart_grid <- paste (regionGrid, "_EqualArea_", strRes,  
                               sep = "")
}
   
file_out <- paste (dir_netcdf, filenamepart_grid, "_", sel_crit, "_", 
                   fileoutDS, "_", text_fr1, ".nc", sep = "") 
                   
# Parameters for time dimension and
#    initialisation of vector with observations
time_unit <- paste ("days since ", beg_year_file, "-01-01 00:00:00", sep ="")
beg_date_file <- as.numeric(as.Date (paste (beg_year_file, "-01-01", sep = "")))
if (daily) {
   end_date_file <- as.numeric(as.Date (paste (end_year_file, "-12-31", sep = "")))
   ntime <- end_date_file - beg_date_file + 1
   time <- seq (0, (ntime-1), 1)
} else {
   ntime <- nyear * nmth
   strDate <- vector (mode = "character", length = ntime)
   itime <- 0
   for (year in (beg_year_file:end_year_file)) {
	  for (mth in (1:nmth)) {
		 if (mth < 10) {
			strmth <- paste ("0", mth, sep = "")
		 } else {
			strmth <- paste (mth)
		 }
		 itime <- itime + 1
		 strDate[itime] <- paste (year, "-", strmth, "-01", sep = "")
	   }
   }
   time <- as.numeric (as.Date (strDate)) - beg_date_file
}
		 		  
dis_vector <- vector (length = ntime)	   

# Create dimensions for netcdf file (output)
if (type_grid == "latlon") {
   firstdim <- ncdim_def ("lon", "degrees_east",  as.double(lon)) 
   secdim   <- ncdim_def ("lat", "degrees_north", as.double(lat))
} else if (type_grid == "Laea") {
   firstdim <- ncdim_def ("x", "column_number",  seq (1, nx, length.out = nx)) 
   secdim   <- ncdim_def ("y", "row_number",     seq (1, ny, length.out = ny)) 
} 
timedim  <- ncdim_def ("time", time_unit, as.double(time), calendar = "standard")
nchardim <- ncdim_def ("nchar", "", 1:maxstrl)
if (select_stat == "all") statdim <- ncdim_def ("stations", "number of", 
                                                seq (1, maxstat, length.out = maxstat))

# define variables
fillvalue <- NA
fillname  <- "-"
long_name <- "discharge"
if (select_stat != "all") {
   dis_def <- ncvar_def (varname, "m3/s", list (firstdim ,secdim, timedim),
                         fillvalue, long_name, 
                         chunksizes = c(1, 1, ntime), compression = 6, prec = "double")
   spec_dis_def <- ncvar_def ("specdis", "mm/d", list (firstdim ,secdim, timedim),
                         fillvalue, "specific discharge", 
                         chunksizes = c(1, 1, ntime), compression = 6, prec = "double")
} else {
   dis_def <- ncvar_def (varname, "m3/s", list (firstdim ,secdim, timedim, statdim),
                         fillvalue, long_name, 
                         chunksizes = c(1, 1, ntime, 1), compression = 6, prec = "double")
   spec_dis_def <- ncvar_def ("specdis", "mm/d", list (firstdim ,secdim, timedim, statdim),
                         fillvalue, "specific discharge", 
                         chunksizes = c(1, 1, ntime, 1), compression = 6, prec = "double")
}                         
                                            
# NOTE that if units is set to the empty string ("")
#    creation of a units attribute is suppressed and that the missing value
# is omitted, which suppresses creation of the missing value attribute
if (select_stat != "all") {
   statId_def   <- ncvar_def ("station_identifier", "",
                              list (nchardim, firstdim ,secdim), 
                              prec = "char")
   riv_def      <- ncvar_def ("river_name",   "", list (nchardim, firstdim, secdim),
                              prec = "char")
   stat_def     <- ncvar_def ("station_name", "", list (nchardim, firstdim, secdim),
                              prec = "char")
   beg_date_def <- ncvar_def ("first_date_obs", "", list (nchardim, firstdim, secdim),
                              prec = "char")
   end_date_def <- ncvar_def ("last_date_obs", "", list (nchardim, firstdim, secdim),
                              prec = "char")
   lat_stat_def <- ncvar_def ("latitude_station",  "degrees_north",
                              list (firstdim ,secdim), fillvalue, prec = "double")
   lon_stat_def <- ncvar_def ("longitude_station", "degrees_east",
                              list (firstdim ,secdim), fillvalue, prec = "double")
   obs_area_def <- ncvar_def ("area_observed", "km2",
                              list (firstdim ,secdim), fillvalue, 
                              "area_of_catchment_upstream_from_station",
                              prec = "double")
   alt_def      <- ncvar_def ("altitude", "m",
                              list (firstdim ,secdim), fillvalue, 
                              "altitude_above_sea_level",
                              prec = "double")
   nday_def     <- ncvar_def (paste (text_fr2, "_observations", sep = ""), " ",
                              list (firstdim ,secdim), 0, 
                              paste ("number_of_", text_fr2, "_with_observations", 
                                     sep = ""),
                              prec = "integer")
   nday_WF_def  <- ncvar_def (paste (text_fr2, "_WFDEI_obs", sep = ""), " ",
                              list (firstdim ,secdim), 0, 
                              paste ("number_of_", text_fr2, 
                                     "_with_observations_since_1979-01-01", sep = ""),
                              prec = "integer")
   mod_area_def <- ncvar_def ("area_model", "km2",
                              list (firstdim ,secdim), fillvalue, 
                              "area_of_catchment_upstream_from_and_including_grid_cell",
                              prec = "double")
} else {
   statId_def   <- ncvar_def ("station_identifier", "",
                              list (nchardim, firstdim, secdim, statdim), 
                              prec = "char")
   riv_def      <- ncvar_def ("river_name",   "", list (nchardim, firstdim, secdim, statdim),
                              prec = "char")
   stat_def     <- ncvar_def ("station_name", "", list (nchardim, firstdim, secdim, statdim),
                              prec = "char")
   beg_date_def <- ncvar_def ("first_date_obs", "", list (nchardim, firstdim, secdim, statdim),
                              prec = "char")
   end_date_def <- ncvar_def ("last_date_obs", "", list (nchardim, firstdim, secdim, statdim),
                              prec = "char")
   lat_stat_def <- ncvar_def ("latitude_station",  "degrees_north",
                              list (firstdim, secdim, statdim), fillvalue, prec = "double")
   lon_stat_def <- ncvar_def ("longitude_station", "degrees_east",
                              list (firstdim, secdim, statdim), fillvalue, prec = "double")
   obs_area_def <- ncvar_def ("area_observed", "km2",
                              list (firstdim, secdim, statdim), fillvalue, 
                              "area_of_catchment_upstream_from_station",
                              prec = "double")
   alt_def      <- ncvar_def ("altitude", "m",
                              list (firstdim, secdim, statdim), fillvalue, 
                              "altitude_above_sea_level",
                              prec = "double")
   nday_def     <- ncvar_def (paste (text_fr2, "_observations", sep = ""), " ",
                              list (firstdim, secdim, statdim), 0, 
                              paste ("number_of_", text_fr2, "_with_observations", 
                                     sep = ""),
                              prec = "integer")
   nday_WF_def  <- ncvar_def (paste (text_fr2, "_WFDEI_obs", sep = ""), " ",
                              list (firstdim, secdim, statdim), 0, 
                              paste ("number_of_", text_fr2, 
                                     "_with_observations_since_1979-01-01", sep = ""),
                              prec = "integer")
   mod_area_def <- ncvar_def ("area_model", "km2",
                              list (firstdim, secdim), fillvalue, 
                              "area_of_catchment_upstream_from_and_including_grid_cell",
                              prec = "double")
   nstat_def    <- ncvar_def ("number of stations", " ",
                              list (firstdim, secdim), 0, 
                              "number of stations in grid cell",
                              prec = "integer")
}

# Define the variables related to reservoirs and their effect on the routing.
# These are derived from the GranD database, which is not linked
#    to the observational datasets.
# Hence the station dimension (number of stations per cell) is omitted. 
time_res_def    <- ncvar_def ("reservoir_delay", "day",
                              list (firstdim ,secdim), fillvalue, 
                              paste ("average of time delays due to all upstream reservoirs, ",
                                     "computed as their maximum capacity ",
                                     "divided by the average streamflow", sep = "") ,
                              prec = "double")
yr_res_def      <- ncvar_def ("year_reservoir", " ",
                              list (firstdim ,secdim), fillvalue, 
                              "weighted, average year of construction of upstream reservoirs",
                              prec = "double")
cap_res_def     <- ncvar_def ("capacity_reservoirs", "Mm3",
                              list (firstdim ,secdim), fillvalue, 
                              "summed capacity of reservoirs in each cell",
                              prec = "double")
                           
if (type_grid == "Laea") {
   lat_grid_def <- ncvar_def ("latitude_cell",  "degrees_north",
                              list (firstdim ,secdim), fillvalue, prec = "double")
   lon_grid_def <- ncvar_def ("longitude_cell",  "degrees_east",
                              list (firstdim ,secdim), fillvalue, prec = "double")
}
	                     
system (paste ("rm -f ", file_out, sep = ""))
if (type_grid == "latlon") {
   ncout <- nc_create (file_out, list(dis_def, spec_dis_def, statId_def, riv_def, 
                                      stat_def, beg_date_def, end_date_def, 
                                      lat_stat_def, lon_stat_def, 
                                      obs_area_def, alt_def, nday_def, nday_WF_def,
                                      mod_area_def, nstat_def, time_res_def, yr_res_def,
                                      cap_res_def), 
                                      force_v4 = T)
} else if (type_grid == "Laea") {
   ncout <- nc_create (file_out, list(dis_def, spec_dis_def, statId_def, riv_def, 
                                      stat_def, beg_date_def, end_date_def,
                                      lat_stat_def, lon_stat_def, 
                                      obs_area_def, alt_def, nday_def, nday_WF_def,
                                      mod_area_def, nstat_def, time_res_def, yr_res_def,
                                      cap_res_def, lat_grid_def, lon_grid_def), 
                                      force_v4 = T)
}
                                   
nfiles_miss_meta    <- 0
nfiles_nobs_inc     <- 0
nfiles_too_short    <- 0
nfiles_noarea_match <- 0
nfiles_double_cell  <- 0
nfiles_not_coorgrid <- 0
nfiles_not_areagrid <- 0
nfiles_doubles      <- 0
nfiles_all_datasets <- 0

for (dataSet in dataSets) {                                   

   # If each station has its own file, EachStatFile = T
   # nrDS is the number of the dataset
   if (dataSet == "GRDC") {
	  dir_statdata <- paste (dir_obs_bas, "stationdata_Mar19/globalDATA_",
                             text_fr1, "/", sep = "")
      eachStatFile <- T 
      nrDS <- 1                      
   } else if (dataSet == "GRDCRhine") {
	  dir_statdata <- paste (dir_obs_bas, "stationdata_Apr21/RhineDATA_",
                             text_fr1, "/", sep = "")
      eachStatFile <- T                       
      nrDS <- 2                      
   } else if (dataSet == "ONS") {
	  dir_statdata <- paste (dir_obs_bas, "ONS_Brazil/", sep = "")
      eachStatFile <- T                       
      nrDS <- 3                      
   } else if (dataSet == "RhineRuben") {
	  dir_statdata <- paste (dir_obs_bas, "RhineCatchRuben/", sep = "")
	  fileStatData <- paste (dir_statdata, "stationsRhineRuben.rds",
	                         sep = "")
	  load (fileStatData)
      eachStatFile <- F                             
      nrDS <- 4                      
   }
   
   if (eachStatFile) {
      files_stations <- list.files (dir_statdata)
      nStats <- length (files_stations)
   } else {
	  nStats <- length (statIds)
	  nobs <- dim (disObs) [2]

	  str_beg_file <- as.Date (date [1] / 86400, 
	                           origin = "1970-01-01")
	  str_year_fo <- substr (str_beg_file, 1,  4)
	  str_mth_fo  <- substr (str_beg_file, 6,  7)
	  str_day_fo  <- substr (str_beg_file, 9, 10)

	  str_end_file <- as.Date (date [nobs]  / 86400, 
	                           origin = "1970-01-01")
	  str_year_lo <- substr (str_end_file, 1,  4)
	  str_mth_lo  <- substr (str_end_file, 6,  7)
	  str_day_lo  <- substr (str_end_file, 9, 10)
	                           
	  missVal <- NA
   }

   nfiles_all_datasets <- nfiles_all_datasets + nStats
   print (paste ("Total number of stations in ", dataSet, " dataset : ",
                  nStats, sep = ""))
                  
   for (iStat in (1:nStats)) {
	   
	  if (eachStatFile) {
		 file <- files_stations[iStat]
	     filestat <- paste (dir_statdata, file, sep = "")
	  }  
		 
      #print (paste ("Station ", iStat, sep = ""))
	 
      if (dataSet == "GRDC" | dataSet == "GRDCRhine") {
		  
		 # The encoding specification is needed because the files contain
         #    an otherwise unreadable character in the line specifying
         #    the catchment area
	     file_cont <- readLines (filestat, encoding = "latin1")

         # Read meta data of the station
	     str_missval <- substr (file_cont[5], 34, 42)
         missval_file <- as.numeric (str_missval)

         if (missval_file != missVal) {
            stop (paste ("The missing value of the file is not equal to ",
	                     missVal, sep = ""))
	     }
	   
	     str_grdc <- substr (file_cont[9], 23, 32)
	     str_grdc <- gsub (" ", "", str_grdc)
	     statIdhere <- paste ("GRDC_", str_grdc, sep = "")
	   
         strl <- nchar (file_cont[10], type = "chars")
	     rivernamehere <- substr (file_cont[10], 26, strl)
	   
         strl <- nchar (file_cont[11], type = "chars")
	     stationnamehere <- substr (file_cont[11], 26, strl)
	   
	     str_lat <- substr (file_cont[13], 21, 29)
	     latstathere <- as.numeric (str_lat)

	     str_lon <- substr (file_cont[14], 21, 29)
	     lonstathere <- as.numeric (str_lon)
	   
	     if (type_grid == "Laea") {
		    if ((lonstathere < lon2Dmin | lonstathere > lon2Dmax) |
	            (latstathere < lat2Dmin | latstathere > lat2Dmax)) {
               nfiles_not_coorgrid <- nfiles_not_coorgrid + 1
               next
	        }
	     }
		     
	     str_area <- substr (file_cont[15], 27, 41)
	     obsareahere <- as.numeric (str_area)
	      
	     # Some GRDC stations have negative catchment area
	     if (obsareahere <= 0 | latstathere == 90.0) {
		    nfiles_miss_meta <- nfiles_miss_meta + 1
		    next
	     }
	   
	     str_alt <- substr (file_cont[16], 22, 31)
	     altstathere <- as.numeric (str_alt)

         # nobs is the number of days according to the meta data in the
         #    station file
         if (dataSet == "GRDC") {
	 	    dline <- 0
         } else if (dataSet == "GRDCRhine") {
			dline <- 1
		 }

	     if (daily) {
		    str_nobs <- substr (file_cont [(34+dline)], 14, 19)
		    begLineMin1 <- 36 + dline
	     } else {
		    str_nobs <- substr (file_cont [(36+dline)], 14, 17)
		    begLineMin1 <- 38 + dline
	     }
         nobs <- strtoi (str_nobs)
	   
         dis_obs <- vector (length = nobs)
	      
          # Read data	   
	     for (iobs in (1:nobs)) {
		    line <- begLineMin1 + iobs
	        data_line <- file_cont [line]
	        if (iobs == 1) {
	           str_year_fo <- substr (data_line,  1, 4 )
		       str_mth_fo  <- substr (data_line,  6, 7 )
		       str_day_fo  <- substr (data_line,  9, 10)
		    } else if (iobs == nobs) {
		       str_year_lo <- substr (data_line,  1, 4 )
		       str_mth_lo  <- substr (data_line,  6, 7 )
		       str_day_lo  <- substr (data_line,  9, 10)
		    }
	        if (daily) {
			   dis_obs[iobs]  <- as.double (substr (data_line, 18, 28))
		    # Preference is given to the calculated value
	        } else {
			   disObsOri <- as.double (substr (data_line, 18, 28))
			   disObsCal <- as.double (substr (data_line, 30, 40))
			   if (disObsCal != missVal) {
			      dis_obs[iobs] <- disObsCal
	           } else {
			      dis_obs[iobs] <- disObsOri
			   }
		    } 
	     }
	   
      } else if (dataSet == "ONS") {
		   
	     ONS_cont <- scan (filestat, what = "character")
	     statIdhere <- "ONS"
	     rivernamehere <- ONS_cont[2]  
	     stationnamehere <- ONS_cont[4]  
	     latstathere <- as.numeric (ONS_cont[6])  
	     lonstathere <- as.numeric (ONS_cont[8])
         obsareahere <- as.numeric (ONS_cont[10])
	     altstathere <- missVal
	      
	     nItemsONS <- length (ONS_cont)
	     nMetaONS <- 10
	     nYearONS <- (nItemsONS - nMetaONS) / (nmth + 1)
	     str_year_fo <- ONS_cont[nMetaONS+1]  
	     str_mth_fo  <- "01"
	     indLY <- nMetaONS + (nYearONS - 1) * (nmth + 1) + 1  
         str_year_lo <- ONS_cont[indLY]  
	     str_mth_lo  <- "12"
	      
	     nobs <- nYearONS * nmth
	   	 dis_obs <- vector (length = nobs)
	   	 for (iYear in (1:nYearONS)) {
			indBegSrc <- nMetaONS + 2 + ((iYear - 1) * (nmth + 1))
		    indEndSrc <- nMetaONS + (iYear * (nmth + 1))
			indBegDes <- (iYear - 1) * nmth + 1
		    indEndDes <- iYear * nmth 
		    dis_obs[indBegDes:indEndDes] <- as.double (ONS_cont[indBegSrc:indEndSrc])
		 } 

      } else if (dataSet == "RhineRuben") {
		  
		  statIdhere <- paste ("Ruben_", statIds[iStat], sep = "")
		  rivernamehere <- " "
		  stationnamehere <- statNames[iStat]
		  latstathere <- statLats[iStat] 
		  lonstathere <- statLons[iStat] 
		  obsareahere <- areaCatch[iStat]
	      altstathere <- missVal               # The elevation is missing
	      dis_obs <- disObs[iStat, ]           # Missing values are NA
	      
	      indValRR <- which (!is.na (dis_obs))
	      nVRR <- length (indValRR)
	      nSamObsHere <- nVRR
	      indFirst <- indValRR[1]
	      indLast  <- indValRR[nVRR]
	      BegDateObsHere <- as.character (as.Date (date [indFirst] / 86400, 
	                                 origin = "1970-01-01"))
	      EndDateObsHere <- as.character (as.Date (date [indLast]  / 86400, 
	                                 origin = "1970-01-01")) 
	                                 
      }		   
		   		   
	   if (!is.na (missVal)) {
	      nSamObsHere <- length (which (dis_obs != missVal))
	      # Replace missing values by NA
	      id_miss <- which (dis_obs == missVal)
	      dis_obs[id_miss] <- NA
	   }
	   
       # Compute number of expected samples	   
       # Days since 1970-01-01 of first and last observation
       # str_beg_date_obs is a character string
       # as.Date converts the string to a double
       # (which looks with print exactly equal to the string, e.g. "1960-01-01"
       # as.numeric converts the double to an integer,
       # namely the number of days since 1970-01-01
       if (daily) {
		  str_beg_date_obs <- paste (str_year_fo, "-", str_mth_fo, "-", 
                                     str_day_fo, sep = "")
          beg_date_obs <- as.numeric (as.Date (str_beg_date_obs))                 
          str_end_date_obs <- paste (str_year_lo, "-", str_mth_lo, "-", 
                                     str_day_lo, sep = "")
          end_date_obs <- as.numeric (as.Date (str_end_date_obs))
          nSamExp <- end_date_obs - beg_date_obs + 1
          if (dataSet == "GRDC" | dataSet == "GRDCRhine") {
		     BegDateObsHere <- str_beg_date_obs
		     EndDateObsHere <- str_end_date_obs
		  }
       } else {
          year_fo <- strtoi (str_year_fo)
          beg_str_mth_fo <- substr (str_mth_fo, 1, 1)
          if (beg_str_mth_fo == "0") {
			 mth_fo  <- strtoi (substr (str_mth_fo, 2, 2))
		  } else {
			 mth_fo  <- strtoi (str_mth_fo)
		  }
          year_lo <- strtoi (str_year_lo)
          beg_str_mth_lo <- substr (str_mth_lo, 1, 1)
          if (beg_str_mth_lo == "0") {
			 mth_lo  <- strtoi (substr (str_mth_lo, 2, 2))
		  } else {
			 mth_lo  <- strtoi (str_mth_lo)
		  }
          nSamExp <- nmth * (year_lo - year_fo + 1) - (mth_fo - 1) - (12 - mth_lo)
       }
       
       if (nobs != nSamExp) {
          nfiles_nobs_inc <- nfiles_nobs_inc + 1
          next
	   }
	   
	   # Compute number of observations since 1979-01-01
       if (daily) {
          beg_date_WFDEI <- as.numeric (as.Date ("1979-01-01"))
		  iBeg_WFDEI <- max ((beg_date_WFDEI - beg_date_obs + 1), 1)
       } else {
		  iBeg_WFDEI <- nmth * (1979 - year_fo) - (mth_fo - 1) + 1
		  iBeg_WFDEI <- max (iBeg_WFDEI, 1)
	   }
       obs_WFDEI <- dis_obs [iBeg_WFDEI:nobs]
       nSamObsWFHere <- length (which (! is.na(obs_WFDEI)))
	   
	   # If the area of the catchment is NA, the file is skipped
	   if (is.na (obsareahere)) {
		  nfiles_miss_meta <- nfiles_miss_meta + 1
		  next
	   }
	   
       # Time series shorter than minSam are not considered
	   if (nSamObsWFHere < minSam) {
		  nfiles_too_short <- nfiles_too_short + 1
		  next
	   }
	   
       # Determine the model grid cell in which the station is located
       # First without correction
       if (type_grid == "latlon") {
		  iy_raw <- round ((latstathere - latmin) / res_nc + 1)
	      ix_raw <- round ((lonstathere - lonmin) / res_nc + 1)
       } else if (type_grid == "Laea") {
		  dlatmax <- 0.55 * res_km / diskm_1deglat
		  indcells2D <- which (abs(latstathere - lat2D) < dlatmax, arr.ind = T)
		  latselall <- lat2D[indcells2D]
		  lonselall <- lon2D[indcells2D]
		  dlonmax <- 0.55 * res_km / (diskm_1deglat * cos ((latstathere / 180 * pi))) 
		  indcells1D <- which (abs(lonstathere - lonselall) < dlonmax, arr.ind = T)
		  nselc <- length (indcells1D)
		  if (nselc == 0) {
		     nfiles_not_coorgrid <- nfiles_not_coorgrid + 1
		     next
		  }
		  distsel <- vector (mode = "double", length = nselc)
		  for (isel in (1:nselc)) {
			 indsel <- indcells1D[isel]
			 latsel <- latselall[indsel]
			 lonsel <- lonselall[indsel]
			 distsel[isel] <- diskm_1deglat * sqrt ((latsel - latstathere)^2 + 
			            ((lonsel - lonstathere) * cos (latstathere / 180 * pi))^2)
		  }
		  indmindist <- which (distsel == min(distsel))
		  if (distsel[indmindist] > (1.1 * sqrt(2) * 0.5 * res_km)) {
		     stop ("Something wrong with selection grid cell")
		  }
		  ind1D <- indcells1D[indmindist]
		  ix_raw <- indcells2D[ind1D,1]
		  iy_raw <- indcells2D[ind1D,2]
	   }

       # If the dataset is limited to a part of the domain,
       #    it is checked whether the station could be in that part	   
	   if (basin) {
		  mask_ar_stat <- mask_basin[(ix_raw-1):(ix_raw+1),(iy_raw-1):(iy_raw+1)]
		  sum_mask_stat <- sum (mask_ar_stat, na.rm = T)
		  if (sum_mask_stat == 0) next
	   }
	   
	   loc_area_model_arr <- area_model[(ix_raw-1):(ix_raw+1), (iy_raw-1):(iy_raw+1)]
	   loc_nr_cells_arr <- nrcells_model[(ix_raw-1):(ix_raw+1), (iy_raw-1):(iy_raw+1)]

       # For the Lisflood grid, stations can be within grid
       #    but the assigned grid cell and its surrounding cells
       #    may have no information about the catchment area
       if (type_grid == "Laea") {
		  indval <- which (!is.na (loc_area_model_arr))
		  nval <- length (indval)
		  if (nval == 0) {
		     nfiles_not_areagrid <- nfiles_not_areagrid + 1
		     next
		  }
	   }
			  	   
	   # A correction to the location of the grid cell might be applied
	   abs_diff_area <- abs((area_model[ix_raw,iy_raw] - obsareahere))
	   rel_diff_area <- abs_diff_area / obsareahere
	   if (type_grid == "latlon") {
	      area_grid_cell <- (res_nc * diskm_1deglat)^2 * cos ((lat[iy_raw] / 180 * pi))
	   } else if (type_grid == "Laea") {
	      area_grid_cell <- res_km^2
	   }
	   
 	   # Under three conditions the grid cell location is not shifted
	   # 1) If the model catchment area of the central grid cell agrees within
	   #    a fraction of thr_darea with the catchment area of the observation.
	   # 2) If the catchment area of the observation is unknown. In that case
	   #    the observation will be discarded. 
	   # 3) If the model catchment area of the central grid cell agrees within
	   #    the area of the central grid cell with the catchment area of the observation.
	   if (!is.na(area_model[ix_raw,iy_raw]) &
	       (rel_diff_area < thr_darea | is.na(obsareahere) | abs_diff_area < area_grid_cell)) {
		  iy <- iy_raw
		  ix <- ix_raw
		  
	   # If the central cell does not match, 
       #    all eight model cells surrounding the central cell are considered
       # Among these cells the one with the smallest absolute difference 
	   #    of its catchment area with the catchment area of the observations
	   #    is selected.
	   } else {
		  abs_diff_area_arr <- abs(loc_area_model_arr - obsareahere)
		  rel_diff_area_arr <- abs_diff_area_arr / obsareahere
		  
		  min_abs_diff <- min (abs_diff_area_arr, na.rm = T)
		  min_rel_diff <- min (rel_diff_area_arr, na.rm = T)
		  indmin_abs <- which (abs_diff_area_arr == min_abs_diff, arr.ind = T)
		  
          # If the relative difference is larger than thr_area AND
          #    the absolute difference larger than the area of the central
          #    model grid cell, the observations are discarded		  
		  if (min_abs_diff >= area_grid_cell & min_rel_diff > thr_darea) {
			 nfiles_noarea_match <- nfiles_noarea_match + 1 
			 next
		  } else {

             # For the cell with the smallest difference in catchment area 
             #    with that of the observations,
             #    the number of cells (nr_cells_min) in its catchment is determined 
             
             # If there are multiple cells with minimum difference in area
             #    the first one is selected
             if (length (indmin_abs) > 2) {
				indmin_sel <- indmin_abs[1, ]
			 } else {            
				indmin_sel <- indmin_abs
             }
		     plon <- ix_raw + indmin_sel[1] - 2
			 plat <- iy_raw + indmin_sel[2] - 2
		     nr_cells_min <- nrcells_model[plon,plat]

             # And among the cells surrounding the central cell,
             #    all cells with nr_cells_min in the catchment are selected			
		     indmin_nrc <- which (loc_nr_cells_arr == nr_cells_min, arr.ind = T)
				
			 # If more than one cell matches best,
			 #    the one at the shortest distance from the station is selected
			 nmin_nrc <- length (indmin_nrc) / 2
			 if (nmin_nrc == 1) {
				ix <- ix_raw + indmin_nrc[1] - 2
			    iy <- iy_raw + indmin_nrc[2] - 2
		     } else {
			    dist_norm <- array (NA, dim = c(3, 3))
				for (jx in (1:3)) {
				for (jy in (1:3)) {
				   if (type_grid == "latlon") {
				      loncell <- lon[(ix_raw + jx - 2)]
				      latcell <- lat[(iy_raw + jy - 2)]
				   } else if (type_grid == "Laea") {
				      loncell <- lon2D[(ix_raw + jx - 2),(iy_raw + jy - 2)]
				      latcell <- lat2D[(ix_raw + jx - 2),(iy_raw + jy - 2)]
				   }
				   dislon_norm <- cos ((latstathere / 180 * pi)) *
				                  (loncell - lonstathere)
				   dislat_norm <- latcell - latstathere
				   dist_norm[jx,jy] <- sqrt (dislon_norm^2 + dislat_norm^2)
				}
				}
				   
				distmin <- vector (length = nmin_nrc)
				for (imin in (1:nmin_nrc)) {
				   kx <- indmin_nrc[imin,1]
				   ky <- indmin_nrc[imin,2]
				   distmin[imin] <- dist_norm[kx,ky]
				}
				inddist <- which.min(distmin)
				   
			    ix <- ix_raw + indmin_nrc[inddist,1] - 2
			    iy <- iy_raw + indmin_nrc[inddist,2] - 2
				if (type_grid == "latlon") {
			       area_grid_cell <- (res_nc * diskm_1deglat)^2 * cos ((lat[iy] / 180 * pi))
				} else if (type_grid == "Laea") {
			       area_grid_cell <- area_grid_cell
			    }

		     }   # End of the if statement for number of minima (one or more)
	      }      # End of the if statement for looking whether one of the
	             #    surrounding cells matches (yes of no)
	   }         # End of the if statement for matching with the central cell
	             #    or with one of the surrounding cells

       # If the dataset will be limited to a part of the domain,
       #    it is checked whether the station is in that part
	   if (basin & mask_basin[ix,iy] != 1) next
	   
       # Check for errors
	   rel_diff_print <- abs((area_model[ix,iy] - obsareahere) / obsareahere)
	   abs_diff_print <- abs((area_model[ix,iy] - obsareahere) / area_grid_cell)
	   abs_diff_iy <- abs(iy - iy_raw)
	   abs_diff_ix <- abs(ix - ix_raw)
	   if (abs_diff_iy > 1 | abs_diff_ix > 1 |
	       (rel_diff_print > thr_darea & abs_diff_print > (1 + eps_area))) {
           print (paste (stationnamehere, rel_diff_print, abs_diff_print,
                         abs_diff_iy, abs_diff_ix))
           stop ("check this")             
       }
       
       if (select_stat != "all") {
		  # Each cell can contain only one time series of observations
          # nSamObsWF[ix,iy] > 0 is used to check whether the grid cell
          #    already contains a time series
          if (nSamObsWF[ix,iy] > 0) {
		     nfiles_double_cell <- nfiles_double_cell + 1 
		     if (select_stat == "catch_area") {
			    if (obsarea[ix,iy] > obsareahere) next
		     } else if (select_stat == "length_time") {
			    if (nSamObsWF[ix,iy] > nSamObsWFHere) next
			    if (nSamObsWF[ix,iy] == nSamObsWFHere) {
				   if (nSamObs[ix,iy] > nSamObsHere) next
		        }
		     }
	      }
	   } else {
		  isSoFar <- nStat[ix,iy]
		  # If the cell is already occupied by a time series
		  #    from another dataset, the present dataset is skipped
		  if (skipDoubles & isSoFar >= 1) {
		     if (nrDS != nrDSArr[ix,iy,isSoFar]) {
				nfiles_doubles <- nfiles_doubles + 1
				next
			 }
		  }
		  nStat[ix,iy]<- nStat[ix,iy] + 1
		  is <- nStat[ix,iy]
		  if (is > maxstat) {
			 print (paste ("In one of the cells the number of stations ",
			               "exceeds the maximum (maxstat)", sep = ""))
		  } 
	   }
	   
	   if (daily) {
		  ibeg <- beg_date_obs - beg_date_file + 1
	      iend <- end_date_obs - beg_date_file + 1
	   } else {
		  ibeg <- nmth * (year_fo - beg_year_file) + mth_fo
		  iend <- nmth * (year_lo - beg_year_file) + mth_lo
	   }
	   
	   dis_vector[] <- NA
	   dis_vector[ibeg:iend] <- dis_obs
	      
       spec_dis_vector <- dis_vector / obsareahere * fac_spec_dis
	      
	   meansd <- mean (spec_dis_vector, na.rm = T)
	   
	   if (meansd <= 0) stop ("Mean specific discharge equal to zero or negative")

       if ((length (dis_vector)) != ntime) stop ("sadk")
       
       print (paste (iStat, ix, iy, is, nSamObsHere, BegDateObsHere,
                     EndDateObsHere, stationnamehere, sep = "   "))

	   if (select_stat != "all") {
		  ncvar_put (ncout, varname, dis_vector, start = c(ix, iy, 1),
	                 count = c(1, 1, ntime))
          ncvar_put (ncout, "specdis", spec_dis_vector, start = c(ix, iy, 1),
	                 count = c(1, 1, ntime))
          latstat[ix,iy]     <- latstathere
          lonstat[ix,iy]     <- lonstathere
          statId[ix,iy]      <- statIdhere
          rivername[ix,iy]   <- rivernamehere
          stationname[ix,iy] <- stationnamehere
          obsarea[ix,iy]     <- obsareahere
          altstat[ix,iy]     <- altstathere
          nSamObs[ix,iy]     <- nSamObsHere
          nSamObsWF[ix,iy]   <- nSamObsWFHere
          BegDateObs[ix,iy]  <- BegDateObsHere
          EndDateObs[ix,iy]  <- EndDateObsHere
          nrDSArr[ix,iy]     <- nrDS
	   } else {
		  ncvar_put (ncout, varname, dis_vector, start = c(ix, iy, 1, is),
	                 count = c(1, 1, ntime, 1))
          ncvar_put (ncout, "specdis", spec_dis_vector, start = c(ix, iy, 1, is),
	                 count = c(1, 1, ntime, 1))
          latstat[ix,iy,is]     <- latstathere
          lonstat[ix,iy,is]     <- lonstathere
          statId[ix,iy,is]      <- statIdhere
          rivername[ix,iy,is]   <- rivernamehere
          stationname[ix,iy,is] <- stationnamehere
          obsarea[ix,iy,is]     <- obsareahere
          altstat[ix,iy,is]     <- altstathere
          nSamObs[ix,iy,is]     <- nSamObsHere
          nSamObsWF[ix,iy,is]   <- nSamObsWFHere
          BegDateObs[ix,iy,is]  <- BegDateObsHere
          EndDateObs[ix,iy,is]  <- EndDateObsHere
          nrDSArr[ix,iy,is]     <- nrDS
       }
       
   }   # End of the loop over the stations in a data set
   
}   # End of the loop over the data sets

ind_co <- which (nSamObsWF > 0)
nRecFile <- length (ind_co)
indCells <- which (nStat > 0)
nCellsOcc <- length (indCells)

print (paste ("Number of stations in all datasets = ", 
              nfiles_all_datasets, sep = ""))
print (paste ("Number of stations outside the domain given by ",
              "the file with the 2D latlon coordinates = ", 
              nfiles_not_coorgrid, sep = ""))
print (paste ("Number of stations outside the domain given by ",
              "the file with the model catchment area = ", 
              nfiles_not_areagrid, sep = ""))
print (paste ("Number of stations with missing essential meta data = ", 
              nfiles_miss_meta, sep = ""))
print (paste ("Number of stations with issue about ",
              "number of observations = ", 
              nfiles_nobs_inc, sep = ""))
print (paste ("Number of stations with a record that is ",
              "too short = ", 
              nfiles_too_short, sep = ""))
print (paste ("Number of stations with double records = ", 
              nfiles_doubles, sep = ""))
print (paste ("Number of stations for which the observation area ", 
              "does not match with the area of any of the selected ",
              "model grid cells: ", nfiles_noarea_match, sep = ""))
print (paste ("Number of stations that are removed ",
              "because another station in the same cell ",
              "is preferred ", nfiles_double_cell, sep = ""))
print (paste ("Number of records in the file ", 
              nRecFile, sep = ""))
print (paste ("Number of cells in the file occupied by observations ", 
              nCellsOcc, sep = ""))
              
checkNFiles  <- nfiles_all_datasets - 
                nfiles_not_coorgrid -
                nfiles_not_areagrid -
                nfiles_miss_meta -             
                nfiles_nobs_inc - 
                nfiles_too_short - 
                nfiles_doubles -
                nfiles_noarea_match - 
                nfiles_double_cell -
                nRecFile
if (checkNFiles == 0) {
   print ("The file budget is equal to zero")
} else {   
   print ("The file budget is not equal to zero")
}

# The next ncvar_put commands are computationally relatively cheap
ncvar_put (ncout, "station_identifier", statId)
ncvar_put (ncout, "river_name", rivername)
ncvar_put (ncout, "station_name", stationname)
ncvar_put (ncout, "latitude_station", latstat)
ncvar_put (ncout, "longitude_station", lonstat)
ncvar_put (ncout, "area_observed", obsarea)
ncvar_put (ncout, "altitude", altstat)
ncvar_put (ncout, paste (text_fr2, "_observations", sep = ""), nSamObs)
ncvar_put (ncout, paste (text_fr2, "_WFDEI_obs", sep = ""), nSamObsWF)
ncvar_put (ncout, "area_model", area_model)
ncvar_put (ncout, "number of stations", nStat)
ncvar_put (ncout, "reservoir_delay", timeRes)
ncvar_put (ncout, "year_reservoir", meanYr)
ncvar_put (ncout, "capacity_reservoirs", capRes)
ncvar_put (ncout, "first_date_obs", BegDateObs)
ncvar_put (ncout, "last_date_obs", EndDateObs)

if (type_grid == "Laea") {
   ncvar_put (ncout, "latitude_cell",  lat2D)
   ncvar_put (ncout, "longitude_cell", lon2D)
}
	
str_rsl <- format (res_nc, digits = 2)

ncatt_put (ncout, 0, "Title", paste ("NetCDF-4 file at ", str_rsl, " by ", 
                     str_rsl," degrees", sep = ""))
ncatt_put (ncout, 0, "Data_source", "GRDC data, acquired ...")
ncatt_put (ncout, 0, "Period", paste (beg_year_file, end_year_file, 
                     sep = "-"))
ncatt_put (ncout, 0, "Conditions_for_use", paste ("The user must be ",
                     "conscious of the conditions of use of the data, ",
                     "see.", sep = ""))
ncatt_put (ncout, 0, "Method", "See ...")
if (select_stat != "all") {
   ncatt_put (ncout, 0, "Selection", paste ("Based on", des_sel_crit, sep = " "))
} else {
   ncatt_put (ncout, 0, "Selection", des_sel_crit)
}
ncatt_put (ncout, 0, "Date_file", paste ("File created on ", 
                     Sys.Date(), sep = ""))
ncatt_put (ncout, 0, "Contact", "wouter.greuell@wur.nl")
ncatt_put (ncout, 0, "Institute", paste ("Water Systems and Global ",
                     "Change (WSG) group; Wageningen University and ",
                     "Research", sep = ""))
	               
# close the netcdf-file, writing data to disk
nc_close (ncout)                    
