#!/bin/bash
#SBATCH -N 1                            ## Ensure that all cores are on one machine
#SBATCH --comment=5160957624            ## Is het WUR projectnummer (5160957624 = CLIMAX)
#SBATCH --time=5000                     ## Na deze (echte) tijd in minuten wordt job in ieder geval beeindigd
#SBATCH --mem=4048                      ## Is het maximale geheugen in MByte; als de computer meer nodig heeft, beeindigt hij de job
#SBATCH --ntasks=1                      ## Aantal processoren
#SBATCH --output=output_%j.txt
#SBATCH --error=output_%j.txt
#SBATCH --job-name=downloadERSST            
#SBATCH --qos=std                       ## Low kan eruitgegooid worden

Download='n'

BegYr=1979
EndYr=2019
nMth=12
FactRes=5

DirOut='/lustre/backup/WUR/ESG/greue002/ERSST/v5/'
cd $DirOut

if [ $Download == "y" ]
then

   yr=$BegYr

   while [ $yr -le $EndYr ]; do
      nm=1

      while [ $nm -le $nMth ]; do

         if [ $nm -lt 10 ]; then
            nm=0$nm
         fi

         wget ftp://ftp.ncdc.noaa.gov/pub/data/cmb/ersst/v5/netcdf/ersst.v5.$yr$nm.nc -O $DirOut'ERSST_v5_'$yr'_'$nm.nc
      
         nm=`expr $nm + 1`

      done

   yr=`expr $yr + 1`

   done
   
fi

# Create one file with all the data
AllFiles=`ls /lustre/backup/WUR/ESG/greue002/ERSST/v5/ERSST*`
FileOrigRes='FileOrigRes.nc'

# Aggregate the fields to lower resolution
cdo -O -a mergetime $AllFiles $FileOrigRes
FileDestRes='FileDestRes.nc'
cdo gridboxavg,$FactRes,$FactRes $FileOrigRes $FileDestRes

# Select the Niño 3.4 region
FileNino34='FileNino34.nc'
cdo sellonlatbox,190,240,-5,5 $FileOrigRes $FileNino34 

# Average over the Niño 3.4 region
FileAvgNino34='FileAvgNino34.nc'
cdo fldavg $FileNino34 $FileAvgNino34 

