#!/bin/bash
#SBATCH -N 1                            ## Ensure that all cores are on one machine
#SBATCH --comment=5120776-01            ## Is het WUR projectnummer (5120867-01 = Euporias; 5120776-01 = IMPACT2C)
#SBATCH --time=5000                     ## Na deze (echte) tijd in minuten wordt job in ieder geval beeindigd
#SBATCH --mem=4048                      ## Is het maximale geheugen in MByte; als de computer meer nodig heeft, beeindigt hij de job
#SBATCH --ntasks=1                      ## Aantal processoren
#SBATCH --output=output_%j.txt
#SBATCH --error=error_output_%j.txt
#SBATCH --job-name=rearr_modout            
#SBATCH --qos=std                       ## Low kan eruitgegooid worden

dir_all_mod_out=dir_all_mod_out_ph
dir_mod_out=dir_mod_out_ph
finiyear=finiyear_ph
liniyear=liniyear_ph
str_dur=str_dur_ph
fmem=fmem_ph
lmem=lmem_ph

allfiles=''

for imem in $(seq $fmem $lmem); do

   if [ "$imem" -lt "10" ]
   then
      str_mem='0'$imem
   else
      str_mem=$imem
   fi

   for iniyear in $(seq $finiyear $liniyear); do
      for inimth in $(seq 1 12); do
 
         echo $imem   $inimth   $iniyear

         # Bepaal variabelen voor filenamen en parameters     
         if [ "$inimth" -lt "10" ]
         then
            str_inimth='0'$inimth
         else
            str_inimth=$inimth
         fi
         
         dir_sim='ini'$iniyear$str_inimth'_dur'$str_dur'_E'$str_mem
         dir_mod_out_mth=$dir_mod_out$dir_sim'/data/'
         file_in_dir='Output_'$dir_sim'.'$iniyear'-'$str_inimth'-01.nc'
         file_in=$dir_mod_out_mth$file_in_dir
         allfiles=$allfiles' '$file_in
         
      done

   done
   
   file_combined_data=$dir_all_mod_out'all_daily_data.nc'
   file_monthly_data=$dir_all_mod_out'all_monthly_data.nc'
   cdo -O mergetime $allfiles $file_combined_data
   cdo monavg $file_combined_data $file_monthly_data
   
done

         
