rm(list=ls())	#remove all the variables from the workspace

library (ncdf4)

# The following input variables must be set
InclHind <- T          # Include hindcasts, yes or no
variables <- c ("evap", "prec", "dis")
                       # Run this script for these variables
inpObsDaily <- F       # Daily (T) or monthly (F) input data
# End of the input variables to be set

# First and last year of the Gleam data,
#    which is a global dataset of quasi-observations of
#    evapotranspiration. 
FyGleam <- 1980
LyGleam <- 2018

domain <- "domain_ph"
hydmodel <- "hydmodel_ph"
HydModResol <- HydModResol_ph
HydModResolStr <- "HydModResolStr_ph"

forcing <- "forcing_ph"
forc_vers <- forc_vers_ph
spec_run <- "spec_run_ph"
typerun <- "typerun_ph"
biascorr <- "biascorr_ph"
version <- "version_ph"

forcing_ref <- "forcing_ref_ph"
forc_vers_ref <- "forc_vers_ref_ph"
spec_run_ref <- "spec_run_ref_ph"

fmem <- fmem_ph
lmem <- lmem_ph
nlead <- dur_ph     # Neem dur over

nmth <- 12
fac_sp_dis <- 24 * 3600 / 1000
NDayMth <- c (31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)

nmem <- (lmem - fmem) + 1

dirlustregreue002 <- "/lustre/backup/WUR/ESG/greue002/"

for (varname in variables) {
	
# For the time being, it is easier to read precipitation for
#    hindcasts and reference simulation from the VIC output
if (varname == "dis") {
   typeData <- "hydModel"
} else if (varname == "evap") {
   typeData <- "hydModel"
} else if (varname == "prec") {
   typeData <- "hydModel"
} else if (varname == "Precip") {
   typeData <- "forcing"
}

DirOutBase <- paste (dirlustregreue002, "verif_seas/", domain, 
                     "/", varname, "stations/", forcing, "_", forc_vers, "/", 
                     forcing_ref, "_", forc_vers_ref, "_", biascorr, "_",
                     version, "_", sep = "")
if (InclHind) {
   DirOut <- paste (DirOutBase, "InclHind/", sep = "")
} else {
   DirOut <- paste (DirOutBase, "ExclHind/", sep = "")	
}                     
system (paste ("mkdir -p ", DirOut, sep = ""))

if (InclHind) {
   if (typeData == "hydModel") {
      dirHind <- paste (dirlustregreue002, "CLIMAX/", domain, "/", hydmodel, "/",
                 forcing, "_", forc_vers, "/", HydModResolStr, "_",
                 spec_run, "_SH_", biascorr, "_", version,
                 "/monthly_leadtime/", sep = "")
   } else if (typeData == "forcing") {
      dirHind <- paste (dirlustregreue002, "CLIMAX/", domain, "/forcing/",
                 forcing, "_", forc_vers, "/", HydModResolStr, "_",
                 biascorr, "_monthly_leadtime/", sep = "")
   }
}

if (typeData == "hydModel") {
   dirRSim <- paste (dirlustregreue002, "CLIMAX/", domain, "/", hydmodel, "/",
              forcing_ref, "_", forc_vers_ref, "/", HydModResolStr, "_",
              spec_run_ref, "_SREF_", biascorr, "_", version, "/", sep = "")
} else if (typeData == "forcing") {
   dirRSim <- paste (dirlustregreue002, "CLIMAX/", domain, "/forcing/",
              forcing_ref, "_", forc_vers_ref, "/", HydModResolStr, "_",
              biascorr, "_daily/data/", sep = "")
}
           
# A single file with simulations must be opened
#    to determine the boundaries of the domain          
if (typeData == "hydModel") {
   fileRSim <- paste (dirRSim, "allmonthavg.nc", sep = "")
} else if (typeData == "forcing") {
   fileRSim <- paste (dirRSim, varname, "_monthmean.nc", sep = "")
}


ncRSim <- nc_open (fileRSim)
lonsim <- ncvar_get (ncRSim, varid = "lon")
latsim <- ncvar_get (ncRSim, varid = "lat")
nc_close (ncRSim)

lonminSim <- min (lonsim)
lonmaxSim <- max (lonsim)
latminSim <- min (latsim)
latmaxSim <- max (latsim)
nLonSim <- length (lonsim)
nLatSim <- length (latsim)

# Open file with discharge observations
# This is also needed when datasets for other variables than discharge
#    are to be produced because the cells with discharge observations
#    must be determined with the discharge observation file
dirObsDis <- paste (dirlustregreue002, "dischargedata/netcdf/", sep = "")
if (inpObsDaily) {
   fileObsDis <- paste (dirObsDis, "global_latlon_res_halfdegr_LargestArea_GRDConly_DAY.nc", sep = "")
} else {
   fileObsDis <- paste (dirObsDis, "global_latlon_res_halfdegr_LargestArea_withONS_MON.nc", sep = "")
}
ncObsDis <- nc_open (fileObsDis)

# Read co-ordinates from the file with discharge observations
lonObsDis <- ncvar_get (ncObsDis, varid = "lon")
latObsDis <- ncvar_get (ncObsDis, varid = "lat")
nLonObsDis <- length (lonObsDis)
nLatObsDis <- length (latObsDis)

# Read arrays with meta data of the discharge observations 
stationnameAll <- ncvar_get (ncObsDis, varid = "station_name")
latstatAll     <- ncvar_get (ncObsDis, varid = "latitude_station")
lonstatAll     <- ncvar_get (ncObsDis, varid = "longitude_station")
areaobsAll     <- ncvar_get (ncObsDis, varid = "area_observed")
areamodAll     <- ncvar_get (ncObsDis, varid = "area_model")
rivernameAll   <- ncvar_get (ncObsDis, varid = "river_name")

# Create 2D-arrays of the lon and the lat vector
lonObsDis2D <- array (NA, dim = c(nLonObsDis, nLatObsDis))
latObsDis2D <- array (NA, dim = c(nLonObsDis, nLatObsDis))
for (ilat in (1:nLatObsDis)) lonObsDis2D[ , ilat] <- lonObsDis
for (ilon in (1:nLonObsDis)) latObsDis2D[ilon, ]  <- latObsDis

# Select the grid cells with observations within the domain
indStatDom <- which (rivernameAll != " " &
                     lonObsDis2D >= lonminSim & lonObsDis2D <= lonmaxSim &
                     latObsDis2D >= latminSim & latObsDis2D <= latmaxSim, 
                     arr.ind = T)
nstat <- length (indStatDom[ ,1])

# Read time axis of the observations and extract date info                     
timeobs <- ncvar_get (ncObsDis, varid = "time")
ntimesobs <- length (timeobs)
timeunit <- ncatt_get (ncObsDis, "time", attname = "units")
begyear <- substr (timeunit$value, 12, 15)
begmth  <- substr (timeunit$value, 17, 18)
begday  <- substr (timeunit$value, 20, 21)
begdate <- paste (begyear, begmth, begday, sep = "-")
begDate <- as.Date (begdate)
if (inpObsDaily) {
   allDates <- seq (from = begDate, length = ntimesobs, by = "days")
} else {
   allDates <- seq (from = begDate, length = ntimesobs, by = "months")
}
allyears <- substr (allDates, 1, 4)
allmths  <- substr (allDates, 6, 7)

# Read GLEAM data
if (varname == "evap") {
   DirGleam <- paste (dirlustregreue002, "GLEAM/v3.3a/monthly/", sep = "")
   FileGleam <- paste (DirGleam, "E_", FyGleam, "_", LyGleam,
                       "_GLEAM_v3.3a_MO_", domain,
                       "_", HydModResolStr, ".nc", sep = "")
   NcEvapObs <- nc_open (FileGleam)
   EvapObsRead <- ncvar_get (NcEvapObs, varid = "E")
   TimeEvapObs <- ncvar_get (NcEvapObs, varid = "time")
   nc_close (NcEvapObs)
   # In de Gleam data staan lon en lat verwisseld
   EvapObsInv <- aperm (EvapObsRead, c(2,1,3))
   # en begint lat in het noorden
   EvapObs <- EvapObsInv
   for (iLat in (1:nLatSim)) {
	  iLatInv <- nLatSim - iLat + 1
	  EvapObs[ , iLat, ] <- EvapObsInv[ , iLatInv, ]
   }
   nTimesEvapObs <- length (TimeEvapObs)
}

# Read hindcasts
if (InclHind) {
	
   for (lead in (0:(nlead-1))) {

      print (paste ("lead = ", lead, sep = ""))
   	
      for (imem in (fmem:lmem)) {
	   
	     print (paste ("member = ", imem, sep = ""))
	     jmem <- imem - fmem + 1
	   
	     if (imem < 10) {
		    strmem <- paste ("0", imem, sep = "")
	     } else {
            strmem <- paste (imem)
         }

         if (typeData == "hydModel") {
            fileHind <- paste (dirHind, varname, "mean_monthly_", hydmodel, "_",
                              forcing, "_", forc_vers, "_", domain, "_",
                              biascorr, "_E", strmem, "_lead", lead, ".nc4",
                              sep = "")
            varRead <- varname                 
         } else if (typeData == "forcing") {
            fileHind <- paste (dirHind, varname, "mean_monthly_", 
                               forcing, "_", forc_vers, "_", forcing, "_", 
                               forc_vers, "_", domain, "_",
                               biascorr, "_E", strmem, "_lead", lead, ".nc4",
                               sep = "")
            varRead <- paste (varname, "_mean", sep = "")                 
         }
      
         fileHindabs <- paste (dirHind, "fileHindabs.nc4", sep = "")
         system (paste ("rm -f ", fileHindabs))
         cdo_comm <- paste ("cdo -a -s copy" , fileHind, fileHindabs, sep = " ")
         system (cdo_comm)
                        
         ncHind <- nc_open (fileHindabs)

         varHind <- ncvar_get (ncHind, varid = varRead)
         dimSim <- dim (varHind)
      
         if (lead == 0 & imem == fmem) {
		    varHindAll <- array (NA, dim = c (nlead, nmem, dimSim))
		    timeHindAll <- array (NA, dim = c (nlead, dimSim[3]))
	     }
	     varHindAll[(lead+1), jmem, , , ] <- varHind
      
         # Dates of the hindcasts and their number	  
         if (imem == fmem) {

            timeHind <- ncvar_get (ncHind, varid = "time")
            nTimesHind <- length (timeHind)
            timeHindAll[(lead+1), ] <- timeHind

            if (lead == 0) {
			   firstHindTime <- timeHind[1]
               fYearHind <- floor (firstHindTime / 10000)
			   LastHindTime <- timeHind[nTimesHind]
               lYearHind <- floor (LastHindTime / 10000)
            }

         }
      
         nc_close (ncHind)
      
      }   # End of the loop over the members
   
   }   # End of the loop over the lead months

}   # End read hindcasts

# Read the reference simulation

ncRSim <- nc_open (fileRSim)
varRSim <- ncvar_get (ncRSim, varid = varname)
timeRSim <- ncvar_get (ncRSim, varid = "time")
timeunitRSim <- ncatt_get (ncRSim, "time", attname = "units")
nc_close (ncRSim)

nTimesRSim <- length (timeRSim)
begyearRSim <- substr (timeunitRSim$value, 12, 15)
begmthRSim  <- substr (timeunitRSim$value, 17, 18)
begdayRSim  <- substr (timeunitRSim$value, 20, 21)
begdateRSim <- paste (begyearRSim, begmthRSim, begdayRSim, sep = "-")
begDateRSim <- as.Date (begdateRSim)
# De met het volgende statement gegeneerde data zijn steeds op de 
#    17e of 18e van de maand
allDatesRSim <-  as.Date (timeRSim, origin = begDateRSim)

fYearRSim <- strtoi (substr (allDatesRSim[1], 1, 4))
fMthRSim  <- substr (allDatesRSim[1], 6, 7)
lYearRSim <- strtoi (substr (allDatesRSim[nTimesRSim], 1, 4))
lMthRSim  <- substr (allDatesRSim[nTimesRSim], 6, 7)
if (fMthRSim != "01" | lMthRSim != "12") stop ("Something
   wrong with time axis of the reference simulation")
   
# Read indices of all cells contributing to discharge
fileIndCC <- paste (dirlustregreue002, "CLIMAX/", domain, "/static_data/",
                    "indCC_", HydModResolStr, "_", domain, ".RDS", sep = "")
indCC <- readRDS (file = fileIndCC)
# and read the number of contributing cells
fileNrCells <- paste (dirlustregreue002, "CLIMAX/", domain, "/static_data/",
                      "nrCells_", HydModResolStr, "_", domain, ".RDS", sep = "")
nrCells <- readRDS (file = fileNrCells)

riversOut   <- vector (mode = "character", length = nstat)
stationsOut <- vector (mode = "character", length = nstat)
latstatOut  <- vector (mode = "double",    length = nstat)
lonstatOut  <- vector (mode = "double",    length = nstat)
areaobsOut  <- vector (mode = "double",    length = nstat)
areamodOut  <- vector (mode = "double",    length = nstat)
riversOut[]   <- " "
stationsOut[] <- " "
latstatOut[]  <- NA
lonstatOut[]  <- NA
areaobsOut[]  <- NA
areamodOut[]  <- NA
iOut <- 0

for (istat in (1:nstat)) { 
	
   indstat <- indStatDom[istat, ]
   iLonObsDis <- indstat[1]                     
   iLatObsDis <- indstat[2]
   
   DisObsIn <- ncvar_get (ncObsDis, varid = "dis", start = c(iLonObsDis, iLatObsDis, 1), 
                          count = c(1, 1, -1))
                        
   rivername   <- rivernameAll  [iLonObsDis, iLatObsDis]
   stationname <- stationnameAll[iLonObsDis, iLatObsDis]
   latstat     <- latstatAll    [iLonObsDis, iLatObsDis]
   lonstat     <- lonstatAll    [iLonObsDis, iLatObsDis]
   areaobs     <- areaobsAll    [iLonObsDis, iLatObsDis]
   areamod     <- areamodAll    [iLonObsDis, iLatObsDis]

   rivername <- gsub ("Ö", "O", rivername)
   stationname <- gsub ("Ö", "O", stationname)
	    
   # Bepaal het aantal geldige observaties, het eerste en laatste jaar
   #    en het aantal jaren met geldige observaties 
   indvalobs <- which (!is.na (DisObsIn))
   nvalobs <- length (indvalobs)
   FyDisObs <- strtoi (allyears[indvalobs[1]])                        
   LyDisObs <- strtoi (allyears[indvalobs[nvalobs]])
   nyear_obs <- LyDisObs - FyDisObs + 1
   NSamDisObs <- nyear_obs * nmth
   
   if (InclHind) {
      fyear_both <- max (fYearHind, FyDisObs)
      lyear_both <- min (lYearHind, LyDisObs)
      nyear_olap <- lyear_both - fyear_both + 1
      if (nyear_olap < 10) next
   } else {
	  nYDisObs <- LyDisObs - FyDisObs + 1
      if (nYDisObs < 10) next
   }
	  
   if (inpObsDaily) {
      # Bereken maandgemiddeldes
      df <- data.frame (DisObsIn, allmths, allyears)
      # na.pass: if any day during a months has DisObsIn = NA,
      #          the monthly mean = NA
      dfobsmth <- aggregate ( DisObsIn ~ allmths + allyears, df, mean,
                              na.action = na.pass)
      DisObsMthAll <- dfobsmth$varobs
   } else {
	  DisObsMthAll <- DisObsIn
   }
   indbeg <- (FyDisObs - strtoi (begyear)) * nmth + 1
   indend <- (LyDisObs + 1 - strtoi (begyear)) * nmth 
   DisObsMth <- DisObsMthAll[indbeg:indend]
   # De arrays DisObsMthArr en HindMthArr hebben in de dimensie jaren
   #    ruimte voor de jaren van het eerste tot het laatste jaar 
   #    van de afvoerwaarnemingen
   DisObsMthArr  <- array (data = DisObsMth, dim = c (nmth, nyear_obs))
   VarObsMthArr  <- array (NA,               dim = c (nmth, nyear_obs))
   RSimMthArr    <- array (NA,               dim = c (nmth, nyear_obs))
   if (InclHind) HindMthArr <- array (NA, dim = c (nlead, nmem, nmth, nyear_obs))                        

   ilonsim <- round ((lonObsDis2D[iLonObsDis,1] - lonminSim) / HydModResol) + 1
   ilatsim <- round ((latObsDis2D[1,iLatObsDis] - latminSim) / HydModResol) + 1
   lonSimStat <- lonsim[ilonsim]
   latSimStat <- latsim[ilatsim]
   
   nrCellsStat <- nrCells[ilonsim, ilatsim]
   indCCStat <- array (NA, dim = c(nrCellsStat, 2))
   indCCStat   <- indCC  [ilonsim, ilatsim, 1:nrCellsStat, ]

   # Fill HindMthArr
   if (InclHind) {
	      
      for (lead in (0:(nlead-1))) {

         # For discharge all elements for a specific lead time and cell are selected
         if (varname == "dis" | nrCellsStat == 1) {
		    varHindLead <- varHindAll[(lead+1), , ilonsim, ilatsim, ]
	     # For the other variables all elements within the catchment are selected and averaged
	     } else {
		    varHindLeadCatch <- array (NA, dim = c(nmem, nrCellsStat, dimSim[3]))
		    for (i in (1:nrCellsStat)) {
			   varHindLeadCatch[ ,i, ] <- varHindAll[(lead+1), , indCCStat[i,1], indCCStat[i,2], ]
	        }
	        varHindLead <- apply (varHindLeadCatch, c(1,3), mean)
	     } 
         timeHind <- timeHindAll[(lead+1), ]
      
         # Months of the observations and the hindcasts must be matched
         # ind_fs_obs is de index in de observatievector 
         #    waarin de eerste waarde van de simulatiereeks,
         #    die niet verwijderd is bij gebrek aan observaties, valt     
         # firstHindInd is de eerste index in de simulatietievector,
         #    die niet verwijderd is bij gebrek aan observaties     
         firstHindTime <- timeHind[1]
         year_fs <- floor (firstHindTime / 10000)
         mth_fs  <- floor ((firstHindTime - 10000 * year_fs) / 100)
         ind_fs_obs_a <- (year_fs - FyDisObs) * nmth + mth_fs 
         # Voor het geval de hindcasts eerder starten dan de
         #    eerste observatie
         if (ind_fs_obs_a < 1) {
		    firstHindInd <- 2 - ind_fs_obs_a
            ind_fs_obs <- 1
         } else {
   	        firstHindInd <- 1
            ind_fs_obs <- ind_fs_obs_a
         }
      
         # ind_ls_obs_a is de index in de observatievector 
         #    waarin de laatste waarde van de simulatiereeks valt    
         # ind_ls_obs is de index in de observatievector 
         #    waarin de laatste waarde van de simulatiereeks,
         #    die niet verwijderd is bij gebrek aan observaties, valt 
         # lastHindInd is de laatste index in de simulatietievector,
         #    die niet verwijderd is bij gebrek aan observaties     
         LastHindTime <- timeHind[nTimesHind]
         year_ls <- floor (LastHindTime / 10000)
         mth_ls  <- floor ((LastHindTime - 10000 * year_ls) / 100)
         ind_ls_obs_a <- (year_ls - FyDisObs) * nmth + mth_ls 
         # Voor het geval de simulaties later eindigen dan de
         #    laatste observatie
         # Dit geval is gecheckt en ok (7-10-2019)
         if (ind_ls_obs_a > NSamDisObs) {
            lastHindInd <- nTimesHind - (ind_ls_obs_a - NSamDisObs)
		    ind_ls_obs <- NSamDisObs
         } else {
		    lastHindInd <- nTimesHind
		    ind_ls_obs <- ind_ls_obs_a
         }
	        
         varHindLeadmth <- array (NA, dim = c(nmem, NSamDisObs))
         for (imem in (1:nmem)) {
	        varHindLeadmth[imem, ind_fs_obs:ind_ls_obs] <- varHindLead[imem, firstHindInd:lastHindInd]
	        HindMthArr[(lead+1), imem, , ] <- varHindLeadmth[imem, ]
	     }
      	  
      }   # End of the loop over the lead months

   }   # End of filling HindMthArr
   
   if (varname == "dis" | nrCellsStat == 1) {
      varRSimStat <- varRSim[ilonsim, ilatsim, ]
      EvapObsStat <- EvapObs[ilonsim, ilatsim, ]
	  FracNA <- length (which (is.na (EvapObsStat))) / length (EvapObsStat)
   } else {
	  varRSimCatch <- array (NA, dim = c(nrCellsStat, nTimesRSim))
	  EvapObsCatch <- array (NA, dim = c(nrCellsStat, nTimesEvapObs))
	  for (i in (1:nrCellsStat)) {
		 varRSimCatch[i, ] <- varRSim[indCCStat[i,1], indCCStat[i,2], ]
		 EvapObsCatch[i, ] <- EvapObs[indCCStat[i,1], indCCStat[i,2], ]
	  }
	  varRSimStat <- apply (varRSimCatch, 2, mean)
	  FracNA <- length (which (is.na (EvapObsCatch))) / length (EvapObsCatch)
	  EvapObsStat <- apply (EvapObsCatch, 2, mean, na.rm = T)
   } 

   print (paste (istat, rivername, stationname, nrCellsStat, FracNA, sep = "   "))
   
   # synchronize the reference simulations with the discharge observations   
   varRSimObsL <- vector (mode = "double", length = NSamDisObs)
   varRSimObsL[] <- NA

   indFObs_a <- (fYearRSim - FyDisObs) * nmth + 1
   if (indFObs_a < 1) {
	  firstRSimInd <- 2 - indFObs_a
      indFObs <- 1
   } else {
   	  firstRSimInd <- 1
      indFObs <- indFObs_a
   }

   indLObs_a <- (lYearRSim - FyDisObs + 1) * nmth 
   if (indLObs_a > NSamDisObs) {
      lastRSimInd <- nTimesRSim - (indLObs_a - NSamDisObs)
      indLObs <- NSamDisObs
   } else {
	  lastRSimInd <- nTimesRSim
	  indLObs <- indLObs_a
   }
   
   varRSimObsL[indFObs:indLObs] <- varRSimStat[firstRSimInd:lastRSimInd]
   RSimMthArr[ , ] <- varRSimObsL

   # synchronize the GLEAM data with the discharge observations   
   if (varname == "evap") {
	      
      EvapObsObsL <- vector (mode = "double", length = NSamDisObs)
      EvapObsObsL[] <- NA

      indFObs_a <- (FyGleam - FyDisObs) * nmth + 1
      if (indFObs_a < 1) {
	     FEvapObsInd <- 2 - indFObs_a
         indFObs <- 1
      } else {
   	     FEvapObsInd <- 1
         indFObs <- indFObs_a
      }

      indLObs_a <- (LyGleam - FyDisObs + 1) * nmth 
      if (indLObs_a > NSamDisObs) {
         LEvapObsInd <- nTimesEvapObs - (indLObs_a - NSamDisObs)
         indLObs <- NSamDisObs
      } else {
	     LEvapObsInd <- nTimesEvapObs
	     indLObs <- indLObs_a
	  }
	  
      EvapObsObsL[indFObs:indLObs] <- EvapObsStat[FEvapObsInd:LEvapObsInd]
      VarObsMthArr[ , ] <- EvapObsObsL
      for (i in (1:nmth)) VarObsMthArr[i, ] <- VarObsMthArr[i, ] / NDayMth[i]
      
   } else if (varname == "prec") {
	  VarObsMthArr <- RSimMthArr
   } else if (varname == "dis") {
	  VarObsMthArr <- DisObsMthArr   
   }
   
   rivername <- gsub ("/", "_", rivername)
   stationname <- gsub ("/", "_", stationname)
   
   fileout <- paste (DirOut, rivername, "_", stationname, "_raw.rds", 
                     sep = "")

   if (varname == "dis") {
	  if (InclHind) SpecHindMthArr <- HindMthArr / areamod * fac_sp_dis 
      SpecRSimMthArr <- RSimMthArr / areamod * fac_sp_dis 
      SpecDisObsMthArr <- DisObsMthArr / areaobs * fac_sp_dis
   } else {
	  if (InclHind) SpecHindMthArr     <- NA
      SpecRSimMthArr     <- NA
      SpecDisObsMthArr   <- NA
   }
 
   if (InclHind) {  
      save (HindMthArr, RSimMthArr, DisObsMthArr, VarObsMthArr, 
            rivername, stationname,
            latstat, lonstat, areaobs, areamod, FyDisObs,
            LyDisObs, lonSimStat, latSimStat, 
            SpecHindMthArr, SpecRSimMthArr, SpecDisObsMthArr,
            file = fileout)
   } else {  
      save (RSimMthArr, DisObsMthArr, VarObsMthArr, 
            rivername, stationname,
            latstat, lonstat, areaobs, areamod, FyDisObs,
            LyDisObs, lonSimStat, latSimStat, 
            SpecRSimMthArr, SpecDisObsMthArr,
            file = fileout)
   }
         
   iOut <- iOut + 1
   riversOut[iOut]   <- rivername
   stationsOut[iOut] <- stationname
   latstatOut[iOut]  <- latstat
   lonstatOut[iOut]  <- lonstat
   areaobsOut[iOut]  <- areaobs
   areamodOut[iOut]  <- areamod
   
}   # End of the loop over the stations

nc_close (ncObsDis)

if (varname == "dis") {
   fileStats <- paste (DirOut, "RiverAndStationNames.rds", sep = "")
   riversSave   <- riversOut[1:iOut]                    
   stationsSave <- stationsOut[1:iOut]                    
   latstatSave  <- latstatOut[1:iOut]                    
   lonstatSave  <- lonstatOut[1:iOut]                    
   areaobsSave  <- areaobsOut[1:iOut]                    
   areamodSave  <- areamodOut[1:iOut]                    
   save (riversSave, stationsSave, latstatSave, lonstatSave, 
         areaobsSave, areamodSave, file = fileStats) 
}  

}   # end of the loop over the variables                  




   





