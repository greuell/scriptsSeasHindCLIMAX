#!/bin/bash

# This is the central script for producing seasonal hydrological hindcasts
#    (WUSHP)
# Within this script, other scripts, each one developed for a specific task
#    (e.g. to convert daily to 3-hourly forcing), are called within specific
#     sections. The structures of the different sections are more or less the same.
#    I added some comment to the first one (acquire forcing for the hindcasts). 

# Input parameters that are often modified

project='CLIMAX'
dir_scripts='/home/WUR/greue002/'$project'/scripts/'
lus_backup='/lustre/backup/WUR/ESG/greue002/'

typerun='SH'         # SREF: perform actions related to the reference 
                     #       (i.e. historical) simulation and its forcing 
                     #       (i.e. meteorological observations or similar,
                     #       e.g. WFDEI)
                     # SH:   perform actions related to hydrological 
                     #       hindcasts and their 
                     #       forcings (seasonal hindcasts produced by
                     #       climate models, e.g. SEAS5) 

# List of actions that will be performed (mostly y (yes) or n (no))

# Climate model hindcasts can better be downloaded with acq_singlevar_CDS.sh
#    than by setting acq_forc='y'
# but this task must be performed for creating the forcing of the
#    reference simulation
acq_forc='n'         # download forcing for SH or prepare forcing for SREF 
                     #    from data on server
# man_grib is only relevant if acq_forc='y' and typerun='SH'                     
man_grib='do'        # only download grib from CDS ('do') 
                     #    or manipulate files that have already been downloaded ('fd')
                     #    or download from CDS and manipulate ('dm')

# Prepare the simulations
conv_to_VIC_forc='n' # convert forcing from CDS to VIC forcing
n_jobs_max_conv=32   # maximum number of simultaneous jobs for the conversion

DailyTo3hr='n'       # convert daily to 3-hourly forcing                  
n_jobs_max_3h=32     # maximum number of simultaneous jobs for creating 3-hourly forcing
make_parfiles='n'    # make VIC parameter files 

# Run the simulations
run_hydmodel='n'     # run the hydrological model (output are daily means)
n_jobs_max_hm=64     # maximum number of simultaneous jobs to run the 
                     #    hydrological model.
                     # Is automatically set equal to 1 for the reference simulation.
                     
# Process the output of the simulations
calc_mm='n'          # calculate monthly means from daily means 
rearr_to_lead='y'    # rearrange the monthly output so each resulting file 
                     # contains the data for a single lead month
anal_forc='y'        # only active if calc_mm='y' or rearr_to_lead='y':
                     # for analysis of the forcing (y) 
                     #     or of the output of hydrological model (n)
MeanInitStates='n'   # compute the mean of initial states. 
                     # If 'y', type_run must be set to 'SREF'.
                     # First and last year must be specified.                   
PrepAnalStat='n'     # prepare data for the analysis at station level
#rearr_out='n'       # rearrange the output of the hydrological model.
                     # This action is probably obsolete

batch='y'            # perform task in batch mode (y) or not (n)

# End of the list of input parameters that are often modified

# Input parameters that are less likely modified
hydmodel='VIC'             # the hydrological model
domain='SA'                # the domain, e.g. South America (SA)
version='v1'               # version of the simulations. In the case of the CLIMAX project:
                           # v0: parameters obtained from Bram in October 2018
                           # v1: parameters updated with LAI and vegetation heights from CLM 
                           #     in February 2020
VICdt_hrs=3                # time step for running the hydrological model (hours)
dtWFDEI=24                 # time step of meteorological forcing of the reference
                           #    simulation (hours) 
HydModResol=0.5            # spatial resolution of the simulations (degrees)
 
if [ "$typerun" == "SREF" ]
then
   forcing='WFDEI'         # the meteorological forcing
   forc_vers='aug2018'     # its version
   spec_run='std'          # option to specify a version of the reference simulation.
                           # in the CLIMAX project this was always set as 'std'
   biascorr='noBC'         # should be set to 'noBC' in the reference simulation
   read_init_first='n'     # if y: read initial state at beginning of the simulation.
                           #       Use this when reference simulation
                           #       was interrupted
                           # if n: do not read initial state at beginning of the simulation.
                           #       Use this when this is the first attempt to
                           #       run the reference simulation. 
   finiyear=1981           # first year 
   liniyear=2015           # last year
   finimth=1               # first month
   linimth=12              # last month
   # The following three variables are only used when the simulation is an ensemble
   #    consisting of members
   fmem=0                  # Should always be 0 when typerun=SREF
   lmem=0                  # Should always be 0 when typerun=SREF
   nmem=1                  # Should always be 1 when typerun=SREF
   if [ "$forcing" == "WFDEI" ]
   then
      prectype='GPCC'      # type of the precipitation forcing (WFDEI has two options)
   fi
   dur=1                   # Should always be 1 (length of the simulation in months)
   RawForcResol=0.5        # Resolution of the downloaded forcing data (degrees)
elif [ "$typerun" == "SH" ]
then
   forcing='ecmwf'         # the meteorological forcing
   forc_vers='5'           # its version (5 for SEAS5)
   spec_run='Meteo'        # Different types of hindcasts, see publications Greuell.
                           # options: Full, Init, InitSM, InitSn of Meteo
   biascorr='noBC'         # use forcing corrected for bias (BC) or not (noBC)
   finiyear=1981           # The first year of the actual job (if run was interrrupted)
                           # Can differ from finiyearmod (see below)        
                           # Has no effect in select_data_station.R
   liniyear=2015           # The last year of the actual job (if run was interrrupted)
                           # Can differ from liniyearmod        
                           # Has no effect in select_data_station.R
   finimth=1               # first month 
   linimth=12              # last month
   fmem=1                  # The first member of the ACTUAL job
                           # Can differ from 1 (if run was interrrupted)
   lmem=25                 # The last member of the ACTUAL job
                           # Can differ from nmem (if run was interrrupted)

   if [ "$forcing" == "ecmwf" ] && [ "$forc_vers" == "5" ]
   then
      finiyearmod=1981     # The first year of this data set
      liniyearmod=2015     # The last year of this data set
      nmem=25              # The number of ensemble members        
      dur=7                # Length of the simulation in months
      RawForcResol=1       # Resolution of the downloaded forcing data (degrees)
      if [ "$conv_to_VIC_forc" == "y" ]
      then
         biascorr='noBC'
      fi
   fi

   # Specify the reference simulation (needed for the initial states)
   # Meaning of variable: see under if [ "$typerun" == "SREF" ] above 
   forcing_ref='WFDEI'
   forc_vers_ref='aug2018'
   spec_run_ref='std'   
fi

# End of the input variables that might be modified
# Basically, the script should run by only adapting variables above this
#    comment

iniday=1
lengthmth_ref=(0 31 28 31 30 31 30 31 31 30 31 30 31)
nyearmod=$((liniyearmod-finiyearmod+1))

# Define domain boundaries
if [ "$domain" == "EU" ]
then
   westb=-25.0
   eastb=40.0
   southb=33.0
   northb=72.0
elif [ "$domain" == "NL" ]
then
   westb=3.0
   eastb=7.5
   southb=50.5
   northb=54.0
elif [ "$domain" == "SA" ]
then
   westb=-83.5
   eastb=-32.5
   southb=-58.0
   northb=14.5
fi

# Compute coordinates of the grid cells along the margins of the domain
northb_gpHydMod=$(echo "$northb - 0.50000 * $HydModResol" | bc)
southb_gpHydMod=$(echo "$southb + 0.50000 * $HydModResol" | bc)
eastb_gpHydMod=$(echo "$eastb - 0.50000 * $HydModResol" | bc)
westb_gpHydMod=$(echo "$westb + 0.50000 * $HydModResol" | bc)

# Determine whether the forcing and the initial conditions
#    must be identical for al years, or not
if [ "$typerun" == "SREF" ]
then
   ForcIden='n'
elif [ "$typerun" == "SH" ]
then

   case $spec_run in
      'Full')   ForcIden='n' ;
                InitIden='n' ;;
      'Init')   ForcIden='y' ;
                InitIden='n' ;;
      'Meteo')  ForcIden='n' ;
                InitIden='y' ;;
      'InitSM') ForcIden='y' ;
                InitIden=' ' ;;
      'InitSn') ForcIden='y' ;
                InitIden=' ' ;;
      *)        exit 'spec_run has no appropriate value' ;;
   esac
   
   if [ "$ForcIden" == 'y' ]
   then

      # If the forcing is identical for all years, a scheme is needed
      #    to select the ensemble members from the different years
      #    of the hindcasts
      if [ "$nyearmod" == 35 -a "$nmem" == 25 ]
      then
         declare -a iYearForc=( 0 1 2 4 5 7 8 9 11 12 14 15 16 18 19 21 22 \
                                23 24 26 28 29 30 32 33)
      else
         echo 'scheme for creating forcing must still be produced'
      fi

      YearForc=()
      nmemm1=$((nmem-1))
      for imem in $(seq 0 $nmemm1); do
         YearForc[$imem]=$((finiyearmod+iYearForc[$imem]))
      done

   fi

fi

# Create strings for file names, etc.      
if [ "$dur" -lt "10" ]
then
   str_dur='0'$dur
else
   str_dur=$dur
fi

case $HydModResol in
     '0.05') HydModResolStr='zpz5' ;; 
     '0.5')  HydModResolStr='half' ;; 
     '1.0')  HydModResolStr='one'    ;; 
     *)      exit 'String is missing for this spatial resolution' ;;
esac 
HydModResolStr=$HydModResolStr'degree'

case $RawForcResol in
     '0.05') RawForcResolStr='zpz5' ;; 
     '0.5')  RawForcResolStr='half' ;; 
     '1')    RawForcResolStr='1'    ;; 
     *)      exit 'String is missing for this spatial resolution' ;;
esac 
RawForcResolStr=$RawForcResolStr'degree'

# set some directories
dir_domain=$lus_backup$project'/'$domain'/'
dir_paramfiles=$lus_backup'VIC/paramfiles/'
if [ "$version" == "v0" ]
then
   dir_VICparamfiles=$dir_paramfiles'VICParams2018_10/'
elif [ "$version" == "v1" ]
then
   dir_VICparamfiles=$dir_paramfiles'VICParams2020_02/'
fi 

# Acquire the forcing.
# For the hindcasts, the forcing can better be downloaded with acq_singlevar_CDS.sh
if [ "$acq_forc" == "y" ] 
then

   dir_forcbas=$dir_domain'forcing/'

   if [ "$typerun" == "SH" ]  
   then

      # directories are defined
      dir_acqforcbas=$dir_forcbas$forcing'_'$forc_vers'/'$RawForcResolStr'_'$biascorr'/'

      dir_acqforcrun=$dir_acqforcbas'run/'
      dir_acqforcoutput=$dir_acqforcbas'data/'
      dir_acqforcstatic=$dir_acqforcbas'static/'
      dir_forcadj=$dir_forcbas$forcing'_'$forc_vers'/'$HydModResolStr'_'$biascorr'_daily/'

      # directories are created if they do not yet exist (-p)
      mkdir -p $dir_acqforcbas
      mkdir -p $dir_acqforcrun
      mkdir -p $dir_acqforcoutput
      mkdir -p $dir_acqforcstatic
      mkdir -p $dir_forcadj

      # scripts and documents are copied.
      # The original will remain unmodified,
      # whereas the copied version will be modified to suit the occasion (see below) 
      cp acq_forcing_CDS_empty_v3.sh $dir_acqforcrun/acq_forcing_CDS.sh3
      cp form_acq_forc6_empty.py $dir_acqforcrun/form_acq_forc6_all.py 
      cp form_acq_forc24_empty.py $dir_acqforcrun/form_acq_forc24_all.py 
      cp form_acq_stat_empty.py $dir_acqforcrun/form_acq_stat_all.py 
      cd $dir_acqforcrun
   
      northb_downl=$(echo "$northb + $RawForcResol" | bc)
      southb_downl=$(echo "$southb - $RawForcResol" | bc)
      eastb_downl=$(echo "$eastb + $RawForcResol" | bc)
      westb_downl=$(echo "$westb - $RawForcResol" | bc)

      # all occurrences of *_ph are replaced by their actual values
      #    in all files described by $dir_acqforcrun/*,
      #    e.g. all occurrences of finiyear_ph are replaced
      #         the actual value of $finiyear     
      # ph means place holder  
      sed -i "s|dir_acqforcstatic_ph|$dir_acqforcstatic|g" $dir_acqforcrun/*
      sed -i "s|dir_acqforcoutput_ph|$dir_acqforcoutput|g" $dir_acqforcrun/*
      sed -i "s|dir_acqforcrun_ph|$dir_acqforcrun|g" $dir_acqforcrun/*
      sed -i "s|dir_paramfiles_ph|$dir_paramfiles|g" $dir_acqforcrun/*
      sed -i "s|northb_downl_ph|$northb_downl|g" $dir_acqforcrun/*
      sed -i "s|southb_downl_ph|$southb_downl|g" $dir_acqforcrun/*
      sed -i "s|westb_downl_ph|$westb_downl|g" $dir_acqforcrun/*
      sed -i "s|eastb_downl_ph|$eastb_downl|g" $dir_acqforcrun/*
      sed -i "s|dir_forcadj_ph|$dir_forcadj|g" $dir_acqforcrun/*
      sed -i "s|dir_scripts_ph|$dir_scripts|g" $dir_acqforcrun/*
      sed -i "s|dir_domain_ph|$dir_domain|g" $dir_acqforcrun/*
      sed -i "s|forc_vers_ph|$forc_vers|g" $dir_acqforcrun/*
      sed -i "s|finiyear_ph|$finiyear|g" $dir_acqforcrun/*
      sed -i "s|liniyear_ph|$liniyear|g" $dir_acqforcrun/*
      sed -i "s|man_grib_ph|$man_grib|g" $dir_acqforcrun/*
      sed -i "s|finimth_ph|$finimth|g" $dir_acqforcrun/*
      sed -i "s|linimth_ph|$linimth|g" $dir_acqforcrun/*
      sed -i "s|forcing_ph|$forcing|g" $dir_acqforcrun/*
      sed -i "s|str_dur_ph|$str_dur|g" $dir_acqforcrun/*
      sed -i "s|domain_ph|$domain|g" $dir_acqforcrun/*
      sed -i "s|southb_ph|$southb|g" $dir_acqforcrun/*
      sed -i "s|northb_ph|$northb|g" $dir_acqforcrun/*
      sed -i "s|westb_ph|$westb|g" $dir_acqforcrun/*
      sed -i "s|eastb_ph|$eastb|g" $dir_acqforcrun/*
      sed -i "s|lmem_ph|$lmem|g" $dir_acqforcrun/*

      # run the relevant script        
      if [ "$batch" == "y" ]
      then
         sbatch ./acq_forcing_CDS.sh
      else
         ./acq_forcing_CDS.sh
      fi
      exit

   elif [ "$typerun" == "SREF" ] 
   then

      dir_forc=$dir_forcbas$forcing'_'$forc_vers'/'$RawForcResolStr'_'$biascorr'_daily/'
      dir_forcrun=$dir_forc'run/'
      dir_forcdata=$dir_forc'data/'
      
      mkdir -p $dir_forc
      mkdir -p $dir_forcrun
      mkdir -p $dir_forcdata
      
      cp make_WFDEIforc_refrun_empty.sh $dir_forcrun/make_WFDEIforc_refrun.sh
      cd $dir_forcrun

      sed -i "s|dir_forcdata_ph|$dir_forcdata|g" $dir_forcrun/*
      sed -i "s|dir_forc_ph|$dir_forc|g" $dir_forcrun/*
      sed -i "s|prectype_ph|$prectype|g" $dir_forcrun/*
      sed -i "s|finiyear_ph|$finiyear|g" $dir_forcrun/*
      sed -i "s|liniyear_ph|$liniyear|g" $dir_forcrun/*
      sed -i "s|dtWFDEI_ph|$dtWFDEI|g" $dir_forcrun/*
      sed -i "s|southb_ph|$southb|g" $dir_forcrun/*
      sed -i "s|northb_ph|$northb|g" $dir_forcrun/*
      sed -i "s|westb_ph|$westb|g" $dir_forcrun/*
      sed -i "s|eastb_ph|$eastb|g" $dir_forcrun/*

      if [ "$batch" == "y" ]
      then
         sbatch ./make_WFDEIforc_refrun.sh
      else
         ./make_WFDEIforc_refrun.sh
      fi
      
      exit
      
   fi
   
fi 

# Convert forcing so that it is in the correct format for VIC 
if [ "$conv_to_VIC_forc" == "y" ] 
then

   if [ "$typerun" == "SH" ]  
   then

      for iniyear in $(seq $finiyear $liniyear); do
      for inimth in $(seq $finimth $linimth); do
 
         cd $dir_scripts
         echo $inimth   $iniyear

         if [ "$inimth" -lt "10" ]
         then
            str_inimth='0'$inimth
         else
            str_inimth=$inimth
         fi
         
         dirhere1=$lus_backup$project'/'$domain'/forcing/'$forcing'_'
         dirhere2=$forc_vers'/'$HydModResolStr'_'$biascorr'_daily/'
         dirhere3=$iniyear$str_inimth'/'
         dirhere=$dirhere1$dirhere2$dirhere3
         mkdir -p $dirhere
         filerun=$dirhere'conv_to_VIC_forc.sh'
         cp conv_to_VIC_forc_empty.sh $filerun
         cd $dirhere
         chmod u+x $filerun
         
         echo $dirhere
         
         sed -i "s|RawForcResol_ph|$RawForcResol|g" $filerun
         sed -i "s|dir_scripts_ph|$dir_scripts|g" $filerun
         sed -i "s|lus_backup_ph|$lus_backup|g" $filerun
         sed -i "s|forc_vers_ph|$forc_vers|g" $filerun
         sed -i "s|biascorr_ph|$biascorr|g" $filerun
         sed -i "s|dirhere_ph|$dirhere|g" $filerun
         sed -i "s|forcing_ph|$forcing|g" $filerun
         sed -i "s|iniyear_ph|$iniyear|g" $filerun
         sed -i "s|project_ph|$project|g" $filerun
         sed -i "s|inimth_ph|$inimth|g" $filerun
         sed -i "s|domain_ph|$domain|g" $filerun
         sed -i "s|northb_ph|$northb|g" $filerun
         sed -i "s|southb_ph|$southb|g" $filerun
         sed -i "s|westb_ph|$westb|g" $filerun
         sed -i "s|eastb_ph|$eastb|g" $filerun
         sed -i "s|lmem_ph|$lmem|g" $filerun
      
         if [ "$batch" == "y" ]
         then
            sbatch ./conv_to_VIC_forc.sh
            njobs=100
            while [ "$njobs" -gt "$n_jobs_max_conv" ]
            do 
               njobs=$(squeue -n convert_to_VIC_forcing | wc -l)
               sleep 5 
               # echo "waiting"
            done
         else
            ./conv_to_VIC_forc.sh
         fi
         
      done   # End of the loop over the months
      done   # End of the loop over the years
               
   fi        # End of if-statement SH
   
fi

# Calculate monthly means of
# the forcing of the reference simulation
# the output of the reference simulation
# the forcing of the hindcasts
# the output of the hindcasts
if [ "$calc_mm" == "y" ]
then

   if [ "$typerun" == "SREF" ]
   then
   
      if [ "$anal_forc" == "y" ]
      then
      
         dirbase1=$dir_domain'forcing/'$forcing'_'$forc_vers'/'
         dirbase2=$HydModResolStr'_'$biascorr'_daily/data/'
         dirbase=$dirbase1$dirbase2
         
         runscript=$dirbase'calc_monthmean.sh'
         cp calc_monthmean_forcing_refrun_empty.sh $runscript        
         chmod u+x $runscript
         
         sed -i "s|finiyear_ph|$finiyear|g" $runscript
         sed -i "s|liniyear_ph|$liniyear|g" $runscript
 
         cd $dirbase
         ./calc_monthmean.sh
         exit

      elif [ "$anal_forc" == "n" ]
      then
      
         dirbase1=$dir_domain$hydmodel'/'$forcing'_'$forc_vers'/'
         dirbase2=$HydModResolStr'_'$spec_run'_'$typerun'_'$biascorr
         dirbase3='_'$version'/'
         dirbase=$dirbase1$dirbase2$dirbase3
         
         runscript=$dirbase'calc_monthmean_SREF.sh'        
         cp calc_monthmean_SREF_empty.sh $runscript
         chmod u+x $runscript
      
         sed -i "s|finiyear_ph|$finiyear|g" $runscript
         sed -i "s|liniyear_ph|$liniyear|g" $runscript
         sed -i "s|finimth_ph|$finimth|g" $runscript
         sed -i "s|linimth_ph|$linimth|g" $runscript
         sed -i "s|str_dur_ph|$str_dur|g" $runscript
         sed -i "s|version_ph|$version|g" $runscript

         cd $dirbase
         
         if [ "$batch" == "y" ]
         then
            sbatch ./calc_monthmean_SREF.sh
         else
            ./calc_monthmean_SREF.sh
         fi
         exit
         
      fi
     
   elif [ "$typerun" == "SH" ]
   then
   
      if [ "$anal_forc" == "y" ]
      then
     
         diract=$dir_domain'forcing/'$forcing'_'$forc_vers'/'$HydModResolStr'_'$biascorr'_daily/'
         runscract=$diract/calc_monthmean_forcing_SH.sh
         cp calc_monthmean_forcing_SH_empty.sh $runscract
   
         sed -i "s|HydModResolStr_ph|$HydModResolStr|g" $runscract
         sed -i "s|forc_vers_ph|$forc_vers|g" $runscract
         sed -i "s|finiyear_ph|$finiyear|g" $runscract
         sed -i "s|liniyear_ph|$liniyear|g" $runscract
         sed -i "s|biascorr_ph|$biascorr|g" $runscract
         sed -i "s|finimth_ph|$finimth|g" $runscract
         sed -i "s|linimth_ph|$linimth|g" $runscract
         sed -i "s|forcing_ph|$forcing|g" $runscract
         sed -i "s|domain_ph|$domain|g" $runscract
         sed -i "s|fmem_ph|$fmem|g" $runscract
         sed -i "s|lmem_ph|$lmem|g" $runscract
   
         cd $diract

         if [ "$batch" == "y" ]
         then
            sbatch ./calc_monthmean_forcing_SH.sh
         else
            ./calc_monthmean_forcing_SH.sh
         fi
         exit
      
      elif [ "$anal_forc" == "n" ]
      then
      
         dirbase1=$dir_domain$hydmodel'/'$forcing'_'$forc_vers'/'
         dirbase2=$HydModResolStr'_'$spec_run'_SH_'$biascorr'_'$version'/'
         dirbase=$dirbase1$dirbase2
      
         dirrun=$dirbase'run/'
         mkdir -p $dirrun
      
         runscript='calc_monthmean_SH.sh'
         cp calc_monthmean_SH_empty.sh $dirrun$runscript
         cd $dirrun 

         sed -i "s|forc_vers_ph|$forc_vers|g" $runscript
         sed -i "s|hydmodel_ph|$hydmodel|g" $runscript
         sed -i "s|finiyear_ph|$finiyear|g" $runscript
         sed -i "s|liniyear_ph|$liniyear|g" $runscript
         sed -i "s|biascorr_ph|$biascorr|g" $runscript
         sed -i "s|finimth_ph|$finimth|g" $runscript
         sed -i "s|linimth_ph|$linimth|g" $runscript
         sed -i "s|forcing_ph|$forcing|g" $runscript
         sed -i "s|str_dur_ph|$str_dur|g" $runscript
         sed -i "s|domain_ph|$domain|g" $runscript
         sed -i "s|fmem_ph|$fmem|g" $runscript
         sed -i "s|lmem_ph|$lmem|g" $runscript

         if [ "$batch" == "y" ]
         then
            sbatch ./calc_monthmean_SH.sh
         else
            ./calc_monthmean_SH.sh
         fi

         exit
      
      fi   # End of the if-statement for averaging the forcing of or the
           #    output from the hydrological model 
      
   fi   # End of the if-statement over the reference run or the hindcasts  
       
fi

# Convert daily to 3 hourly forcing
if [ "$DailyTo3hr" == "y" ] 
then

   for iniyear in $(seq $finiyear $liniyear); do
   for inimth in $(seq $finimth $linimth); do
 
      echo $inimth   $iniyear

      if [ "$inimth" -lt "10" ]
      then
         str_inimth='0'$inimth
      else
         str_inimth=$inimth
      fi
         
      if [ "$typerun" == "SREF" ]  
      then
         dir_2='_'$forc_vers'/'$RawForcResolStr'_'$biascorr'_daily/data/'
         echo "Je moet dit programma voor de referentierun weer checken"
         exit
      elif [ "$typerun" == "SH" ] 
      then
         dir_2='_'$forc_vers'/'$HydModResolStr'_'$biascorr'_daily/'
      fi

      dir_1='/lustre/backup/WUR/ESG/greue002/'$project'/SA/forcing/'$forcing
      dir_2=$dir_1'_'$forc_vers'/'$HydModResolStr'_'$biascorr'_'
      dirin=$dir_2'daily/'
      dir_yrmth=$dir_2'3hdisaggr/'$iniyear$str_inimth'/'
      dir_run=$dir_yrmth'run'
      dir_data=$dir_yrmth'data'
      
      mkdir -p $dir_run
      mkdir -p $dir_data

      cp from24to3h_empty.R $dir_run'/from24to3h.R'
      cp run_Rscript.sh $dir_run'/run_Rscript.sh'
      cd $dir_run
      
      sed -i "s|northb_gpHydMod_ph|$northb_gpHydMod|g" $dir_run/from24to3h.R
      sed -i "s|southb_gpHydMod_ph|$southb_gpHydMod|g" $dir_run/from24to3h.R
      sed -i "s|westb_gpHydMod_ph|$westb_gpHydMod|g" $dir_run/from24to3h.R
      sed -i "s|eastb_gpHydMod_ph|$eastb_gpHydMod|g" $dir_run/from24to3h.R
      sed -i "s|dir_daily_ph|$dir_daily|g" $dir_run/from24to3h.R
      sed -i "s|dir_data_ph|$dir_data|g" $dir_run/from24to3h.R
      sed -i "s|iniyear_ph|$iniyear|g" $dir_run/from24to3h.R
      sed -i "s|typerun_ph|$typerun|g" $dir_run/from24to3h.R
      sed -i "s|inimth_ph|$inimth|g" $dir_run/from24to3h.R
      sed -i "s|dirin_ph|$dirin|g" $dir_run/from24to3h.R
      sed -i "s|fmem_ph|$fmem|g" $dir_run/from24to3h.R
      sed -i "s|lmem_ph|$lmem|g" $dir_run/from24to3h.R
      sed -i "s|dur_ph|$dur|g" $dir_run/from24to3h.R
      
      if [ "$batch" == "y" ]
      then
         sbatch ./run_Rscript.sh from24to3h.R
         njobs=$((n_jobs_max_3h+1))
         while [ "$njobs" -gt "$n_jobs_max_3h" ]
         do 
            njobs=$(squeue -n Rscript | wc -l)
            sleep 5 
            # echo "waiting"
         done
      else
         ./run_Rscript.sh from24to3h.R
      fi
      
      cd $dir_scripts
         
   done   # End of the loop over the months
   done   # End of the loop over the years
                          
fi

if [ "$make_parfiles" == "y" ]
then
   echo 'Parameter files are written to '$dir_paramfiles 
   par_file_glob=$dir_paramfiles'domain_global_maskCorr.nc'
   par_file_reg=$dir_paramfiles'domain_'$domain'_maskCorr.nc'
   ncks -d lon,$westb,$eastb -d lat,$southb,$northb $par_file_glob -O $par_file_reg
   par_file_glob=$dir_paramfiles'rout_params_global.nc'
   par_file_reg=$dir_paramfiles'rout_params_'$domain'.nc'
   ncks -d lon,$westb,$eastb -d lat,$southb,$northb $par_file_glob -O $par_file_reg   
   par_file_glob=$dir_VICparamfiles'VIC_params_global_latlon_'$HydModResol'.nc'
   par_file_reg=$dir_VICparamfiles'VIC_params_'$domain'_latlon_'$HydModResol'.nc'
   ncks -d lon,$westb,$eastb -d lat,$southb,$northb $par_file_glob -O $par_file_reg   
   exit   
fi

dir_setbas=$dir_domain$hydmodel'/'$forcing'_'$forc_vers'/'
dir_set_p1=$HydModResolStr'_'$spec_run'_'$typerun'_'
dir_set_p2=$biascorr'_'$version'/'
dir_mod_out=$dir_setbas$dir_set_p1$dir_set_p2
mkdir -p $dir_mod_out

# run the hydrological model   
if [ "$run_hydmodel" == "y" ]
then

   if [ "$typerun" == "SREF" ]  
   then
      n_tasks=1
      n_jobs_max_hm=1
   elif [ "$typerun" == "SH" ] 
   then
      n_tasks=1
   fi

   dir_forcbas=$dir_domain'forcing/'$forcing'_'$forc_vers'/'

   # Loop over the members of the ensemble
   for imem in $(seq $fmem $lmem); do

      if [ "$imem" -lt "10" ]
      then
         str_mem='0'$imem
      else
         str_mem=$imem
      fi

      # Loop over the years and months of initialisation
      for iniyear in $(seq $finiyear $liniyear); do
         for inimth in $(seq $finimth $linimth); do
 
         echo $imem   $inimth   $iniyear  njobs = $njobs
         # Set variables for file names and parameters     
         if [ "$inimth" -lt "10" ]
         then
            str_inimth='0'$inimth
         else
            str_inimth=$inimth
         fi
    
         # The last target month of the actual hindcast        
         ltarmth=$((inimth+dur-1))
         ltaryear=$iniyear
         if [ "$ltarmth" -gt "12" ]
         then
            ltarmth=$((ltarmth-12))
            ltaryear=$((ltaryear+1))
         fi

         if [ "$((ltaryear % 4))" -eq "0" ] && [ "$ltarmth" -eq "2" ] 
         then   
            ltarday=29
         else
            ltarday=${lengthmth_ref[$ltarmth]}
         fi

         # Determine for which day, month and year the state must be saved
         saveday=1
         savemth=$((ltarmth+1))
         if [ "$savemth" -gt "12" ]
         then
            savemth=1
            saveyear=$((ltaryear+1))
         else
            saveyear=$ltaryear
         fi
 
         # Determine whether the initial state must be read and/or the
         #    state be saved        
         if [ "$typerun" == "SREF" ]
         then
            if [ "$iniyear" -eq "$finiyear" ] && [ "$inimth" -eq "$finimth" ] && 
               [ "$read_init_first" == "n" ]
            then
               read_init_state='n'      # read initial state
            else
               read_init_state='y'
            fi
            save_state='y'
         else
            read_init_state='y'
            save_state='n'
         fi 

         # Two formatting details         
         if [ "$read_init_state" == "y" ]
         then
            ris_hd=""
         else
            ris_hd="#"
         fi

         if [ "$save_state" == "y" ]
         then
            ss_hd=""
         else
            ss_hd="#"
         fi

         # Define and create directories
         dir_sim='ini'$iniyear$str_inimth'_dur'$str_dur'_E'$str_mem
         dir_mod_out_mth=$dir_mod_out$dir_sim'/'
         
         dir_forc_bas=$dir_forcbas$HydModResolStr'_'$biascorr'_3hdisaggr/'
         dir_log=$dir_mod_out_mth'log/'
         dir_output=$dir_mod_out_mth
         dir_run=$dir_mod_out_mth'run/'         
         rm -rf $dir_run
         mkdir -p $dir_log
         mkdir $dir_run

         if [ "$typerun" == "SREF" ]
         then         
            dir_initstates=$dir_mod_out'initstates/'
            mkdir -p $dir_initstates
            dir_forc=$dir_forc_bas'data/'
         else 

            dir_initstates_sub1=$dir_domain$hydmodel'/'$forcing_ref'_'
            dir_initstates_sub2=$forc_vers_ref'/'$HydModResolStr'_'$spec_run_ref'_'     
            dir_initstates_sub3='SREF_noBC_'$version'/initstates/'     
            dir_initstates=$dir_initstates_sub1$dir_initstates_sub2$dir_initstates_sub3
            
            if [ "$ForcIden" == "n" ]
            then
               dir_forc=$dir_forc_bas$iniyear$str_inimth'/data/E'$str_mem'/'
            elif [ "$ForcIden" == "y" ]
            then

               # Copy the forcing files to a temporary subdirectory of dir_run
               imemm1=$((imem-1))
               YrF=${YearForc[$imemm1]}
               dir_forc_noESP=$dir_forc_bas$YrF$str_inimth'/data/E'$str_mem'/'
               temp_dir_forc=$dir_run'/temp/'
               mkdir -p $temp_dir_forc
               cd $temp_dir_forc

               # In the forcing files, the year of the forcing must be replaced
               #    by that of the run, otherwise VIC produces an error
               # Also, the time axis must be adapted
               # First the part of the forcing in the year of initialisation
               #    is considered                
               cp $dir_forc_noESP*$YrF.nc $temp_dir_forc
               rename $YrF $iniyear *
               fileYrF=( $(ls *$iniyear* ) )
               for file in ${fileYrF[@]} 
               do   
                  cp $file filetemp.nc
                  cdo -s settaxis,$iniyear'-'$str_inimth'-01,00:00:00,3hour' filetemp.nc $file 
               done 
               
               # Move files to dir_run
               mv * ..

               # If the forcing extends into the next year, that part must
               #    be treated too               
               if [ "$ltaryear" != "$iniyear" ]
               then
                  iniyearp1=$((iniyear+1)) 
                  YrFp1=$((YrF+1)) 
                  cp $dir_forc_noESP*$YrFp1.nc $temp_dir_forc
                  rename $YrFp1 $iniyearp1 *
                  fileYrFp1=( $(ls *$iniyearp1* ) )
                  for file in ${fileYrFp1[@]} 
                  do   
                     cp $file filetemp.nc
                     cdo -s settaxis,$iniyearp1'-01-01,00:00:00,3hour' filetemp.nc $file 
                  done   
                  mv * ..
               fi
 
               dir_forc=$dir_run              
               cd $dir_scripts
               
            fi 
            
            dir_forc_Exx=$dir_forc'E'$str_mem'_'
            
         fi
         
         if [ "$read_init_state" == "y" ]
         then
            if [ "$InitIden" == "n" ]
            then
               file_initstat=$dir_initstates'initstat.'$iniyear$str_inimth'01_00000.nc'
            elif [ "$InitIden" == "y" ]
            then
               file_initstat=$dir_initstates'mean_initstats_'$str_inimth'_'$finiyearmod'-'$liniyearmod'.nc'
            fi
         else
            file_initstat=''
         fi
         
         mkdir -p $dir_initstates
         
         gpfhere=$dir_run'globparfile_'$dir_sim'.txt'
         cd $dir_scripts
         cp globparfile_$project_template.txt $gpfhere
         cp runVIC_empty.sh $dir_run'runVIC.sh'

         sed -i "s|dir_VICparamfiles_ph|$dir_VICparamfiles|g" $gpfhere
         sed -i "s|dir_initstates_ph|$dir_initstates|g" $gpfhere
         sed -i "s|dir_paramfiles_ph|$dir_paramfiles|g" $gpfhere
         sed -i "s|file_initstat_ph|$file_initstat|g" $gpfhere
         sed -i "s|dir_forc_Exx_ph|$dir_forc_Exx|g" $gpfhere
         sed -i "s|run_hydmodel_ph|$run_hydmodel|g" $gpfhere
         sed -i "s|HydModResol_ph|$HydModResol|g" $gpfhere
         sed -i "s|dir_output_ph|$dir_output|g" $gpfhere
         sed -i "s|VICdt_hrs_ph|$VICdt_hrs|g" $gpfhere
         sed -i "s|make_forc_ph|$make_forc|g" $gpfhere
         sed -i "s|saveyear_ph|$saveyear|g" $gpfhere
         sed -i "s|prectype_ph|$prectype|g" $gpfhere
         sed -i "s|finiyear_ph|$finiyear|g" $gpfhere
         sed -i "s|liniyear_ph|$liniyear|g" $gpfhere
         sed -i "s|ltaryear_ph|$ltaryear|g" $gpfhere
         sed -i "s|dir_log_ph|$dir_log|g" $gpfhere
         sed -i "s|dir_out_ph|$dir_out|g" $gpfhere
         sed -i "s|gpfhere_ph|$gpfhere|g" $dir_run'/runVIC.sh'
         sed -i "s|dir_run_ph|$dir_run|g" $gpfhere
         sed -i "s|dir_sim_ph|$dir_sim|g" $gpfhere
         sed -i "s|forcing_ph|$forcing|g" $gpfhere
         sed -i "s|namerun_ph|$namerun|g" $gpfhere
         sed -i "s|typerun_ph|$typerun|g" $gpfhere
         sed -i "s|saveday_ph|$saveday|g" $gpfhere
         sed -i "s|savemth_ph|$savemth|g" $gpfhere
         sed -i "s|ltarday_ph|$ltarday|g" $gpfhere
         sed -i "s|ltarmth_ph|$ltarmth|g" $gpfhere
         sed -i "s|iniyear_ph|$iniyear|g" $gpfhere
         sed -i "s|n_tasks_ph|$n_tasks|g" $dir_run'/runVIC.sh'
         sed -i "s|domain_ph|$domain|g" $gpfhere
         sed -i "s|northb_ph|$northb|g" $gpfhere
         sed -i "s|southb_ph|$southb|g" $gpfhere
         sed -i "s|iniday_ph|$iniday|g" $gpfhere
         sed -i "s|inimth_ph|$inimth|g" $gpfhere
         sed -i "s|ris_hd_ph|$ris_hd|g" $gpfhere
         sed -i "s|ss_hd_ph|$ss_hd|g" $gpfhere
         sed -i "s|westb_ph|$westb|g" $gpfhere
         sed -i "s|eastb_ph|$eastb|g" $gpfhere
         sed -i "s|lday_ph|$lday|g" $gpfhere
         sed -i "s|lmth_ph|$lmth|g" $gpfhere
         sed -i "s|fmth_ph|$fmth|g" $gpfhere
         
         cd $dir_run
         chmod u+x runVIC.sh
         
         if [ "$batch" == "y" ]
         then
            sbatch ./runVIC.sh
            njobs=100
            while [ "$njobs" -gt "$n_jobs_max_hm" ]
            do 
               njobs=$(squeue -n seasonHC | wc -l)
               sleep 5 
               # echo "waiting"
            done
         else
            ./runVIC.sh
         fi

         done      # End of the loop over de months of initialisation
      done         # End of the loop over de years of initialisation
   done            # End of the loop over the members of the ensemble

   exit
fi

if [ "$rearr_to_lead" = "y" ]
then

   # rearr_pred_leadtime was tested on July 9, 2019 for precipitation from ecmwf_5
   #    and found ok
   cp rearr_pred_leadtime_empty.sh rearr_pred_leadtime.sh
   
   if [ "$anal_forc" == "y" ]
   then
      model=$forcing'_'$forc_vers    ## VIC, LPJ, seas15 (voor analyse SYS4) of ecmwf_5 
   elif [ "$anal_forc" == "n" ]
   then
      model=$hydmodel
   fi
    
   NWPsyst=$forcing'_'$forc_vers  ## Forcering (identical to model for climate models)

   sed -i "s|HydModResolStr_ph|$HydModResolStr|g" rearr_pred_leadtime.sh
   sed -i "s|biascorr_ph|$biascorr|g" rearr_pred_leadtime.sh
   sed -i "s|spec_run_ph|$spec_run|g" rearr_pred_leadtime.sh
   sed -i "s|finiyear_ph|$finiyear|g" rearr_pred_leadtime.sh
   sed -i "s|liniyear_ph|$liniyear|g" rearr_pred_leadtime.sh
   sed -i "s|NWPsyst_ph|$NWPsyst|g" rearr_pred_leadtime.sh
   sed -i "s|finimth_ph|$finimth|g" rearr_pred_leadtime.sh
   sed -i "s|linimth_ph|$linimth|g" rearr_pred_leadtime.sh
   sed -i "s|version_ph|$version|g" rearr_pred_leadtime.sh
   sed -i "s|str_dur_ph|$str_dur|g" rearr_pred_leadtime.sh
   sed -i "s|domain_ph|$domain|g" rearr_pred_leadtime.sh
   sed -i "s|model_ph|$model|g" rearr_pred_leadtime.sh
   sed -i "s|fmem_ph|$fmem|g" rearr_pred_leadtime.sh
   sed -i "s|lmem_ph|$lmem|g" rearr_pred_leadtime.sh
   
   if [ "$batch" == "y" ]
   then
      sbatch ./rearr_pred_leadtime.sh
   else
      ./rearr_pred_leadtime.sh
   fi
   exit
   
fi

if [ "$MeanInitStates" = "y" ]
then

   DirInitStates1=$lus_backup$project'/'$domain'/'$hydmodel'/'$forcing'_'
   DirInitStates2=$forc_vers'/'$HydModResolStr'_'$spec_run'_'
   DirInitStates3=$typerun'_'$biascorr'_'$version'/initstates/'
   
   DirInitStates=$DirInitStates1$DirInitStates2$DirInitStates3

   cp comp_mean_initstates_empty.sh comp_mean_initstates.sh  
   
   sed -i "s|DirInitStates_ph|$DirInitStates|g" comp_mean_initstates.sh
   sed -i "s|finiyear_ph|$finiyear|g" comp_mean_initstates.sh
   sed -i "s|liniyear_ph|$liniyear|g" comp_mean_initstates.sh
   sed -i "s|finimth_ph|$finimth|g" comp_mean_initstates.sh
   sed -i "s|linimth_ph|$linimth|g" comp_mean_initstates.sh
   
   ./comp_mean_initstates.sh
   
   exit
   
fi

if [ "$PrepAnalStat" = "y" ]
then

   cp select_data_station_empty_v7.R select_data_station.R

   sed -i "s|HydModResolStr_ph|$HydModResolStr|g" select_data_station.R
   sed -i "s|forc_vers_ref_ph|$forc_vers_ref|g" select_data_station.R
   sed -i "s|spec_run_ref_ph|$spec_run_ref|g" select_data_station.R
   sed -i "s|HydModResol_ph|$HydModResol|g" select_data_station.R
   sed -i "s|forcing_ref_ph|$forcing_ref|g" select_data_station.R
   sed -i "s|forc_vers_ph|$forc_vers|g" select_data_station.R
   sed -i "s|hydmodel_ph|$hydmodel|g" select_data_station.R
   sed -i "s|biascorr_ph|$biascorr|g" select_data_station.R
   sed -i "s|spec_run_ph|$spec_run|g" select_data_station.R
   sed -i "s|version_ph|$version|g" select_data_station.R
   sed -i "s|typerun_ph|$typerun|g" select_data_station.R
   sed -i "s|str_dur_ph|$str_dur|g" select_data_station.R
   sed -i "s|forcing_ph|$forcing|g" select_data_station.R
   sed -i "s|domain_ph|$domain|g" select_data_station.R
   sed -i "s|fmem_ph|$fmem|g" select_data_station.R
   sed -i "s|lmem_ph|$lmem|g" select_data_station.R
   sed -i "s|dur_ph|$dur|g" select_data_station.R

   if [ "$batch" == "y" ]
   then
      sbatch ./run_Rscript.sh select_data_station.R
   else
      ./run_Rscript.sh select_data_station.R
   fi
       
fi

if [ "$rearr_out" == "y" ]
then

   dir_all_mod_out=$dir_mod_out'all_output/'
   dir_data=$dir_all_mod_out'data/'
   dir_run=$dir_all_mod_out'run/'
   dir_log=$dir_all_mod_out'log/'
   mkdir -p $dir_data
   mkdir -p $dir_run
   mkdir -p $dir_log
   
   cp rearr_modout_empty.sh $dir_run/rearr_modout.sh 
   cd $dir_run

   sed -i "s|dir_all_mod_out_ph|$dir_all_mod_out|g" $dir_run/*
   sed -i "s|dir_mod_out_ph|$dir_mod_out|g" $dir_run/*
   sed -i "s|finiyear_ph|$finiyear|g" $dir_run/*
   sed -i "s|liniyear_ph|$liniyear|g" $dir_run/*
   sed -i "s|str_dur_ph|$str_dur|g" $dir_run/*
   sed -i "s|fmem_ph|$fmem|g" $dir_run/*
   sed -i "s|lmem_ph|$lmem|g" $dir_run/*

   chmod u+x rearr_modout.sh   
   ./rearr_modout.sh

   exit

fi


