#!/bin/bash
#SBATCH -N 1                            ## Ensure that all cores are on one machine
#SBATCH --comment=5160957624            ## Is het WUR projectnummer (5160957624 = CLIMAX)
#SBATCH --time=5000                     ## Na deze (echte) tijd in minuten wordt job in ieder geval beeindigd
#SBATCH --mem=4048                      ## Is het maximale geheugen in MByte; als de computer meer nodig heeft, beeindigt hij de job
#SBATCH --ntasks=1                      ## Aantal processoren
#SBATCH --output=output_%j.txt
#SBATCH --error=output_%j.txt
#SBATCH --job-name=monthlymean            
#SBATCH --qos=std                       ## Low kan eruitgegooid worden

finiyear=finiyear_ph
liniyear=liniyear_ph
finimth=finimth_ph
linimth=linimth_ph
fmem=fmem_ph
lmem=lmem_ph
forcing=forcing_ph
forc_vers=forc_vers_ph
domain=domain_ph
biascorr=biascorr_ph
str_dur=str_dur_ph
hydmodel=hydmodel_ph

for (( iniyear=$finiyear; iniyear <= $liniyear; iniyear++ ))
do

   for (( inimth=$finimth; inimth <= $linimth; inimth++ ))
   do

      if [ $inimth -lt 10 ]
      then
         nameinimth='0'$inimth
      else
         nameinimth=$inimth
      fi 

      for (( imem=$fmem; imem <= $lmem; imem++ ))
      do
      
         echo 'year = '$iniyear'  month = '$inimth'  member = '$imem
   
         if [ $imem -lt 10 ]
         then
            namemem='0'$imem
         else
            namemem=$imem
         fi
         
         diract='../ini'$iniyear$nameinimth'_dur'$str_dur'_E'$namemem
         cd $diract
         
         filein1='Output_ini'$iniyear$nameinimth'_dur'$str_dur
         filein2='_E'$namemem'.'$iniyear'-'$nameinimth'-01.nc'
         filein=$filein1$filein2
         
         if [ ! -e $filein ]
         then
            echo "Input file does not exist"
         fi
         
         fileout1='Output'$hydmodel'_'$forcing'_'$forc_vers'_'$domain'_'
         fileout2=$biascorr'_E'$namemem'_INIT'$iniyear'_'$nameinimth'_stats.nc4'
         fileout=$fileout1$fileout2
         
         filetemp1='beer.nc'
         cdo -s monavg $filein $filetemp1 

         ncrename -v 'OUT_BASEFLOW','qsb' $filetemp1
         ncrename -v 'OUT_DISCHARGE','dis' $filetemp1
         ncrename -v 'OUT_EVAP','evap' $filetemp1
         ncrename -v 'OUT_PET','potevap' $filetemp1
         ncrename -v 'OUT_PREC','prec' $filetemp1
         ncrename -v 'OUT_RUNOFF','qs' $filetemp1
         ncrename -v 'OUT_RAINF','rainf' $filetemp1
         ncrename -v 'OUT_SNOWF','snowf' $filetemp1
         ncrename -v 'OUT_SOIL_MOIST','soilmoist' $filetemp1
         ncrename -v 'OUT_SWE','swe' $filetemp1

         filetemp2='aap.nc'
         cdo expr,"runoff=qs+qsb;" $filetemp1 $filetemp2
         echo "add description to explain that runoff=qs+qsb"
         cdo -O merge $filetemp1 $filetemp2 $fileout
         
         rm $filetemp1
         rm $filetemp2
         
       done   # End of the loop over the members
       
   done   # End of the loop over the initial months
   
done   # End of the loop over the initial years

