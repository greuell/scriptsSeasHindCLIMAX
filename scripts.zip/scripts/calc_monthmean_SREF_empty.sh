#!/bin/bash
#SBATCH -N 1                            ## Ensure that all cores are on one machine
#SBATCH --comment=5160957624            ## Is het WUR projectnummer (5160957624 = CLIMAX)
#SBATCH --time=5000                     ## Na deze (echte) tijd in minuten wordt job in ieder geval beeindigd
#SBATCH --mem=4048                      ## Is het maximale geheugen in MByte; als de computer meer nodig heeft, beeindigt hij de job
#SBATCH --ntasks=1                      ## Aantal processoren
#SBATCH --output=output_%j.txt
#SBATCH --error=output_%j.txt
#SBATCH --job-name=monthlymean            
#SBATCH --qos=std                       ## Low kan eruitgegooid worden

finiyear=finiyear_ph
liniyear=liniyear_ph
finimth=finimth_ph
linimth=linimth_ph
str_dur=str_dur_ph
version=version_ph

allfiles=''
mkdir -p temporary

for (( iniyear=$finiyear; iniyear <= $liniyear; iniyear++ ))
do

   for (( inimth=$finimth; inimth <= $linimth; inimth++ ))
   do
   
      echo $iniyear   $inimth

      if [ $inimth -lt 10 ]
      then
         nameinimth='0'$inimth
      else
         nameinimth=$inimth
      fi 
   
      if [ $version == 'v0' ]
      then
         diract='ini'$iniyear$nameinimth'_dur'$str_dur'_E00/data/'
      else
         diract='ini'$iniyear$nameinimth'_dur'$str_dur'_E00/'
      fi
      filein1=$diract'Output_ini'$iniyear$nameinimth'_dur'$str_dur
      filein2='_E00.'$iniyear'-'$nameinimth'-01.nc'
      filein=$filein1$filein2
      
      filemthavg='temporary/mthavg'$iniyear$nameinimth'.nc'
      cdo -s monavg $filein $filemthavg
      
      allfiles=$allfiles$filemthavg' '

   done   # End of the loop over the initial months
   
done   # End of the loop over the initial years

fileallmthavgtemp='temporary/allmonthavg.nc'
cdo -O mergetime $allfiles $fileallmthavgtemp
ncrename -v 'OUT_BASEFLOW','qsb' $fileallmthavgtemp
ncrename -v 'OUT_DISCHARGE','dis' $fileallmthavgtemp
ncrename -v 'OUT_EVAP','evap' $fileallmthavgtemp
ncrename -v 'OUT_PET','potevap' $fileallmthavgtemp
ncrename -v 'OUT_PREC','prec' $fileallmthavgtemp
ncrename -v 'OUT_RUNOFF','qs' $fileallmthavgtemp
ncrename -v 'OUT_RAINF','rainf' $fileallmthavgtemp
ncrename -v 'OUT_SNOWF','snowf' $fileallmthavgtemp
ncrename -v 'OUT_SOIL_MOIST','soilmoist' $fileallmthavgtemp
ncrename -v 'OUT_SWE','swe' $fileallmthavgtemp

fileallmthavg_runoff='temporary/allmonthavg_runoff.nc'
fileallmthavg='allmonthavg.nc'
cdo expr,"runoff=qs+qsb;" $fileallmthavgtemp $fileallmthavg_runoff
         echo "add description to explain that runoff=qs+qsb"
         exit
cdo -O merge $fileallmthavgtemp $fileallmthavg_runoff $fileallmthavg

rm temporary/*
