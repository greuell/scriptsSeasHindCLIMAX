#!/bin/bash
#SBATCH -N 1                            ## Ensure that all cores are on one machine
#SBATCH --comment=5160957624            ## Is het WUR projectnummer (5160957624 = CLIMAX)
#SBATCH --time=5000                     ## Na deze (echte) tijd in minuten wordt job in ieder geval beeindigd
#SBATCH --mem=36000                     ## Is het maximale geheugen in MByte; als de computer meer nodig heeft, beeindigt hij de job
#SBATCH --ntasks=1                      ## Aantal processoren
#SBATCH --output=output_%j.txt
#SBATCH --error=output_%j.txt
#SBATCH --job-name=convert_to_VIC_forcing            
#SBATCH --qos=std                       ## Low kan eruitgegooid worden

# print date and time
date 

# Loops for different types of data are different,
#    namely static, i.e. data without temporal variation,
#    6-hourly and 24 hourly data
declare -a typevar=( 'static' '6' '24' )
ntypes=${#typevar[*]} 

iniyear=iniyear_ph                                                                                                 
inimth=inimth_ph                                                                                        
domain=domain_ph
lmem=lmem_ph
forcing=forcing_ph
forc_vers=forc_vers_ph
westb=westb_ph
eastb=eastb_ph
southb=southb_ph
northb=northb_ph
RawForcResol=RawForcResol_ph
biascorr=biascorr_ph
dirout=dirhere_ph
lus_backup=lus_backup_ph
dir_scripts=dir_scripts_ph
project=project_ph

# For later interpolation, the box has to be widened
northb_CDS=$(echo "$northb + $RawForcResol" | bc)
southb_CDS=$(echo "$southb - $RawForcResol" | bc)
westb_CDS=$(echo "$westb - $RawForcResol" | bc)
eastb_CDS=$(echo "$eastb + $RawForcResol" | bc)

nsecday=$((24*3600))

# Define and create (if needed: -p) directories and files
dir_bas=$lus_backup$project'/'$domain'/'
dir_paramfiles=$lus_backup'VIC/paramfiles/'

dirin=$lus_backup$project'/global/forcing/'$forcing'_'$forc_vers'/1degree_'$biascorr'/data/netcdf/'
dir_temp=$dirout'temporary/'
mkdir -p $dir_temp
rm -f $dir_temp/*

dir_stat_halfdeg=$dir_bas'static_data/'
mkdir -p $dir_stat_halfdeg
fileLandMask=$dir_stat_halfdeg'LandMask.nc'

dir_stat_1deg=$lus_backup$project'/'$domain'/forcing/'$forcing'_'$forc_vers'/1degree/staticdata/'
mkdir -p $dir_stat_1deg
fileSurfElev=$dir_stat_1deg'SurfElev.nc'

# make a grid for the regridding to 0.5 x 0.5 degrees
dirgrid=$dir_scripts'grids/'
filegrid=$dirgrid'grid_'$domain'.txt'

# this is only done if the file does not yet exist
if [ ! -e $filegrid ]
then

   file_emptygrid=$dirgrid'grid_empty.txt'
   cp $file_emptygrid $filegrid

   dgrid=$(echo "0.5" | bc)
   halfdgrid=$(echo "scale=8; 0.5 * $dgrid" | bc)
   dlon=$(echo "scale=8; $eastb - $westb" | bc)
   nlon=$(echo "$dlon / $dgrid" | bc)
   dlat=$(echo "scale=8; $northb - $southb" | bc)
   nlat=$(echo "$dlat / $dgrid" | bc)
   ncells=$((nlon*nlat))
   lonw=$(echo "$westb + $halfdgrid" | bc)
   lats=$(echo "$southb + $halfdgrid" | bc)

   sed -i "s|ncells_ph|$ncells|g" $filegrid
   sed -i "s|dgrid_ph|$dgrid|g" $filegrid
   sed -i "s|nlon_ph|$nlon|g" $filegrid
   sed -i "s|nlat_ph|$nlat|g" $filegrid
   sed -i "s|lonw_ph|$lonw|g" $filegrid
   sed -i "s|lats_ph|$lats|g" $filegrid
   
fi  

# Make a file with a mask for saving data more efficiently 
#    (only if the file does not yet exist)
if [ ! -e $fileLandMask ]
then

   file_rout_params_glob=$dir_paramfiles'routing_param_global.nc'
   fileRoutParams=$dir_stat_halfdeg'RoutParams_'$domain'.nc'
   fileDownstrID=$dir_stat_halfdeg'DownstrID_'$domain'.nc'

   cdo sellonlatbox,$westb,$eastb,$southb,$northb $file_rout_params_glob $fileRoutParams
   cdo select,name='downstream_id' $fileRoutParams $fileDownstrID 
   cdo ifthenc,1 $fileDownstrID $fileLandMask
   ncrename -v 'downstream_id','LandMask' $fileLandMask
   
fi

# Initialise presence of the following variables
PSeaL_pres='n'
PSurf_pres='n'
Tair_pres='n'
Tdew_pres='n'
Uwind_pres='n'
Vwind_pres='n'

#for iniyear in $(seq $finiyear $liniyear); do
#   for inimth in $(seq $finimth $linimth); do

      inimthstr=$inimth
      if [ "$inimth" -lt "10" ]
      then
         inimthstr='0'$inimth
      fi 
      
      all_files_6=''
      all_files_24=''
      nr_files_6=0
      nr_files_24=0
      
      # Loop over three types of data: 6-hourly, 24-hourly and static      
      for (( itype=0; itype < $ntypes; itype++ ))
      do

          typehere=${typevar[$itype]}
         
          if [ "$typehere" == "static" ]
          then
             declare -a varname=( 'orography' )
          elif [ "$typehere" == "6" ]
          then
             declare -a varname=( '2m_temperature' 'mean_sea_level_pressure' \
                                  '2m_dewpoint_temperature' '10m_u_component_of_wind' \
                                  '10m_v_component_of_wind' )
             nvar6=${#varname[*]}
             declare -a VICvarname6
          elif [ "$typehere" == "24" ]
          then
             declare -a varname=( 'total_precipitation' \
                                  'surface_solar_radiation_downwards' \
                                  'maximum_2m_temperature_in_the_last_24_hours' \
                                  'minimum_2m_temperature_in_the_last_24_hours' \
                                  'surface_thermal_radiation_downwards' )
             nvar24=${#varname[*]}
             declare -a VICvarname24
          fi                   

          nvartype=${#varname[*]}
          
          # The file with the surface elevation needs to be read only once
          if [ "$typehere" == "static" ]
          then
             if [ -e $fileSurfElev ]
             then
                continue
             fi
          fi

          # Loop over the variables
          for (( ivar=0; ivar < $nvartype; ivar++ ))
          do

             varhere=${varname[$ivar]}
                      
             echo 'year='$iniyear '  month='$inimth '  varhere='$varhere
         
             # All the data will be downloaded into and
             #     manipulated within a temporary directory
             cd $dir_temp

             # Settings for the various variables downloaded from the CDS:
             # CDSname:  name used on the CDS
             # unit:     unit of the variable required by VIC
             # parid:    parameter identifier on the CDS
             # longname: for the netcdf file (no spaces allowed in name)            
             # More info on
             #    https://confluence.ecmwf.int/display/COPSRV/List+of+requested+variables en op
             #    https://cds.climate.copernicus.eu/cdsapp#!/dataset/seasonal-original-single-levels?tab=overview
             # According to the last page, mean sea level pressure is an instantaneous value     
             case $varhere in
                '2m_temperature') CDSname='t2m'; unit='K'; parid=167; VICvarname='Tair'; longname='instantaneous_2_m_temperature' ;;
                '2m_dewpoint_temperature') CDSname='d2m'; unit='C'; parid=168; VICvarname='Tdew'; longname='instantaneous_2_m_dew_point_temperature' ;;
                '10m_u_component_of_wind') CDSname='u10'; unit='m/s'; parid=165; VICvarname='Uwind'; longname='instantaneous_10_m_u-component_of_wind_speed' ;;
                '10m_v_component_of_wind') CDSname='v10'; unit='m/s'; parid=166; VICvarname='Vwind'; longname='instantaneous_10_m_v-component_of_wind_speed' ;;
                'minimum_2m_temperature_in_the_last_24_hours') CDSname='mn2t24'; unit='C'; parid=52; VICvarname='Tmin'; longname='daily_minimum_2_m_temperature' ;;
                'maximum_2m_temperature_in_the_last_24_hours') CDSname='mx2t24'; unit='C'; parid=51; VICvarname='Tmax'; longname='daily_maximum_2_m_temperature' ;;
                'mean_sea_level_pressure') CDSname='msl'; unit='kPa'; parid=151; VICvarname='PSeaLevel'; longname='instantaneous_sea_level_pressure' ;;
                'orography') CDSname='z'; unit='m';  parid=129; VICvarname='SurfElev'; longname='surface_elevation' ;;
                'surface_solar_radiation_downwards') CDSname='ssrd'; unit='W/m2'; parid=169; VICvarname='SWdown'; longname='daily_mean_surface_incoming_solar_radiation' ;;
                'surface_thermal_radiation_downwards') CDSname='strd'; unit='W/m2'; parid=175; VICvarname='LWdown'; longname='daily_mean_surface_incoming_long-wave_radiation' ;;
                'total_precipitation') CDSname='tp'; unit='mm'; parid=228; VICvarname='Precip'; longname='daily_sum_of_precipitation' ;;
                *) exit 'No variable type assigned' ;;
             esac
         
             if [ "$typehere" == "6" ]
             then
                VICvarname6[$ivar]=$VICvarname
             elif [ "$typehere" == "24" ]
             then
                VICvarname24[$ivar]=$VICvarname
             fi

             # Name of the inputfile downloaded from the CDS for SEAS5
             if [ "$forcing" == "ecmwf" -a "$forc_vers" -eq "5" ]             
             then
                if [ "$typehere" == "static" ]
                then
                   filein=$dirin$typehere'/'$varhere'.nc'
                else
                   filein=$dirin$varhere'/S5_'$iniyear$inimthstr'01_'$parid'.nc'
                fi
             fi
 
             # Select the data for the specified domain. 
             # These data are written to file_region           
             file_region='file_region.nc'
             file_varhere='file_'$VICvarname'.nc'
             cdo sellonlatbox,$westb_CDS,$eastb_CDS,$southb_CDS,$northb_CDS $filein $file_region
             
             # Provide the correct longname, variable name and unit for VIC         
             # o: overwrite
             # c: create attribute
             # d: delete attribute
             ncrename -v $CDSname,$VICvarname $file_region
             ncatted -O -a long_name,$VICvarname,o,c,$longname $file_region
             ncatted -O -a unit,$VICvarname,o,c,$unit $file_region
             ncatted -O -a units,$VICvarname,d,, $file_region
             ncatted -O -a standard_name,$VICvarname,d,, $file_region

             # The file from the CDS is geopotential and hence needs to be divided
             #    by g to compute surface elevation, 
             #    according to Eduardo Penabad from CDS
             if [ "$varhere" == "orography" ]
             then
                cdo divc,9.81 $file_region $fileSurfElev
                continue

             # For each meteorological variable the contents of file_region is copied to
             #    file_varhere, often changing the unit or making other changes.               
             # The VIC input mostly has another unit
             #    than the data downloaded from the CDS,
             #    so the data must be converted
             elif [ "$varhere" == "total_precipitation" ]
             then
                cdo -b 64 mulc,1000.0 $file_region $file_varhere
             elif [ "$varhere" == "surface_solar_radiation_downwards" ]
             then
                cdo -b 64 divc,$nsecday $file_region $file_varhere
                elif [ "$varhere" == "surface_thermal_radiation_downwards" ]
             then
                cdo -b 64 divc,$nsecday $file_region $file_varhere
             elif [ "$varhere" == "mean_sea_level_pressure" ]
             then
                PSeaL_pres='y'
                cdo -b 64 divc,1000.0 $file_region $file_varhere
             elif [ "$varhere" == "2m_temperature" ]
             then
                Tair_pres='y'
                # The following statements are used to prepare the conversion
                #    of sea level pressure (CDS) to surface pressure (VIC).
                # The conversion depends on air temperature.
                cdo -b 64 div $fileSurfElev $file_region fileElevDivByTemp.nc
                cdo divc,-29.263 fileElevDivByTemp.nc fileFactExpPress.nc
                ncatted -O -a long_name,$VICvarname,o,c,'exponential_factor_for_calculation_surface_pressure_from_sea_level_pressure' fileFactExpPress.nc
                ncatted -O -a unit,$VICvarname,o,c,'m/K' fileFactExpPress.nc
                ncrename -v $VICvarname,FactExpPress fileFactExpPress.nc
                cdo -O merge $file_region fileFactExpPress.nc $file_varhere
             elif [ "$varhere" == "2m_dewpoint_temperature" ]
             then
                Tdew_pres='y'
                cdo -b 64 subc,273.15 $file_region $file_varhere
             elif [ "$varhere" == "maximum_2m_temperature_in_the_last_24_hours" ]
             then
                cdo -b 64 subc,273.15 $file_region $file_varhere
             elif [ "$varhere" == "minimum_2m_temperature_in_the_last_24_hours" ]
             then
                cdo -b 64 subc,273.15 $file_region $file_varhere
             elif [ "$varhere" == "10m_u_component_of_wind" ]
             then
                Uwind_pres='y'
                cp $file_region $file_varhere
             elif [ "$varhere" == "10m_v_component_of_wind" ]
             then
                Vwind_pres='y'
                cp $file_region $file_varhere
             else 
                cp $file_region $file_varhere
             fi

             # String is made with names of all files with 6-hourly data
             if [ "$typehere" == "6" ]
                then
                all_files_6=$all_files_6$file_varhere' '
                nr_files_6=$((nr_files_6+1))
             # String is made with names of all files with 24-hourly data
             elif [ "$typehere" == "24" ]
             then
                all_files_24=$all_files_24$file_varhere' '
                nr_files_24=$((nr_files_24+1))
             fi

             rm $file_region
             last_VICvarname=$VICvarname

          done   # End of the loop over the variables
          
      done   # End of the loop over the type of variables

      # Compute surface pressure with the equation from
      #    https://www.sandhurstweather.org.uk/barometric.pdf     
      # All of the following equations have been checked and found ok (01-11-18)     
      if [ "$PSeaL_pres" == "y" -a "$Tair_pres" == "y" ]
      then 
         echo 'year='$iniyear '  month='$inimth '  varhere=Psurf'
         cdo -O merge file_PSeaLevel.nc file_Tair.nc file_compPSurf.nc
         cdo expr,'PSurf=PSeaLevel*exp(FactExpPress);' file_compPSurf.nc file_PSurf.nc
         ncatted -O -a long_name,PSurf,o,c,'surface_pressure' file_PSurf.nc
         ncatted -O -a unit,PSurf,o,c,'kPa' file_PSurf.nc
         all_files_6=$all_files_6'file_PSurf.nc '
         nr_files_6=$((nr_files_6+1))
         PSurf_pres='y'
      fi
      
      # Vapor pressure is computed with the equation of Tetens,
      #    copied from https://en.wikipedia.org/wiki/Vapour_pressure_of_water
      # Finally, the humidity mixing ratio is computed
      if [ $Tdew_pres == 'y' ]
      then 
         echo 'year='$iniyear '  month='$inimth '  varhere=Vappr'
         cdo expr,'Vappr=0.61078*exp(17.27*Tdew/(Tdew+237.3));' file_Tdew.nc file_Vappr.nc      
         ncatted -O -a long_name,Vappr,o,c,'2_m_vapor_pressure' file_Vappr.nc
         ncatted -O -a unit,Vappr,o,c,'kPa' file_Vappr.nc
         all_files_6=$all_files_6'file_Vappr.nc '
         nr_files_6=$((nr_files_6+1))
      fi
 
      # Compute the 10 m wind speed from its u and v components     
      if [ $Uwind_pres == 'y' -a $Vwind_pres == 'y' ]
      then
         echo 'year='$iniyear '  month='$inimth '  varhere=Wind'
         cdo -O merge file_Uwind.nc file_Vwind.nc file_twocompWind.nc
         cdo expr,'Wind=sqrt(sqr(Uwind)+sqr(Vwind));' file_twocompWind.nc file_Wind.nc
         ncatted -O -a long_name,Wind,o,c,'10_m_wind_speed' file_Wind.nc
         ncatted -O -a unit,Wind,o,c,'m/s' file_Wind.nc
         all_files_6=$all_files_6'file_Wind.nc '
         nr_files_6=$((nr_files_6+1))
      fi
      
      # Calculation of the water vapour mixing ratio, 
      #    i.e. weight of vapour divided by weight of dry air
      if [ $Tdew_pres == 'y' -a $PSurf_pres == 'y' ]
      then
         echo 'year='$iniyear '  month='$inimth '  varhere=Qair'
         cdo -O merge file_Vappr.nc file_PSurf.nc file_compQair.nc
         cdo expr,'Qair=0.622*Vappr/(PSurf-Vappr);' file_compQair.nc file_Qair.nc
         ncatted -O -a long_name,Qair,o,c,'2_m_water_vapor_mixing_ratio' file_Qair.nc
         ncatted -O -a unit,Qair,o,c,'kg/kg' file_Qair.nc
         all_files_6=$all_files_6'file_Qair.nc '
         nr_files_6=$((nr_files_6+1))
      fi

      echo 'year='$iniyear '  month='$inimth '  Daily averages'
      # Daily averages are calculated for all variables with 6-hourly data      
      if [ "$nr_files_6" -ne "0" ]
      then
         if [ "$nr_files_6" -eq "1" ]
         then
            cp $all_files_6 file_allvar6.nc
         else
            cdo -O merge $all_files_6 file_allvar6.nc
         fi
         # This type of variable is present as momentaneous values
         #    at 6, 12, 18, 24, 36 hours etc.
         # For computing daily means, the values are shifted by 3 hours,
         #    so that each daily mean is the mean of 4 values
         cdo shifttime,-3hour file_allvar6.nc file_allvar6_timesh.nc
         # The time stamp of dayavg is at midday
         cdo dayavg file_allvar6_timesh.nc file_dayavg6.nc
      fi
      
      # Daily averages are calculated for all variables with 24-hourly data      
      if [ "$nr_files_24" -ne "0" ]
      then
         if [ "$nr_files_24" -eq "1" ]
         then
            cp $all_files_24 file_allvar24.nc
         else
            cdo -O merge $all_files_24 file_allvar24.nc
         fi
         # This type of variable is the sum over the past 24 hours.
         # For synchronisation with the 6-hourly values,
         #    the timeZZ axis is shifted by 12 hours
         cdo shifttime,-12hour file_allvar24.nc file_allvar24_timesh.nc
         cp file_allvar24_timesh.nc file_dayavg24.nc
      fi
      
      # A file with daily averages of all variables is produced
      if [ -e file_dayavg6.nc -a  -e file_dayavg24.nc ]
      then
         cdo -O merge file_dayavg6.nc file_dayavg24.nc file_dayavg.nc
      else
         if [ -e file_dayavg6.nc ]
         then
            cp file_dayavg6.nc file_dayavg.nc
         elif [ -e file_dayavg24.nc ]
         then
            cp file_dayavg24.nc file_dayavg.nc
         fi
      fi

      # the cdo module dayavg adds the variable time_bnds,
      #    which can be nasty in subsequent cdo actions,
      #    cannot be removed with cdo delete amd is hence 
      #    removed with ncks
      # ncks -C -O -x -v time_bnds file_dayavg.nc file_dayavg.nc 

      echo 'year='$iniyear '  month='$inimth '  Regridding'
      # Remapping to half degree
      # and keeping only the data for the cells defined by the land mask
      # file_interpol.nc was checked and found ok on 11-27-2018                       
      cdo remapbil,$filegrid file_dayavg.nc file_interpol_nomask.nc
      cdo mul file_interpol_nomask.nc $fileLandMask file_interpol.nc
      # Remove variable time_bnds from file
      # ncks -C -O -x -v time_bnds file_interpol_TB.nc file_interpol.nc
      
      # Separation of the ensembles into members 
      for imem in $(seq 1 $lmem); do
      
         echo 'year='$iniyear '  month='$inimth '  member='$imem

         if [ "$imem" -lt "10" ] 
         then
            mem_name='E0'$imem
         else
            mem_name='E'$imem
         fi

         # Select the member (the ensemble dimension of the data
         #    is the vertical dimension in the CDS files)
         #    and put it in a file only containing this member
         filemem_temp=$mem_name'.nc'
         cdo select,levidx=$imem file_interpol.nc $filemem_temp
         cdo -f nc4c -z zip splitname $filemem_temp $mem_name'_alltm_'
                 
         # Some of the 24-hourly variables are stored as cumulations 
         #    over forecast time on the CDS 
         #    and hence need to be recalculated to daily sums or daily fluxes 
         # The de-cumulation part was checked on 29-11-2018 and found ok       
         for (( ivar24=0; ivar24 < $(($nvar24)); ivar24++ ))
         do
         
             parhere=${VICvarname24[$ivar24]}
             cumul='n'         
             case $parhere in
                'Tmin') cumul='n' ;;
                'Tmax') cumul='n' ;;
                'SWdown') cumul='y' ;;
                'LWdown') cumul='y' ;;
                'Precip') cumul='y' ;;
                *) exit 'No parameter assigned' ;;
             esac
             
             if [ "$cumul" == "y" ]
             then
                file_cum=$mem_name'_alltm_'$parhere'.nc'
                cdo shifttime,+1day $file_cum file_shift.nc
                cdo select,timestep=1 $file_cum file1.nc
                cdo delete,timestep=1 $file_cum file2.nc
                cdo delete,timestep=-1 file_shift.nc file3.nc
                cdo sub file2.nc file3.nc file4.nc
                cdo -f nc4c -z zip -O mergetime file1.nc file4.nc file5.nc
                cp file5.nc $file_cum
             fi
         
         done    # End of the loop over the 24-hour variables 

         # Files for a number of variables will not be used any more
         #    and are hence removed
         rm -f $mem_name'_alltm_FactExpPress.nc'        
         rm -f $mem_name'_alltm_PSeaLevel.nc'        
         rm -f $mem_name'_alltm_Tdew.nc'        
         rm -f $mem_name'_alltm_Uwind.nc'        
         rm -f $mem_name'_alltm_Vwind.nc' 
                
         # Save the result
         dirout_mem=$dirout$mem_name'/'
         mkdir -p $dirout_mem         
         cp $mem_name'_'* $dirout_mem
         
         # Split files in month files (for the bias correction)
         files_split=$(ls $dirout_mem*_alltm_*)
         for f in $files_split
         do
            newf=${f/_alltm_/_}
            mv $f $newf
            #outf=$(echo $newf | cut -f 1 -d '.')
            #cdo splitmon $newf $outf
         done
         
      done   # End of the loop over the members
      
      echo ' '

      rm *
 
#    done   # End of the loop over the months of the year
   
#done   # End of the loop over the years

  
