rm(list=ls())

library (ncdf4)

Year <- 1984
VarName3hr <- "vp"   # lwdown or wind
ilat <- 70
ilon <- 50
daybeg <- 100
dayend <- 104
nday <- dayend - daybeg + 1

ntday <- 8
itbeg <- (daybeg - 1) * ntday + 1
itend <- dayend * ntday
time_3hr_beg <- daybeg + 0.5 / ntday
time_3hr_end <- (dayend + 1) - 0.5 / ntday
time_3hr <- seq (time_3hr_beg, time_3hr_end, length.out = (ntday * nday))
time_day_beg <- daybeg + 0.5 
time_day_end <- dayend + 0.5 
time_day <- seq (time_day_beg, time_day_end, length.out = nday)

if (VarName3hr == "lwdown") VarNameDay <- "LWdown"
if (VarName3hr == "pr")     VarNameDay <- "Precip"
if (VarName3hr == "psurf")  VarNameDay <- "PSurf"
if (VarName3hr == "swdown") VarNameDay <- "SWdown"
if (VarName3hr == "tas")    VarNameDay <- "Tmin"
if (VarName3hr == "vp")     VarNameDay <- "Evappr"
if (VarName3hr == "wind")   VarNameDay <- "Wind"

DirBase <- "/lustre/backup/WUR/ESG/greue002/CLIMAX/SA/forcing/WFDEI_aug2018/"
Dir3hr <- paste (DirBase, "halfdegree_noBC_3hdisaggr/data/", sep = "")
DirDay <- paste (DirBase, "halfdegree_noBC_daily/data/", sep = "")

File3hr <- paste (Dir3hr, VarName3hr, "_", Year, ".nc", sep = "") 
Nc3hr <- nc_open (File3hr)
Var3hr <- ncvar_get (Nc3hr, varid = VarName3hr)
Lat <- ncvar_get (Nc3hr, varid = "lat")
Lon <- ncvar_get (Nc3hr, varid = "lon")
Var3hrGp <- Var3hr[ilon, ilat, itbeg:itend]

FileDay <- paste (DirDay, VarNameDay, "_", Year, ".nc", sep = "") 
NcDay <- nc_open (FileDay)
VarDay <- ncvar_get (NcDay, varid = VarNameDay)
VarDayGp <- VarDay[ilon, ilat, daybeg:dayend]

FileDay3hr <- paste (Dir3hr, VarName3hr, "_dayavg_", Year, ".nc", sep = "") 
NcDay3hr <- nc_open (FileDay3hr)
VarDay3hr <- ncvar_get (NcDay3hr, varid = VarName3hr)
VarDay3hrGp <- VarDay3hr[ilon, ilat, daybeg:dayend]

maxval <- max (c (Var3hrGp, VarDayGp)) 
minval <- min (c (Var3hrGp, VarDayGp))
lim_yaxis <- c (minval, maxval)  

# if (VarName3hr == "pr") VarDayGp <- VarDayGp / ntday

dev.new (width = 15, height = 7)
		 
plot (time_3hr, Var3hrGp, type = "b", col = "blue", xlab = "Julian day",
      cex.lab = 1.5, ylab = VarName3hr, ylim = lim_yaxis)
lines (time_day, VarDayGp, type = "p", col = "red", cex = 2)
lines (time_day, VarDay3hrGp, type = "p", col = "darkgreen", cex = 2)

if (VarName3hr == "tas") {

   FileDay2 <- paste (DirDay, "Tmax", "_", Year, ".nc", sep = "") 
   NcDay2 <- nc_open (FileDay2)
   VarDay2 <- ncvar_get (NcDay2, varid = "Tmax")
   VarDayGp2 <- VarDay2[ilon, ilat, daybeg:dayend]
   lines (time_day, VarDayGp2, type = "p", col = "red", cex = 2)

   FileDay3 <- paste (DirDay, "Tair", "_", Year, ".nc", sep = "") 
   NcDay3 <- nc_open (FileDay3)
   VarDay3 <- ncvar_get (NcDay3, varid = "Tair")
   VarDayGp3 <- VarDay3[ilon, ilat, daybeg:dayend]
   lines (time_day, VarDayGp3, type = "p", col = "orange", cex = 2)

   File3hrSW <- paste (Dir3hr, "swdown", "_", Year, ".nc", sep = "") 
   Nc3hrSW <- nc_open (File3hrSW)
   SW3hr <- ncvar_get (Nc3hrSW, varid = "swdown")
   SW3hrGp <- SW3hr[ilon, ilat, itbeg:itend]

   maxSW <- max (SW3hrGp)
   SW3hrGpTf <- minval + SW3hrGp / maxSW * (maxval - minval)
   lines (time_3hr, SW3hrGpTf, type = "b", col = "purple")

}

for (iday in (daybeg:(dayend+1))) abline (v = iday)

mean3hr <- mean (Var3hrGp)
meanDay <- mean (VarDayGp)

print (paste ("Mean3hr = ", mean3hr, "   Meanday = ", meanDay))

stop ("fut")
