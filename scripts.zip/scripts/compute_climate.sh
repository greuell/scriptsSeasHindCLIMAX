#!/bin/bash

# produce climate data

vartype="hydro"      # can be either meteo (forcing) or 
                     #    hydro (output of the hydrological model)
datatype="obs"       # can be either obs (observations) or hdc (hindcasts).

                     # meteo and obs: WFDEI
                     # meteo and hdc: SEAS5
                     # hydro and obs: pseudo-observations of streamflow etc.
                     #                generated with the reference simulation 
                     # hydro and hdc: output of VIC forced with SEAS5

begyear=1981
endyear=2015

years=""
for (( year=$begyear; year <= $endyear; year++ ))
do
   years=$years","$year
done

if [ "$vartype" == "meteo" ]
then

   if [ "$datatype" == "obs" ]
   then
      declare -a varname=( 'Evappr' 'LWdown' 'Precip' 'PSurf' 'Qair' \
                           'Tair' 'SWdown' 'Tmax' 'Tmin' 'Wind' )
      source='WFDEI'
      source_vers='aug2018'
      dur=1
      lmem=0
   elif [ "$datatype" == "hdc" ]
   then
      declare -a varname=( 'Precip' )
      clim_model='ecmwf'
      clim_model_vers='5'
      dur=7
      lmem=25
   fi
   
elif [ "$vartype" == "hydro" ]
then

   declare -a varname=( 'runoff'  'qs' 'qsb' 'dis' 'evap' 'prec' \
                        'soilmoist' 'swe' )
   hyd_model='VIC'
   version='v1'

   if [ "$datatype" == "obs" ]
   then
      forcing='WFDEI'
      forc_vers='aug2018'
      spec_run='std'
      dur=1
      lmem=0
   elif [ "$datatype" == "hdc" ]
   then
      forcing='ecmwf'
      forc_vers='5'
      spec_run='Full'
      dur=7
      lmem=25
   fi
   
fi
      
nvar=${#varname[*]} 

nmth=12
biascorr='noBC'
resolution='halfdegree'
domain='SA'

lus_backup='/lustre/backup/WUR/ESG/greue002/'
dir_domain=$lus_backup'CLIMAX/'$domain'/'

filename=$dir_domain'/static_data/regboundaries.txt'
declare -a array=()
n=1
while read line; do
# reading each line
array[n]=$line
n=$((n+1))
done < $filename

nreg=${array[1]}
declare -a namereg=()
declare -a latmax=()
declare -a lonmax=()
declare -a latmin=()
declare -a lonmin=()

for (( ireg=0; ireg < $nreg; ireg++ ))
do

   i=$((ireg*5+2))
   namereg[ireg]=${array[i]}
   i=$((ireg*5+3))
   latmax[ireg]=${array[i]}
   i=$((ireg*5+4))
   lonmax[ireg]=${array[i]}
   i=$((ireg*5+5))
   latmin[ireg]=${array[i]}
   i=$((ireg*5+6))
   lonmin[ireg]=${array[i]}
   
done

maxlead=$((dur-1))

if [ "$vartype" == "meteo" ]
then
   if [ "$datatype" == "obs" ]
   then   
      dir_vartype=$dir_domain'forcing/'$source'_'$source_vers'/'   
      dirin=$dir_vartype$resolution'_noBC_daily/data/'
   elif [ "$datatype" == "hdc" ]
   then
      dir_vartype=$dir_domain'forcing/'$clim_model'_'$clim_model_vers'/'   
      dirin=$dir_vartype$resolution'_noBC_monthly_leadtime/'
   fi
elif [ "$vartype" == "hydro" ]
then
   if [ "$datatype" == "obs" ]
   then   
      dir_vartype=$dir_domain$hyd_model'/'$forcing'_'$forc_vers'/'   
      dirin=$dir_vartype$resolution'_'$spec_run'_SREF_'$biascorr'_'$version'/'
   elif [ "$datatype" == "hdc" ]
   then
      dir_vartype=$dir_domain'forcing/'$clim_model'_'$clim_model_vers'/'   
      dirin=$dir_vartype$resolution'_'$spec_run'_SH_'$biascorr'_'$version'/'
   fi
fi

dirout=$dirin'climate/data/'
dirouttemp=$dirout'temp/'

mkdir -p $dirout
mkdir -p $dirouttemp

for (( ivar=0; ivar < $nvar; ivar++ ))
do

   varhere=${varname[$ivar]}
   echo $varhere
   
   for (( lead=0; lead <= $maxlead; lead++ ))
   do

      if [ "$datatype" == "obs" ]   
      then

         if [ "$vartype" == "meteo" ]
         then
            fileinallyears=$dirin$varhere'.nc'
         elif [ "$vartype" == "hydro" ]
         then
            filein_allvar=$dirin'allmonthavg.nc'
            fileinallyears=$dirin'monthavg_'$varhere'.nc'
            cdo --no_history -s selname,$varhere $filein_allvar $fileinallyears
         fi
         
         fileymonavg_b=$dirout$varhere'_ymonavg'
         fileymonstd_b=$dirout$varhere'_ymonstd'
         fileymoncfv_b=$dirout$varhere'_ymoncfv'

      elif [ "$datatype" == "hdc" ]
      then

         if [ "$vartype" == "hydro" ]
         then
            echo "hindcasts of hydrological variables still need to be programmed"
         fi

         filemem1=$dirin$varhere'mean_monthly_'$forcing'_'$forc_vers'_'
         filemem2=$forcing'_'$forc_vers'_'$domain'_'$biascorr'_E'

         files_all_mem=''
      
         for (( mem=1; mem <= $lmem; mem++ ))
         do
      
            if [ "$mem" -lt "10" ]
            then
               str_mem='0'$mem
            else
               str_mem=$mem
            fi

            filemem3=$str_mem'_lead'$lead'.nc4'
            filemem=$filemem1$filemem2$filemem3
            
            files_all_mem=$files_all_mem$filemem' '
            
         done

         fileinallyears=$dirin$varhere'_median_of_mean_monthly_lead'$lead'.nc4' 
         
         cdo --no_warnings -O -s enspctl,50 $files_all_mem $fileinallyears
         
         fileymonavg_b=$dirout$varhere'_lead'$lead'_ymonavg'
         fileymonstd_b=$dirout$varhere'_lead'$lead'_ymonstd'
         fileymoncfv_b=$dirout$varhere'_lead'$lead'_ymoncfv'

      fi

      # Select years
      filein=$dirouttemp'filein.nc'
      cdo -s selyear$years $fileinallyears $filein
      
      fileymonavg=$fileymonavg_b'_'$begyear'-'$endyear'.nc'
      fileymonstd=$fileymonstd_b'_'$begyear'-'$endyear'.nc'
      fileymoncfv=$fileymoncfv_b'_'$begyear'-'$endyear'.nc'

      cdo --no_history -s ymonavg $filein $fileymonavg
      # Het volgende statement levert een foutief resultaat op
      # cdo ymonstd $filein $fileymonstd

      # Derhalve reken ik via een omweg
      filemonavg=$dirouttemp'monavg.nc'
      cdo -s monavg $filein $filemonavg
      
      # Compute standard deviation of all values for January, February, etc. 
      files_all_std=''
           
      for (( mth=1; mth <= $nmth; mth++ ))
      do

         mthstr=$mth
         if [ "$mth" -lt "10" ]
         then
            mthstr='0'$mth
         fi 
         
         date='2000-'$mthstr'-01'
   
         filemth=$dirouttemp'selmonth'$mth'.nc'
         cdo -s selmonth,$mth $filemonavg $filemth
         filemthstd=$dirouttemp'stdmonth'$mth'.nc'
         cdo -s timstd $filemth $dirouttemp'aap.nc'
         cdo --no_warnings -s setdate,$date $dirouttemp'aap.nc' $filemthstd
         files_all_std=$files_all_std$filemthstd' '
         
      done
      
      cdo -O -s mergetime $files_all_std $fileymonstd 
      cdo -s div $fileymonstd $fileymonavg $fileymoncfv
      
      # Compute regional means      
      for (( ireg=0; ireg < $nreg; ireg++ ))
      do

         reghere=${namereg[$ireg]}

         if [ "$ireg" != 0 ]
         then
            coor1=${lonmin[$ireg]}
            coor2=${lonmax[$ireg]}
            coor3=${latmin[$ireg]}
            coor4=${latmax[$ireg]}
            fileymonavgreg=$dirouttemp'ymonavgreg'$ireg'.nc'
            cdo -s sellonlatbox,$coor1,$coor2,$coor3,$coor4 $fileymonavg $fileymonavgreg
            fileymonstdreg=$dirouttemp'ymonstdreg'$ireg'.nc'
            cdo -s sellonlatbox,$coor1,$coor2,$coor3,$coor4 $fileymonstd $fileymonstdreg
         else
            fileymonavgreg=$fileymonavg
            fileymonstdreg=$fileymonstd
         fi
         
         fileymoncfvreg=$dirouttemp'ymoncfvreg'$ireg'.nc'
         cdo -s div $fileymonstdreg $fileymonavgreg $fileymoncfvreg
 
         fileymonavgregmean=$fileymonavg_b'_'$begyear'-'$endyear'_'$reghere'_mean.nc'
         cdo --no_history -s fldmean $fileymonavgreg $fileymonavgregmean
         fileymonstdregmean=$fileymonstd_b'_'$begyear'-'$endyear'_'$reghere'_mean.nc'
         cdo --no_history -s fldmean $fileymonstdreg $fileymonstdregmean
         fileymoncfvregmean=$fileymoncfv_b'_'$begyear'-'$endyear'_'$reghere'_mean.nc'
         cdo --no_history -s fldmean $fileymoncfvreg $fileymoncfvregmean
      done
      
      rm $dirouttemp/*
      
   done    # End of the loop over the lead times
   
done    # End of the loop over the variables
