#!/bin/bash
#SBATCH -N 1                            ## Ensure that all cores are on one machine
#SBATCH --comment=5120776-01            ## Is het WUR projectnummer (5120867-01 = Euporias; 5120776-01 = IMPACT2C)
#SBATCH --time=5000                     ## Na deze (echte) tijd in minuten wordt job in ieder geval beeindigd
#SBATCH --mem=12144                     ## Is het maximale geheugen in MByte; als de computer meer nodig heeft, beeindigt hij de job
#SBATCH --ntasks=1                      ## Aantal processoren
#SBATCH --output=output_%j.txt
#SBATCH --error=error_output_%j.txt
#SBATCH --job-name=test_cdo_ifthen            
#SBATCH --partition=ESG_Std             ## Low kan eruitgegooid worden

# print date and time
date

nloops=100

for (( iloop=0; iloop < $nloops; iloop++ ))
do

   echo 'loop number '$iloop 
   cd /lustre/backup/WUR/ESG/greue002/CLIMAX/SA/forcing/ecmwf_SEAS5
   fileout=aap'_'$iloop'_nc'
   cdo ifthen 1degree_noBC/static/LandMask.nc 1degree_noBC/data/temporary/file_interpol_nomask.nc $fileout
   
done
