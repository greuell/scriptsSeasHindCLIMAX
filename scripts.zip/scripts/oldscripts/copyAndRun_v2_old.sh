#!/bin/bash

# Input parameters die je vaak aanpast 
typerun='SREF'       # SREF (streamflow reference) of SH (Streamflow Hindcasts) 

acq_forc='n'         # download forcing for SH (forcing for SREF should be on server)
make_forc='y'        # make forcing for VIC; among others from daily to 3-hourly
make_parfiles='n'    # make parameter files 
run_hydmodel='n'     # run the hydrological model

batch='n'

# Input parameters die je bijna nooit aanpast
hydmodel='VIC'
domain='SA'
version='v0'               # normaal 'v0'; anders bij overdoen of met andere settings,
                           #    bijvoorbeeld met human inpacts

VICdt_hrs=24

if [ "$typerun" == "SREF" ]
then
   forcing='WFDEI'
   forc_vers='aug2018'
   spec_run='std'          # normaal 'std'; anders als je ooit experimenteert 
                           #    met de referentierun
   biascorr='noBC'
   finiyear=1979
   liniyear=2016
   fmem=0
   lmem=0
   if [ "$forcing" == "WFDEI" ]
   then
      prectype='GPCC'
   fi
   dur=1
elif [ "$typerun" == "SH" ]
then
   forcing='ecmwf'
   forc_vers='SEAS5'
   spec_run='Full'         # Full, Init, InitSM, InitSn of Meteo
   biascorr='BC'
   liniyear=2016
   fmem=1
   if [ "$forcing" == "ecmwf" ] && [ "$forc_vers" == "SEAS5" ]
   then
      finiyear=1981
      lmem=25
      dur=7
      if [ "$acq_forc" == "y" ]
      then
         resol='1'
         resol_str=$resol'degree'
         biascorr='noBC'
      fi
   fi
fi

iniday=1
lengthmth_ref=(0 31 28 31 30 31 30 31 31 30 31 30 31)

if [ "$domain" == "SA" ]
then
   westb=-83.5
   eastb=-32.5
   southb=-58.0
   northb=14.5
fi

if [ "$dur" -lt "10" ]
then
   str_dur='0'$dur
else
   str_dur=$dur
fi

dir_scripts='/home/WUR/greue002/CLIMAX/scripts/'
lus_backup='/lustre/backup/WUR/ESG/greue002/'
dir_paramfiles=$lus_backup'VIC/paramfiles/'
sourcePath=$(pwd)
dir_bas=$lus_backup'CLIMAX/'$domain'/'

if [ "$run_VIC" == "y" ]
then
   dir_runsbas=$dir_outbas'/'$hydmodel'/'$typerun'_runs/'
   dir_set_p1=$domain'_'$forcing'_'$forc_vers'_'$spec_run'_'$typerun'_'
   dir_set_p2=$biascorr'_'$version'/'
   dir_set=$dir_runsbas$dir_set_p1$dir_set_p2
   mkdir -p $dir_set
fi

if [ "$acq_forc" == "y" ]
then
   dir_forcbas=$dir_bas'forcing/'
   dir_acqforcbas=$dir_forcbas$forcing'_'$forc_vers'/'$resol_str'_'$biascorr'/'
   dir_acqforcrun=$dir_acqforcbas'run/'
   dir_acqforcoutput=$dir_acqforcbas'output/'
   dir_acqforcstatic=$dir_acqforcbas'static/'
   dir_forcadj=$dir_forcbas$forcing'_'$forc_vers'/halfdegree_'$biascorr'_daily/'
   mkdir -p $dir_acqforcbas
   mkdir -p $dir_acqforcrun
   mkdir -p $dir_acqforcoutput
   mkdir -p $dir_acqforcstatic
   mkdir -p $dir_forcadj
   
   cp acq_forcing_CDS_empty.sh $dir_acqforcrun/acq_forcing_CDS.sh
   cp form_acq_forc6_empty.py $dir_acqforcrun/form_acq_forc6_all.py 
   cp form_acq_forc24_empty.py $dir_acqforcrun/form_acq_forc24_all.py 
   cp form_acq_stat_empty.py $dir_acqforcrun/form_acq_stat_all.py 
   cd $dir_acqforcrun
   
   northb_downl=$(echo "$northb + $resol" | bc)
   southb_downl=$(echo "$southb - $resol" | bc)
   eastb_downl=$(echo "$eastb + $resol" | bc)
   westb_downl=$(echo "$westb - $resol" | bc)

   sed -i "s|dir_acqforcstatic_ph|$dir_acqforcstatic|g" $dir_acqforcrun/*
   sed -i "s|dir_acqforcoutput_ph|$dir_acqforcoutput|g" $dir_acqforcrun/*
   sed -i "s|dir_acqforcrun_ph|$dir_acqforcrun|g" $dir_acqforcrun/*
   sed -i "s|northb_downl_ph|$northb_downl|g" $dir_acqforcrun/*
   sed -i "s|southb_downl_ph|$southb_downl|g" $dir_acqforcrun/*
   sed -i "s|westb_downl_ph|$westb_downl|g" $dir_acqforcrun/*
   sed -i "s|eastb_downl_ph|$eastb_downl|g" $dir_acqforcrun/*
   sed -i "s|dir_forcadj_ph|$dir_forcadj|g" $dir_acqforcrun/*
   sed -i "s|dir_scripts_ph|$dir_scripts|g" $dir_acqforcrun/*
   sed -i "s|finiyear_ph|$finiyear|g" $dir_acqforcrun/*
   sed -i "s|liniyear_ph|$liniyear|g" $dir_acqforcrun/*
   sed -i "s|forcing_ph|$forcing|g" $dir_acqforcrun/*
   sed -i "s|str_dur_ph|$str_dur|g" $dir_acqforcrun/*
   sed -i "s|domain_ph|$domain|g" $dir_acqforcrun/*
   sed -i "s|southb_ph|$southb|g" $dir_acqforcrun/*
   sed -i "s|northb_ph|$northb|g" $dir_acqforcrun/*
   sed -i "s|westb_ph|$westb|g" $dir_acqforcrun/*
   sed -i "s|eastb_ph|$eastb|g" $dir_acqforcrun/*
   sed -i "s|resol_ph|$resol|g" $dir_acqforcrun/*
   sed -i "s|lmem_ph|$lmem|g" $dir_acqforcrun/*
   
   if [ "$batch" == "y" ]
   then
      sbatch ./acq_forcing_CDS.sh
   else
      ./acq_forcing_CDS.sh
   fi
   exit
fi

if [ "$make_parfiles" == "y" ]
then
   n_tasks=1
   par_file_glob=$dir_paramfiles'domain_global.nc'
   par_file_reg=$dir_paramfiles'domain_'$domain'.nc'
   ncks -d lon,$westb,$eastb -d lat,$southb,$northb $par_file_glob -O $par_file_reg   
   par_file_glob=$dir_paramfiles'routing_param_global.nc'
   par_file_reg=$dir_paramfiles'routing_param_'$domain'.nc'
   ncks -d lon,$westb,$eastb -d lat,$southb,$northb $par_file_glob -O $par_file_reg   
   par_file_glob=$dir_paramfiles'VIC_params_global.nc'
   par_file_reg=$dir_paramfiles'VIC_params_'$domain'.nc'
   ncks -d lon,$westb,$eastb -d lat,$southb,$northb $par_file_glob -O $par_file_reg   
   exit
elif [ "$make_forc" == "y" ]
then
   n_tasks=1
elif [ "$run_hydmodel" == "y" ]
then
   n_tasks=10
fi

if [ "$typerun" == "SREF" ] && [ "$make_forc" == "y" ]
then






for imem in $(seq $fmem $lmem); do

   if [ "$imem" -lt "10" ]
   then
      str_mem='0'$imem
   else
      str_mem=$imem
   fi

   for iniyear in $(seq $finiyear $liniyear); do
      for inimth in $(seq 1 12); do
 
         # In het geval van de referentierun wordt de gehele forcering
         #    in één keer aangemaakt      
         if [ "$typerun" == "SREF" ] && [ "$make_forc" == "y" ]
         then
            if [ "$iniyear" -ne "$finiyear" ] || [ "$inimth" -ne "1" ]
            then
               continue
            fi
         fi 

         echo $inimth   $iniyear

         # Bepaal variabelen voor filenamen en parameters     
         if [ "$inimth" -lt "10" ]
         then
            str_inimth='0'$inimth
         else
            str_inimth=$inimth
         fi
         
         ltarmth=$((inimth+dur-1))
         ltaryear=$iniyear
         if [ "$ltarmth" -gt "12" ]
         then
            ltarmth=$((ltarmth-12))
            ltaryear=$((ltaryear+1))
         fi

         if [ "$((ltaryear % 4))" -eq "0" ] && [ "$ltarmth" -eq "2" ] 
         then   
            ltarday=29
         else
            ltarday=${lengthmth_ref[$ltarmth]}
         fi

         saveday=1
         savemth=$((ltarmth+1))
         if [ "$savemth" -gt "12" ]
         then
            savemth=1
            saveyear=$((ltaryear+1))
         else
            saveyear=$ltaryear
         fi
         
         if [ "$typerun" == "SREF" ]
         then
            if [ "$iniyear" -eq "$finiyear" ] && [ "$inimth" -eq "1" ]
            then
               read_init_state='n'      # read initial state
            else
               read_init_state='y'
            fi
            save_state='y'
         else
            read_init_state='y'
            save_state='n'
         fi 
         
         if [ "$read_init_state" == "y" ]
         then
            ris_hd=""
         else
            ris_hd="#"
         fi

         if [ "$save_state" == "y" ]
         then
            ss_hd=""
         else
            ss_hd="#"
         fi
         
         # Bepaal de namen van de folders, maak ze aan
         #    en kopiëer files naar die folders
         if [ "$typerun" == "SREF" ] && [ "$make_forc" == "y" ]
         then
            dir_run=$dir_set'run/'
         else
            dir_sim='ini'$iniyear$str_inimth'_dur'$str_dur'_E'$str_mem
            dir_out=$dir_set$dir_sim'/'
            echo 'The destination directory is '$dir_out
            mkdir -p $dir_out
            dir_run=$dir_out'run/'
         fi

         mkdir -p $dir_run
         cp $sourcePath/run_empty/jobScript $dir_run
         
         if [ "$typerun" == "SREF" ]
         then
             dir_forc=$dir_set'forcing_'$typerun'/'
             mkdir -p $dir_forc
         fi
        
         if [ "$typerun" == "SREF" ] && [ "$run_hydmodel" == "y" ]
         then
            dir_initstates=$dir_set'initstates/'
            mkdir -p $dir_initstates
            if [ "$read_init_state" == "y" ]
            then
               file_initstat=$dir_initstates'initstat.'$iniyear$str_inimth'01_00000.nc'
            else
               file_initstat=''
            fi
         fi

         if [ "$run_hydmodel" == "y" ] 
         then
            # Bepaal de namen van de subfolders
            dir_log=$dir_out'log/'
            dir_output=$dir_out'output/'
            rm -rf $dir_log
            rm -rf $dir_output
            mkdir $dir_log
            mkdir $dir_output
            gpfhere=$dir_run'globparfile_'$dir_sim'.txt'
            cp $sourcePath/run_empty/globparfile_CLIMAX_template.txt $gpfhere
         fi
         
         if [ "$make_forc" == "y" ]
         then
            if [ "$typerun" == "SREF" -a "$forcing" == "WFDEI" ]
            then
               cp $sourcePath/run_empty/make_WFDEIforc_refrun $dir_run
            fi
         fi
         
         sed -i "s|dir_initstates_ph|$dir_initstates|g" $dir_run/*
         sed -i "s|dir_paramfiles_ph|$dir_paramfiles|g" $dir_run/*
         sed -i "s|file_initstat_ph|$file_initstat|g" $dir_run/*
         sed -i "s|run_hydmodel_ph|$run_hydmodel|g" $dir_run/*
         sed -i "s|dir_output_ph|$dir_output|g" $dir_run/*
         sed -i "s|VICdt_hrs_ph|$VICdt_hrs|g" $dir_run/*
         sed -i "s|make_forc_ph|$make_forc|g" $dir_run/*
         sed -i "s|dir_forc_ph|$dir_forc|g" $dir_run/*
         sed -i "s|saveyear_ph|$saveyear|g" $dir_run/*
         sed -i "s|prectype_ph|$prectype|g" $dir_run/*
         sed -i "s|finiyear_ph|$finiyear|g" $dir_run/*
         sed -i "s|liniyear_ph|$liniyear|g" $dir_run/*
         sed -i "s|ltaryear_ph|$ltaryear|g" $dir_run/*
         sed -i "s|dir_log_ph|$dir_log|g" $dir_run/*
         sed -i "s|dir_out_ph|$dir_out|g" $dir_run/*
         sed -i "s|gpfhere_ph|$gpfhere|g" $dir_run/*
         sed -i "s|dir_run_ph|$dir_run|g" $dir_run/*
         sed -i "s|dir_sim_ph|$dir_sim|g" $dir_run/*
         sed -i "s|forcing_ph|$forcing|g" $dir_run/*
         sed -i "s|namerun_ph|$namerun|g" $dir_run/*
         sed -i "s|typerun_ph|$typerun|g" $dir_run/*
         sed -i "s|saveday_ph|$saveday|g" $dir_run/*
         sed -i "s|savemth_ph|$savemth|g" $dir_run/*
         sed -i "s|ltarday_ph|$ltarday|g" $dir_run/*
         sed -i "s|ltarmth_ph|$ltarmth|g" $dir_run/*
         sed -i "s|dir_set_ph|$dir_set|g" $dir_run/*
         sed -i "s|iniyear_ph|$iniyear|g" $dir_run/*
         sed -i "s|n_tasks_ph|$n_tasks|g" $dir_run/*
         sed -i "s|domain_ph|$domain|g" $dir_run/*
         sed -i "s|northb_ph|$northb|g" $dir_run/*
         sed -i "s|southb_ph|$southb|g" $dir_run/*
         sed -i "s|iniday_ph|$iniday|g" $dir_run/*
         sed -i "s|inimth_ph|$inimth|g" $dir_run/*
         sed -i "s|ris_hd_ph|$ris_hd|g" $dir_run/*
         sed -i "s|ss_hd_ph|$ss_hd|g" $dir_run/*
         sed -i "s|westb_ph|$westb|g" $dir_run/*
         sed -i "s|eastb_ph|$eastb|g" $dir_run/*
         sed -i "s|lday_ph|$lday|g" $dir_run/*
         sed -i "s|lmth_ph|$lmth|g" $dir_run/*
         sed -i "s|fmth_ph|$fmth|g" $dir_run/*

         cd $dir_run
         chmod u+x jobScript
         
         if [ "$typerun" == "SREF" ]
         then
            if [ "$make_forc" == "y" ]
            then
               if [ "$batch" == "y" ]
               then
                  sbatch ./jobScript
               else
                  ./jobScript
               fi
            else            
               submitted="n"
               while [ "$submitted" == "n" ]
               do 
                  if [ "$(squeue -u greue002 | wc -l)" -eq "1" ]
                  then 
                     sbatch ./jobScript
                     submitted='y'
                  fi
                  sleep 5 
                  echo "waiting"
               done
            fi
         fi
         
      done      # Einde van de loop over de initiële maanden
   done         # Einde van de loop over de initiële jaren
done            # Einde van de loop over de leden van het ensemble


