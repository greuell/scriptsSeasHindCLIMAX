#!/bin/bash

# All modules used will be listed in the output
module list

dir_forc=dir_forc_ph
dir_out=dir_out_ph
dir_set=dir_set_ph
fyear=finiyear_ph
lyear=liniyear_ph 
domain=domain_ph
VICdt_hrs=VICdt_hrs_ph
westb=westb_ph
eastb=eastb_ph
southb=southb_ph
northb=northb_ph
prectype=prectype_ph

facprec=$(($VICdt_hrs*3600))

case $VICdt_hrs in
   3) freqin='3hourly';;
   6) freqin='6hourly';;
  24) freqin='daily';;
esac

nmth=12
dir_in='/lustre/backup/WUR/ESG/data/CLIMATE_DATA/WATCH/WATCH_WFDEI_GRIDDED/'$freqin'/'
dir_temp=$dir_set'temporary/' 
mkdir -p $dir_temp
cd $dir_temp
      
declare -a varname=( 'Rainf' 'LWdown' 'PSurf' 'Snowf' \
                     'SWdown' 'Tair' 'Wind' 'Qair' )
nvar=${#varname[*]} 

for (( year=$fyear; year <= $lyear; year++ ))
do

   ## files_var_merge=''
   
   for (( ivar=0; ivar < $nvar; ivar++ ))
   do

      varhere=${varname[$ivar]}

      precfileadd=''
      if [ $varhere == 'Rainf' -o $varhere == 'Snowf' ]
      then
         precfileadd='_'$prectype
      fi
      
      files_time_merge=''
               
      for (( mth=1; mth <= $nmth; mth++ ))
      do
      
         mthstr=$mth
         if [ "$mth" -lt "10" ]
         then
            mthstr='0'$mth
         fi  
      
         echo 'year='$year '  month='$mthstr '  variable='$varhere

         dir_var=$dir_in$varhere'_'$freqin'_WFDEI'$precfileadd'/'
         fileinvar=$varhere'_'$freqin'_WFDEI_'$year$mthstr'.nc'
         ## dirvar=$dirin$varhere'_WFDEI'$precfileadd'/'
         ## fileinvar=$varhere'_WFDEI'$precfileadd'_'$year$mthstr'.nc'
         filetot=$dir_var$fileinvar
         
         ## Copy file to directory for temporary files
         cp $filetot .
         
         ## cdo houdt niet van het geleverde WFDEI rooster
         ## Dat moet opnieuw bepaald worden         
         ## filevargrid=$varhere'_'$year$mthstr'_grid.nc'
         ## global_grd_file=$dirout'global_WFDEI_grid'
         ## cdo setgrid,$global_grd_file $fileinvar $filevargrid
 
         ## Select desired lat-lon box
         filevarreg=$varhere'_'$year$mthstr'_reg.nc'
         ## cdo sellonlatbox,$westb,$eastb,$southb,$northb $filevargrid $filevarreg
         cdo sellonlatbox,$westb,$eastb,$southb,$northb $fileinvar $filevarreg
         
         files_time_merge=$files_time_merge$filevarreg' '

      done   ## End of loop over months

      ## Merge the files of the 12 months into one file per year
      filevaryearraw=$varhere'_'$year'_raw.nc'
      cdo -O mergetime $files_time_merge $filevaryearraw
      
      ## For some reason the file contains a variable timestp,
      ##    which must be deleted
      # filevarnodt=$varhere'_'$year'_nodt.nc'
      # cdo delname,timestp $filevaryearraw $filevarnodt
      
      filevarunit=$varhere'_'$year'_unit.nc'
      filevaryear=$dir_forc$varhere'_'$year'.nc'
      filevarmeanyear=$dir_forc$varhere'_mean_'$year'.nc'
      ## Units must be changed
      case $varhere in
         'Rainf') cdo mulc,$facprec $filevaryearraw $filevarunit;
                  cdo setunit,'mm' $filevarunit $filevaryear;
                  ncatted -O -a long_name,Rainf,o,c,'Rainfall over the previous three hours' $filevaryear
                  fileRainf=$filevaryear;;
         'Snowf') cdo mulc,$facprec $filevaryearraw $filevarunit;
                  cdo setunit,'mm' $filevarunit $filevaryear;
                  ncatted -O -a long_name,Snowf,o,c,'Snowfall over the previous three hours' $filevaryear
                  fileSnowf=$filevaryear;;
         'Tair')  cdo subc,273.15 $filevaryearraw $filevarunit;
                  cdo setunit,'C' $filevarunit $filevaryear;;
         'PSurf') cdo divc,1000 $filevaryearraw $filevarunit;
                  cdo setunit,'kPa' $filevarunit $filevaryear;
                  filePsurf=$filevaryear;;
         'Qair')  cp $filevaryearraw $filevaryear;
                  fileQair=$filevaryear;;
         *)       cp $filevaryearraw $filevaryear;;
      esac
      
      cdo timmean $filevaryear $filevarmeanyear
      
      ## files_var_merge=$files_var_merge$filevaryear' '

   done      ## End of loop over variables

   # Bereken waterdampdruk uit de specifieke vochtigheid en druk    
   varhere='Evappr'
   filevaryear=$dir_forc$varhere'_'$year'.nc'
   cdo mulc,0.378 $fileQair 'tdata1.nc' 
   cdo addc,0.622 'tdata1.nc' 'tdata2.nc'
   cdo mul $fileQair $filePsurf 'tdata3.nc'
   cdo div 'tdata3.nc' 'tdata2.nc' $filevaryear 
   ncrename -v Qair,$varhere $filevaryear
   ncatted -O -a long_name,$varhere,o,c,'Two meter water vapour pressure at time stamp' $filevaryear
   ncatted -O -a title,$varhere,o,c,$varhere $filevaryear
   ncatted -O -a units,$varhere,o,c,'kPa' $filevaryear
   filevarmeanyear=$dir_forc$varhere'_mean_'$year'.nc'
   cdo timmean $filevaryear $filevarmeanyear
   
   # Neerslag is som van regen en sneeuw
   varhere='Precip'
   filevaryear=$dir_forc$varhere'_'$year'.nc'
   cdo add $fileRainf $fileSnowf $filevaryear
   ncrename -v Rainf,$varhere $filevaryear
   ncatted -O -a long_name,$varhere,o,c,'Precipitation over the previous three hours' $filevaryear
   ncatted -O -a title,$varhere,o,c,$varhere $filevaryear
   filevarmeanyear=$dir_forc$varhere'_mean_'$year'.nc'
   cdo timmean $filevaryear $filevarmeanyear
       
   ## fileyear='All_var_WFDEI_'$year'.nc'
   ## cdo -O merge $files_var_merge $fileyear 
   
done         ## End of loops over years 

rm -rf $dir_temp
         
