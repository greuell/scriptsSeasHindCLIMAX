import cdsapi

c = cdsapi.Client()

c.retrieve(
    'seasonal-original-single-levels',
    {
        'originating_centre':'forcing_ph',
        'format':'grib',
        'variable': varform_ph,   
		'area': [ 'southb_downl_ph', 'westb_downl_ph', 'northb_downl_ph', 'eastb_downl_ph'], # swlat swlon nelat nelon
		'year':'iniyear_ph',
        'month':'inimthstr_ph',
        'day':'01',
        'leadtime_hour':[ 
            '6','12','18',
            '24','30','36',
            '42','48','54',
            '60','66','72',
            '78','84','90','96'
            ]
    },
    'dir_acqforcoutput_phtemporary/download.grib')
