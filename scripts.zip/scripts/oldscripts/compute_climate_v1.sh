#!/bin/bash

# Maak files met het klimaat

datatype="obs"       # can be either 'obs' or 'hdc' (hindcasts)

if [ "$datatype" == "obs" ]
then
   declare -a varname=( 'Evappr' 'LWdown' 'Precip' 'PSurf' 'Qair' \
                        'Tair' 'SWdown' 'Tmax' 'Tmin' 'Wind' )
   forcing='WFDEI'
   forc_vers='aug2018'
   dur=1
   lmem=0
elif [ "$datatype" == "hdc" ]
then
   declare -a varname=( 'Precip' )
   forcing='ecmwf'
   forc_vers='5'
   dur=7
   lmem=25
fi
nvar=${#varname[*]} 

resolution='halfdegree'
domain='SA'

nmth=12

biascorr='noBC'
maxlead=$((dur-1))
lus_backup='/lustre/backup/WUR/ESG/greue002/'
dir_domain=$lus_backup'CLIMAX/'$domain'/'
dirin1=$dir_domain'forcing/'$forcing'_'$forc_vers'/'$resolution'_noBC_'

if [ "$datatype" == "obs" ]
then
   dirin2='daily/data/'
elif [ "$datatype" == "hdc" ]
then
   dirin2='monthly_leadtime/'
fi
dirin=$dirin1$dirin2
dirout=$dirin1'climate/data/'
dirouttemp=$dirout'temp/'

mkdir -p $dirout
mkdir -p $dirouttemp

for (( ivar=0; ivar < $nvar; ivar++ ))
do

   varhere=${varname[$ivar]}
   echo $varhere
   
   for (( lead=0; lead <= $maxlead; lead++ ))
   do

      if [ "$datatype" == "obs" ]   
      then

         filein=$dirin$varhere'.nc'

         fileymonavg=$dirout$varhere'_ymonavg.nc'
         fileymonstd=$dirout$varhere'_ymonstd.nc'
         fileymoncfv=$dirout$varhere'_ymoncfv.nc'

      elif [ "$datatype" == "hdc" ]
      then
      
         filemem1=$dirin$varhere'mean_monthly_'$forcing'_'$forc_vers'_'
         filemem2=$forcing'_'$forc_vers'_'$domain'_'$biascorr'_E'

         files_all_mem=''
      
         for (( mem=1; mem <= $lmem; mem++ ))
         do
      
            if [ "$mem" -lt "10" ]
            then
               str_mem='0'$mem
            else
               str_mem=$mem
            fi

            filemem3=$str_mem'_lead'$lead'.nc4'
            filemem=$filemem1$filemem2$filemem3
            
            echo $lead   $mem   
            files_all_mem=$files_all_mem$filemem' '
            
         done

         filein=$dirin$varhere'_median_of_mean_monthly_lead'$lead'.nc4' 
         
         cdo -O -s enspctl,50 $files_all_mem $filein
         
         fileymonavg=$dirout$varhere'_lead'$lead'_ymonavg.nc'
         fileymonstd=$dirout$varhere'_lead'$lead'_ymonstd.nc'
         fileymoncfv=$dirout$varhere'_lead'$lead'_ymoncfv.nc'

      fi

      cdo -s ymonavg $filein $fileymonavg
      # Het volgende statement levert een foutief resultaat op
      # cdo ymonstd $filein $fileymonstd

      # Derhalve reken ik via een omweg
      filemonavg=$dirouttemp'monavg.nc'
      cdo -s monavg $filein $filemonavg
 
      files_all_std=''
           
      for (( mth=1; mth <= $nmth; mth++ ))
      do
         filemth=$dirouttemp'selmonth'$mth'.nc'
         cdo -s selmonth,$mth $filemonavg $filemth
         filemthstd=$dirouttemp'stdmonth'$mth'.nc'
         cdo -s timstd $filemth $filemthstd
         files_all_std=$files_all_std$filemthstd' '
      done
      
      cdo -O -s mergetime $files_all_std $fileymonstd 
      cdo -s div $fileymonstd $fileymonavg $fileymoncfv
      
      rm $dirouttemp/*
      
   done    # End of the loop over the lead times
   
done    # End of the loop over the variables
