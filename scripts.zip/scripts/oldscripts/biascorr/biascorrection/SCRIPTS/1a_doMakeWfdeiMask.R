rm(list=ls())
library(fields) # e.g: using the fields library
library(abind)
library(ncdf4)
library(loadeR.ECOMS)
source(file = "./functions/infoGeneral.R")
source(file = "./functions/functionsGeneral.R")
source(file = "./functions/functionR2Netcdf.R")
library(downscaleR) # Used for interpolation and bias correction

loginUDG(username = "wietsefranssen", password = "ECOMS")

submitscript <- FALSE

locName<-"GHA"
locName<-"EU"
locName<-"SA"
resolution<-"0.50"
outPath<-sprintf("../DATA/maskkk")

variableName<-c( "tas")

dir.create(outPath, recursive = TRUE, showWarnings = FALSE)

if ('ecomsName' %in% names(variableInfo[[variableName]])) {
  variableNameECOMS<-variableInfo[[variableName]]$ecomsName
} else {
  variableNameECOMS<-variableName
}

oFile <- sprintf("%s/mask_wfdei_%s_%s.nc4",
                   outPath, locName,resolution)
print(oFile)

if (resolution == "0.50") {
  lonLim = c(locationInfo$res0.50[[locName]]$lonmin, locationInfo$res0.50[[locName]]$lonmax)
  latLim = c(locationInfo$res0.50[[locName]]$latmin, locationInfo$res0.50[[locName]]$latmax) 
} else {
  #        lonLim = c(locationInfo$res0.75[[locName]]$lonmin-1.5, locationInfo$res0.75[[locName]]$lonmax+1.5)
  #        latLim = c(locationInfo$res0.75[[locName]]$latmin-1.5, locationInfo$res0.75[[locName]]$latmax+1.5) 
  lonLim = c(locationInfo$res0.75[[locName]]$lonmin, locationInfo$res0.75[[locName]]$lonmax)
  latLim = c(locationInfo$res0.75[[locName]]$latmin, locationInfo$res0.75[[locName]]$latmax) 
}

RData<-loadECOMS(dataset = "WFDEI", 
                 var = variableNameECOMS,
                 lonLim = lonLim,
                 latLim = latLim, 
                 season = 1, 
                 years = 1981, 
                 time = "DD")

RData$xyCoords$x[]<-round(RData$xyCoords$x[],2)
RData$xyCoords$y[]<-round(RData$xyCoords$y[],2)

if (resolution == "0.75") {
  newGrid<-getGrid(RData)
  newGrid$x <- c(locationInfo$res0.75[[locName]]$lonmin, locationInfo$res0.75[[locName]]$lonmax)
  newGrid$y <- c(locationInfo$res0.75[[locName]]$latmin, locationInfo$res0.75[[locName]]$latmax)
  attr(newGrid,"resX")<-0.75
  attr(newGrid,"resY")<-0.75
  print("Regridding")
  RData <- interpGrid(RData, new.grid = newGrid, method = "bilinear");
}

# Check units
RData$Variable$varName<-variableName
attr(RData$Variable,"standard_name")<-variableInfo[[variableName]]$standardName
attr(RData$Variable,"long_name")<-variableInfo[[variableName]]$longName
attr(RData$Variable,"units")<-variableInfo[[variableName]]$unitsEcoms

## FIX
RData$Dates$start<-RData$Dates$start[1]
RData$Dates$end<-RData$Dates$end[1]
RData$Data<-RData$Data[1,,]
RData$Data[!is.na(RData$Data)]<-1
attributes(RData$Variable)<-NULL
attr(RData$Variable, "long_name") <- "land-sea mask"
attr(RData$Variable, "standard_name") <- "mask"
attr(RData$Variable, "units") <- "-"
attr(RData$Variable, "title") <- "land-sea mask"
RData$Variable$varName<-"mask"

## add some extra attributes
attr(RData,"contact") <- "Wietse Franssen (wietse.franssen@wur.nl)"

R2Netcdf(oFile, RData)


