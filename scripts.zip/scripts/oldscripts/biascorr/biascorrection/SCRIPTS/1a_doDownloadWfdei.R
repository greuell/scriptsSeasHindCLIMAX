rm(list=ls())
library(fields) # e.g: using the fields library
library(abind)
library(ncdf4)
library(loadeR.ECOMS)
source(file = "./functions/infoGeneral.R")
source(file = "./functions/functionsGeneral.R")
source(file = "./functions/functionR2Netcdf.R")

loginUDG(username = "wietsefranssen", password = "ECOMS")

submitscript <- FALSE

if (submitscript) {
  targetMonths <- c(1:12)
  targetYears  <- c(1981:2011)
  locName    <- 'X'
  resolution<-"0.50"
  outPath<-sprintf("../DATA/wfdei_rev5.0/%sdeg/%s", resolution, locName)
  
} else {
  targetMonths <-c(1:12)
  targetYears  <-c(1981:2010)
  # targetYears  <-c(1981:1982)
  locName<-"GHA"
  locName<-"EU"
  locName<-"SA"
  resolution<-"0.50"
  outPath<-sprintf("../DATA/wfdei_rev5.0/%sdeg/%s", resolution, locName)
}

variables<-names(variableInfo)
variables<-c("tas", "tasmin", "tasmax", "pr", "sfcWind", "rsds", "rlds", "huss")
#variables<-c( "pr")

dir.create(outPath, recursive = TRUE, showWarnings = FALSE)

for (variableName in variables) {
  for (targetMonth in targetMonths) {
    if ('ecomsName' %in% names(variableInfo[[variableName]])) {
      variableNameECOMS<-variableInfo[[variableName]]$ecomsName
    } else {
      variableNameECOMS<-variableName
    }

    print(sprintf("targetMonth: %s, years: %d-%d",month.name[targetMonth], targetYears[1], targetYears[length(targetYears)]))
    
    oPrefix <- sprintf("%s/%s_wfdei_%s_%4d-%4d_%02d",
                       outPath, variableName, locName, 
                       targetYears[1], targetYears[length(targetYears)],
                       targetMonth)
    print(oPrefix)
    
    if (resolution == "0.50") {
      lonLim = c(locationInfo$res0.50[[locName]]$lonmin, locationInfo$res0.50[[locName]]$lonmax)
      latLim = c(locationInfo$res0.50[[locName]]$latmin, locationInfo$res0.50[[locName]]$latmax) 
    } else {
      #        lonLim = c(locationInfo$res0.75[[locName]]$lonmin-1.5, locationInfo$res0.75[[locName]]$lonmax+1.5)
      #        latLim = c(locationInfo$res0.75[[locName]]$latmin-1.5, locationInfo$res0.75[[locName]]$latmax+1.5) 
      lonLim = c(locationInfo$res0.75[[locName]]$lonmin, locationInfo$res0.75[[locName]]$lonmax)
      latLim = c(locationInfo$res0.75[[locName]]$latmin, locationInfo$res0.75[[locName]]$latmax) 
    }
    
    RData<-loadECOMS(dataset = "WFDEI", 
                     var = variableNameECOMS,
                     lonLim = lonLim,
                     latLim = latLim, 
                     season = targetMonth, 
                     years = targetYears, 
                     time = "DD")

    if (variableName == "pr") {
      print("Because on a error on the ecoms server. Pr only contains rainfall.\n
             Because of this we also download snow and sum it up to total precip.\n
             Please check if this error still exists!!!")
      RData_snow<-loadECOMS(dataset = "WFDEI", 
                     var = "prsn",
                     lonLim = lonLim,
                     latLim = latLim, 
                     season = targetMonth, 
                     years = targetYears, 
                     time = "DD")
      RData$Data[]<-RData$Data[]+RData_snow$Data[]
    }
                     
                     
    RData$xyCoords$x[]<-round(RData$xyCoords$x[],2)
    RData$xyCoords$y[]<-round(RData$xyCoords$y[],2)

    if (resolution == "0.75") {
      newGrid<-getGrid(RData)
      newGrid$x <- c(locationInfo$res0.75[[locName]]$lonmin, locationInfo$res0.75[[locName]]$lonmax)
      newGrid$y <- c(locationInfo$res0.75[[locName]]$latmin, locationInfo$res0.75[[locName]]$latmax)
      attr(newGrid,"resX")<-0.75
      attr(newGrid,"resY")<-0.75
      print("Regridding")
      RData <- interpGridData(RData, new.grid = newGrid, method = "bilinear");
    }
    
    # Check units
    RData$Variable$varName<-variableName
    attr(RData$Variable,"standard_name")<-variableInfo[[variableName]]$standardName
    attr(RData$Variable,"long_name")<-variableInfo[[variableName]]$longName
    attr(RData$Variable,"units")<-variableInfo[[variableName]]$unitsEcoms
    
    ## add some extra attributes
    attr(RData,"contact") <- "Wietse Franssen (wietse.franssen@wur.nl)"
    
    save(file = sprintf("%s.RData",oPrefix), RData)
    R2Netcdf(sprintf("%s.nc4",oPrefix), RData)
  }
}
