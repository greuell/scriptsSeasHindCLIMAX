rm(list=ls())
library(ncdf4)
source(file = "./functions/functionsGeneral.R")
source(file = "./functions/functionR2Netcdf.R")
source(file = "./functions/functionNetcdf2R.R")
source(file = "./functions/functionConvert.R")
source(file = "./functions/infoGeneral.R")

submitscript <- FALSE

if (submitscript) {
  members      <- c(1:15)
  initYears    <- c(1981:2010)
  initMonths   <- c(X:X)
  locName      <- 'X'
  resolution   <- 'X'
  bcInfo       <- 'X'
  inPath       <- sprintf("../DATA/System4_seasonal_15_rev5.0/%sdeg/%s_%s", resolution, locName, bcInfo)
  outPath      <- sprintf("../DATA/System4_seasonal_15_rev5.0/%sdeg/%s_%s_final", resolution, locName, bcInfo)
} else {
  members      <- c(1:15)
  initYears    <- c(1981:2010)
  initMonths   <- c(1:12)
  locName      <- "GHA"
  #locName      <- "EU"
  resolution   <- "0.75"
  bcInfo       <- "BC"
  inPath       <- sprintf("../DATA/System4_seasonal_15_rev5.0/%sdeg/%s_%s", resolution, locName, bcInfo)
  outPath      <- sprintf("../DATA/System4_seasonal_15_rev5.0/%sdeg/%s_%s_final", resolution, locName, bcInfo)
}

variables<-names(variableInfo)

FillValue <- 1e20

dir.create(outPath, recursive = TRUE, showWarnings = FALSE)
for (iMember in members) {
  for (initYear in initYears) {
    for (initMonth in initMonths) {
      firstVar<-TRUE
      for (variableName in variables) {
        ## OPEN NCin-Data
        nameFileNCin <- sprintf("%s/%s/%s_forcing_seas15_%s_%s_E%02d_INIT%4d_%02d.nc4", 
                                inPath,
                                variableName,
                                variableName,
                                locName,
                                bcInfo,
                                iMember,
                                initYear,
                                initMonth)
        
        print(paste0("Reading: ", nameFileNCin))
        ncid_in=nc_open(nameFileNCin)
        NCdata <- ncvar_get( ncid_in, variableName ) 
        NCtime <- ncvar_get( ncid_in, "time" ) 
        NClon <- ncvar_get( ncid_in, "lon" ) 
        NClat <- ncvar_get( ncid_in, "lat" ) 
        NCtimeAtt<-ncatt_get( ncid_in, "time", "units" )$value
        nc_close(ncid_in)
        
        NCdata[is.na(NCdata)] <- FillValue
        
        ## CREATE NETCDF
        if (firstVar == TRUE) {
          dimT <- ncdim_def("time", NCtimeAtt, NCtime, unlim = FALSE)
          dimY <- ncdim_def("lat", "degrees_north",round(NClat,2))
          dimX <- ncdim_def("lon", "degrees_east", round(NClon,2))
          
          
          ## SAVE AS NC-DATA
          nameFileNCout <- sprintf("%s/forcing_seas15_%s_%s_E%02d_INIT%4d_%02d.nc4", 
                                   outPath,
                                   locName,
                                   bcInfo,
                                   iMember,
                                   initYear,
                                   initMonth)
          data <- ncvar_def( variableName, variableInfo[[variableName]]$units, list(dimX,dimY,dimT), FillValue, prec="float", compression=4)
          print(paste0("Creating: ", nameFileNCout, " for: ", variableName))
          ncid_out <- nc_create( nameFileNCout,data)
          
          ## ADD ATTRIBUTES
          ncatt_put( ncid_out, 0, "source1", "distributed by ECOMS User Data Gateway (ECOMS-UDG), partially funded by the European Union FP under Grant Agreement no 308291 (EUPORIAS), http://meteo.unican.es/ecoms-udg")
          ncatt_put( ncid_out, 0, "source2", "IPR remains with European Centre For Medium-Range Weather Forecasts (ECMWF)")
          ncatt_put( ncid_out, 0, "source3", "ECMWF System4 hind cast, seasonal-15: 12 Runtimes per year (the 1st of J,F,etc) running for 7 months. Ensemble of 15 members for 1981-2010")
          ncatt_put( ncid_out, 0, "source4", "variables renamed, domain subset, masking, reorganised, interpolated to 0.5 degree by Wageningen University, Earth System Sciences")
          ncatt_put( ncid_out, 0, "source5", "variables naming convention: CMIP5 (http://cmip-pcmdi.llnl.gov/cmip5/docs/standard_output.pdf)")
          ncatt_put( ncid_out, 0, "domain", locationInfo[[paste0("res",resolution)]][[locName]]$longName)
          ncatt_put( ncid_out, 0, "member", iMember)
          ncatt_put( ncid_out, 0, "comment1", "Processed and regridded by W.Franssen")
          ncatt_put( ncid_out, 0, "institution", "Wageningen University and Research centre (WUR)")
          
          ncatt_put( ncid_out, "lon", "standard_name", "longitude")
          ncatt_put( ncid_out, "lon", "long_name",     "Longitude")
          ncatt_put( ncid_out, "lon", "axis",          "X")
          ncatt_put( ncid_out, "lat", "standard_name", "latitude")
          ncatt_put( ncid_out, "lat", "long_name",     "Latitude")
          ncatt_put( ncid_out, "lat", "axis",          "Y")
          ncatt_put( ncid_out, "time", "standard_name", "time")
          ncatt_put( ncid_out, "time", "calendar",     "standard")
          
        } else {
          print(paste0("Adding to: ", nameFileNCout, " for: ", variableName))
          #            data <- ncvar_def( variableName, variableInfo[[variableName]]$units, list(dimX,dimY,dimT), FillValue, prec="float", chunksizes = c(length(RData$xyCoords$x),length(RData$xyCoords$y),1) compression=4)
          data <- ncvar_def( variableName, variableInfo[[variableName]]$units, list(dimX,dimY,dimT), FillValue, prec="float")#, compression=4)
          ncid_out <- ncvar_add( ncid_out, data )
        }           
        ncvar_put( ncid_out, data, NCdata )
        
        ncatt_put( ncid_out, variableName, "standard_name", variableInfo[[variableName]]$standardName)
        ncatt_put( ncid_out, variableName, "long_name", variableInfo[[variableName]]$longName)
        #ncatt_put( ncid_out, variableName, "_FillValue", FillValue)
        
        firstVar<-FALSE
        rm(data, NCdata)
      }
      nc_close(ncid_out)
    } ## end initMonth
  } ## end initYear
}
