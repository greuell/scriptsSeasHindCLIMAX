rm(list=ls())
library(fields) # e.g: using the fields library
library(abind)
library(ncdf4)
library(loadeR.ECOMS)
source(file = "./functions/infoGeneral.R")
source(file = "./functions/functionsGeneral.R")
source(file = "./functions/functionR2Netcdf.R")

loginUDG(username = "wietsefranssen", password = "ECOMS")

submitscript <- FALSE

if (submitscript) {
  members    <- c(1:15)
#  members    <- c(1:2)
  targetMonths <- c(1:12)
#  targetMonths <- c(3)
  targetYears  <- c(1981:2011)
  leadMonths  <- c(X:X)
  locName    <- 'X'
  outPath<-sprintf("../DATA/System4_seasonal_15_rev5.0/0.75deg/%s_noBC_RAW", locName)
} else {
  members    <-c(1,2)
  targetMonths <-c(1:2)
  targetYears  <-c(2009:2011)
  targetYears  <-c(1981:1982)
  leadMonths  <-c(0:1)
  # locName<-"GHA"
  # locName<-"EU"
  locName<-"SA"
  outPath<-"./testData/rawDownload/"
}

variables<-names(variableInfo)
#variables<-c( "tas", "tasmin", "tasmax", "rsds", "rlds", "huss", "sfcWind", "pr")
#variables<-c( "pr")
#variables<-c( "tas")
#variables<-c( "tasmin")
#variables<-c( "tasmax")
#variables<-c( "rsds")
#variables<-c( "rlds")
#variables<-c( "huss")
#variables<-c( "sfcWind")

for (variableName in variables) {
  outPathVar <- sprintf("%s/%s", outPath, variableName)
  dir.create(outPathVar, recursive = TRUE, showWarnings = FALSE)
  for (targetMonth in targetMonths) {
    for (leadMonth in leadMonths) {
      ## get the available target years for the current targetMonth and leadMonth
      availableTargetYears <- getAvailableTargetYears(targetYears = targetYears, targetMonth = targetMonth, leadMonth = leadMonth)
      nYears <- length(availableTargetYears)
      
      if ('ecomsName' %in% names(variableInfo[[variableName]])) {
        variableNameECOMS<-variableInfo[[variableName]]$ecomsName
      } else {
        variableNameECOMS<-variableName
      }
      
      print(sprintf("targetMonth: %s, leadMonth: %s, years: %d-%d",month.name[targetMonth], leadMonth, availableTargetYears[1], availableTargetYears[nYears]))
      
      oPrefix <- sprintf("%s/%s_forcing_seas15_%s_noBC_E%02d-%02d_TAR%4d-%4d_%02d_LM%d",
                         outPathVar, variableName, locName, 
                         members[1], members[length(members)],
                         availableTargetYears[1], availableTargetYears[nYears],
                         targetMonth, leadMonth)
      print(oPrefix)
      
      nummm<-1
      while (!exists("RData")) {
        try({
          RData<-loadECOMS(dataset = "System4_seasonal_15", 
                         var = variableNameECOMS,
                         members = members, 
                         lonLim = c(locationInfo$res0.75[[locName]]$lonmin, locationInfo$res0.75[[locName]]$lonmax),
                         latLim = c(locationInfo$res0.75[[locName]]$latmin, locationInfo$res0.75[[locName]]$latmax), 
                         season = targetMonth, 
                         years = availableTargetYears, 
                         leadMonth = leadMonth,
                         time = "DD",
                         aggr.d = variableInfo[[variableName]]$aggr)
        }, silent=T)
        if (nummm > 1){Sys.sleep(120)}
        nummm<-nummm+1
      }
      
      RData$xyCoords$x[]<-round(RData$xyCoords$x[],2)
      RData$xyCoords$y[]<-round(RData$xyCoords$y[],2)
      
      # Check units
      RData$Variable$varName<-variableName
      attr(RData$Variable,"standard_name")<-variableInfo[[variableName]]$standardName
      attr(RData$Variable,"long_name")<-variableInfo[[variableName]]$longName
      attr(RData$Variable,"units")<-variableInfo[[variableName]]$unitsEcoms
      
      ## add some extra attributes
      attr(RData,"contact") <- "Wietse Franssen (wietse.franssen@wur.nl)"
      
      save(file = sprintf("%s.RData",oPrefix), RData)
      R2Netcdf(sprintf("%s.nc4",oPrefix), RData)
      rm(RData) 
    }
  }
}
