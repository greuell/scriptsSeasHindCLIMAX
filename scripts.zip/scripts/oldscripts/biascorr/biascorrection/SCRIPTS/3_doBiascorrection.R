rm(list=ls())
.libPaths("/home/WUR/frans004/R/justForOldDownscaleR/3.2")
#library(loadeR.ECOMS)
library(downscaleR)
#library(MASS)
library(abind)

source(file = "./functions/functionsGeneral.R")
source(file = "./functions/infoGeneral.R")
source(file = "./functions/functionMakeSelection.R")
source(file = "./functions/functionBiascorrectionWUR.R")
source(file = "./functions/functionR2Netcdf.R")
source(file = "./functions/functionNetcdf2R.R")
source(file = "./functions/functionConvert.R")

submitscript <- FALSE

if (submitscript) {
  members      <- c(1:15)
  initYears    <- c(1981:2010)
  targetMonths <- c(X:X)
  leadMonths   <- c(0:6)
  locName      <- 'X'
  resolution   <- 'X'
  obsPath      <- sprintf("../DATA/wfdei_rev5.0/%sdeg/%s/", resolution, locName)
  inPath       <- sprintf("../DATA/System4_seasonal_15_rev5.0/%sdeg/%s_noBC_biasformat", resolution, locName)
#  outPath      <- sprintf("../DATA/System4_seasonal_15_rev5.0/%sdeg/%s_BC_biasformat_memberTrue", resolution, locName)
  outPath      <- sprintf("../DATA/System4_seasonal_15_rev5.0/%sdeg/%s_BC_biasformat", resolution, locName)
} else {
  members      <- c(1:15)
  initYears    <- c(1981:2010)
  targetMonths <- 1
  leadMonths   <- c(0:6)
  locName      <- "GHA"
  # locName      <- "EU"
  resolution   <- "0.75"
  obsPath      <- sprintf("../DATA/wfdei_rev3.0/%sdeg/%s/", resolution, locName)
  inPath       <- sprintf("../DATA/System4_seasonal_15_rev4.0/%sdeg/%s_noBC_biasformat", resolution, locName)
  outPath      <- sprintf("../DATA/System4_seasonal_15_rev4.0/%sdeg/%s_BC_biasformat", resolution, locName)
}
#source("./biasCorrection.R")
variables <- names(variableInfo)
#variables <- c("pr")

print("start")
for (variableName in variables) {
  dir.create(sprintf("%s/%s", outPath, variableName), recursive = TRUE, showWarnings = FALSE)
  for (targetMonth in targetMonths) {
    for (leadMonth in leadMonths) {
      targetSYear <- getInitTargetInfo( initYear = initYears[1], targetMonth = targetMonth, leadMonth = leadMonth )$targetYear
      targetEYear <- getInitTargetInfo( initYear = initYears[length(initYears)], targetMonth = targetMonth, leadMonth = leadMonth )$targetYear
      
      iPrefix <- sprintf("%s/%s/%s_forcing_seas15_%s_noBC_E%02d-%02d_TAR%4d-%4d_%02d_LM%d",
                       inPath, variableName, variableName, locName, 
                       members[1], members[length(members)],
                       targetSYear, targetEYear,
                       targetMonth, leadMonth)

      #print(sprintf("Open: %s", iPrefix))
      RData_noBC <- Netcdf2R(paste0(iPrefix, ".nc4"), variableName)
      
      if (variableName == "pr") {
        obsFile <- sprintf("%s/%s_wfdei_GPCC_%s_%4d-%4d_%02d.nc4",
                          obsPath, variableName, locName, 
                          initYears[1], initYears[length(initYears)],
                          targetMonth)
#        RData_obs <- Netcdf2R(obsFile, variableName)
#        RData_obs <- convert(RData_obs, toUnit = "mm day-1")
      } else {
        obsFile <- sprintf("%s/%s_wfdei_%s_%4d-%4d_%02d.nc4",
                          obsPath, variableName, locName, 
                          initYears[1], initYears[length(initYears)],
                          targetMonth)
#        RData_obs <- Netcdf2R(obsFile, variableName)
#        RData_obs <- convert(RData_obs, toUnit = variableInfo[[variableName]]$units)
      }
      RData_obs <- Netcdf2R(obsFile, variableName)
      RData_obs <- convert(RData_obs, toUnit = variableInfo[[variableName]]$units)
      
      ## Make uniform and match the selections
      dates1<-as.character(as.POSIXct(RData_obs$Dates$start, tz = "GMT"))
      dates2<-as.character(as.POSIXct(RData_noBC$Dates$start, tz = "GMT"))
      overlapping_dates<-as.Date(intersect(dates1, dates2))
      rm(dates2,dates1)

      RData_obs <- subsetRData(RData_obs, dates = overlapping_dates)
      RData_noBC_pred <- subsetRData(RData_noBC, dates = overlapping_dates)
      
      if (variableName == "pr") {
        ## Correction: PRECIP
        print(sprintf("Bias correction..."))
#        print(sprintf("Convert precip first to [mm day-1]..."))
#        RData_noBC <- convert(RData_noBC, toUnit = "mm day-1")
        for (i in c(1:dim(RData_obs$Data)[1])) {
          RData_obs$Data[i,,][is.na(RData_noBC$Data[1,1,,])]<-NA
        }
        
        RData <- biasCorrect(RData_obs, RData_noBC, nbin = 100, epsilon = 0.00001)
#        RData <- convert(RData, toUnit = variableInfo[[variableName]]$units)
      } else {
        ## Correction: other variables
        print(sprintf("Bias correction..."))
        RData <- biasCorrection (RData_obs, RData_noBC_pred, RData_noBC, method = "qqmap", multi.member = FALSE) # bias
#        RData <- biasCorrection (RData_obs, RData_noBC_pred, RData_noBC, method = "eqm", join.members = FALSE) # bias
#        RData <- biasCorrection (RData_obs, RData_noBC_pred, RData_noBC, method = "eqm", join.members = TRUE) # bias
      }

      ## Write output
      oPrefix <- sprintf("%s/%s/%s_forcing_seas15_%s_BC_E%02d-%02d_TAR%4d-%4d_%02d_LM%d",
                       outPath, variableName, variableName, locName, 
                       members[1], members[length(members)],
                       targetSYear, targetEYear,
                       targetMonth, leadMonth)
      
      print(sprintf("Saving: %s", oPrefix))
      #save(file = paste0(oPrefix, ".RData"), RData)
      R2Netcdf(paste0(oPrefix, ".nc4"), RData)
    }
  }
}
