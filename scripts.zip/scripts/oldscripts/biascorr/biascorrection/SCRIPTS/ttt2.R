## CREATE NETCDF
FillValue <- 1e20

## Check dimensions
dimensions<-attributes(RData$Data)$dimensions

## Check if 'member', or 4th dimension exist
nDims <- length(dim(RData$Data))

## Define dimensions
dimX <- ncdim_def("lon", "degrees_east", RData$xyCoords$x)
dimY <- ncdim_def("lat", "degrees_north",RData$xyCoords$y)
if (nDims > 3) {
  dimZ <- ncdim_def("member", "layer",1:dim(RData$Data)[which(dimensions == "member")])
}
timeString<-format(strptime(RData$Dates$start[1], format = "%Y-%m-%d", tz = "GMT"),format="%Y-%m-%d %T")
timeArray<-as.double(difftime(RData$Dates$start,RData$Dates$start[1], units = c("days"), tz = "GMT"))
dimT <- ncdim_def("time", paste0("days since ",timeString), timeArray, unlim = FALSE)

#   if ('units' %in% names(RData$Variable)) {
#     units<-RData$Variable$units
#   } else {
#     units<-""
#   }

if (nDims > 3) {
  data <- ncvar_def(name=RData$Variable$varName, units='', dim=list(dimX,dimY,dimZ,dimT), missval=FillValue, prec="float",chunksizes = c(length(RData$xyCoords$x),length(RData$xyCoords$y),1,1), compression=4)
} else {
  data <- ncvar_def(name=RData$Variable$varName, units='', dim=list(dimX,dimY,dimT), missval=FillValue, prec="float",chunksizes = c(length(RData$xyCoords$x),length(RData$xyCoords$y),1), compression=4)
}

## SAVE AS NC-DATA
print(paste0("Writing: ", outFile))

ncid <- nc_create(outFile, list(data))

if (nDims > 3) {
  ncvar_put(ncid, data, aperm(RData$Data, c(which(dimensions == "lon"),
                                            which(dimensions == "lat"),
                                            which(dimensions == "member"),
                                            which(dimensions == "time"))))
} else {
  ncvar_put(ncid, data, aperm(RData$Data, c(which(dimensions == "lon"),
                                            which(dimensions == "lat"),
                                            which(dimensions == "time"))))
}

ncatt_put( ncid, "lon", "standard_name", "longitude")
ncatt_put( ncid, "lon", "long_name",     "Longitude")
ncatt_put( ncid, "lon", "axis",          "X")
ncatt_put( ncid, "lat", "standard_name", "latitude")
ncatt_put( ncid, "lat", "long_name",     "Latitude")
ncatt_put( ncid, "lat", "axis",          "Y")
ncatt_put( ncid, "time", "standard_name", "time")
ncatt_put( ncid, "time", "calendar",     "standard")
ncatt_put( ncid, RData$Variable$varName, "standard_name", RData$Variable$varName)
if ('longName' %in% names(RData$Variable)) {
  ncatt_put( ncid, RData$Variable$varName, "long_name", RData$Variable$longName)
}

## Global Attributes
if ('InitializationDates' %in% names(RData)) {
  initDateNames<-paste(RData$InitializationDates, sep = ',', collapse = ',')
  ncatt_put( ncid, 0, "InitializationDates", initDateNames)
}

if ('Members' %in% names(RData)) {
  membernames<-paste(RData$Members, sep = ',', collapse = ',')
  ncatt_put( ncid, 0, "Members", membernames)
}

## Get all global attributes from RData and put them in the NetCDF file
attributeList<-attributes(RData)
attributeList["names"]<-NULL
for (iAttribute in 1:length(attributeList)) {
  ncatt_put( ncid, 0, names(attributeList)[iAttribute], as.character(attributeList[iAttribute[]]))
}
ncatt_put( ncid, 0, "NetcdfCreatationDate", as.character(Sys.Date()))

## Get all attributes of variable from RData and put them in the NetCDF file
attributeList<-attributes(RData$Variable)
attributeList["names"]<-NULL
if (length(attributeList) > 0 ) {
  for (iAttribute in 1:length(attributeList)) {
    ncatt_put( ncid, RData$Variable$varName, names(attributeList)[iAttribute], as.character(attributeList[iAttribute[]]))
  }
}

## Get all xyCoords attributes and put them in the NetCDF file
attributeList<-attributes(RData$xyCoords)
attributeList["names"]<-NULL
if (length(attributeList) > 0 ) {
  for (iAttribute in 1:length(attributeList)) {
    ncatt_put( ncid, 0, paste0("xyCoords_", names(attributeList)[iAttribute]), as.character(attributeList[iAttribute[]]))
  }
}

# length(attributeList)
## Close Netcdf file
nc_close(ncid)
}
