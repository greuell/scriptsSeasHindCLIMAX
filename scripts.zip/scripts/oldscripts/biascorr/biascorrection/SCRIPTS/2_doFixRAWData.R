rm(list=ls())
source(file = "./functions/functionsGeneral.R")
source(file = "./functions/functionR2Netcdf.R")
source(file = "./functions/functionNetcdf2R.R")
source(file = "./functions/functionConvert.R")
source(file = "./functions/infoGeneral.R")

submitscript <- FALSE

if (submitscript) {
  members    <- c(1:15)
  #members      <- c(1:2)
  targetMonths <- c(1:12)
  #  targetMonths <- c(3)
  targetYears  <- c(1981:2011)
  #leadMonths  <- c(3)
  leadMonths  <- c(X:X)
  locName    <- 'X'
  resolution   <- "0.50"
  inPath       <- sprintf("../DATA/System4_seasonal_15_rev5.0/0.75deg/%s_noBC_RAW", locName)
  outPath      <- sprintf("../DATA/System4_seasonal_15_rev5.0/%sdeg/%s_noBC_biasformat", resolution, locName)
} else {
  members    <-c(1,2)
  targetMonths <-c(3)
  targetYears  <-c(2009:2011)
  targetYears  <-c(1981:2011)
  leadMonths  <-c(3)
  locName<-"GHA"
  # locName<-"EU"
  # locName<-"SA"
  resolution   <- "0.50"
  inPath       <- sprintf("../DATA/System4_seasonal_15_rev5.0/0.75deg/%s_noBC_RAW", locName)
  outPath      <- sprintf("../DATA/System4_seasonal_15_rev5.0/%sdeg/%s_noBC_biasformat", resolution, locName)
}

mask<-Netcdf2R(inFile = sprintf("../DATA/mask/mask_wfdei_%s_%s.nc4", locName, resolution), "mask")

variables<-names(variableInfo)
#variables<-"pr"

print("start")
for (variableName in variables) {
  dir.create(sprintf("%s/%s", outPath, variableName), recursive = TRUE, showWarnings = FALSE)
  for (targetMonth in targetMonths) {
    for (leadMonth in leadMonths) {
      ## get the available target years for the current targetMonth and leadMonth
      availableTargetYears <- getAvailableTargetYears(targetYears = targetYears, targetMonth = targetMonth, leadMonth = leadMonth)
      nYears <- length(availableTargetYears)
      
      if ('ecomsName' %in% names(variableInfo[[variableName]])) {
        variableNameECOMS<-variableInfo[[variableName]]$ecomsName
      } else {
        variableNameECOMS<-variableName
      }
      
      inFile <- sprintf("%s/%s/%s_forcing_seas15_%s_noBC_E%02d-%02d_TAR%4d-%4d_%02d_LM%d.nc4",
                        inPath, variableName, variableName, locName, 
                        members[1], members[length(members)],
                        availableTargetYears[1], availableTargetYears[nYears],
                        targetMonth, leadMonth)
      
      outFile <- sprintf("%s/%s/%s_forcing_seas15_%s_noBC_E%02d-%02d_TAR%4d-%4d_%02d_LM%d.nc4",
                         outPath, variableName, variableName, locName, 
                         members[1], members[length(members)],
                         availableTargetYears[1], availableTargetYears[nYears],
                         targetMonth, leadMonth)
      
      ## Load file...
      RData <- Netcdf2R(inFile, variableName)
      
      # Check units
      RData$Variable$varName<-variableName
      attr(RData$Variable,"standard_name")<-variableInfo[[variableName]]$standardName
      attr(RData$Variable,"long_name")<-variableInfo[[variableName]]$longName
      attr(RData$Variable,"units")<-variableInfo[[variableName]]$unitsEcoms
      
      RData$xyCoords$x[]<-round(RData$xyCoords$x[],2)
      RData$xyCoords$y[]<-round(RData$xyCoords$y[],2)
      
      RData$xyCoords$x<-as.numeric(RData$xyCoords$x)
      RData$xyCoords$y<-as.numeric(RData$xyCoords$y)
      
      ## set all negative precipitation values 0
      if (variableName == "pr") {
        RData$Data[RData$Data < 0] <- 0
        
        ################# Add first days if needed
        if (leadMonth == 0) {
          require(Hmisc)
          
          sYear<-format(as.Date(RData$Dates$start[1]), "%Y")
          month<-format(as.Date(RData$Dates$start[1]), "%m")
          nTimeOld<-length(RData$Dates$start)
          eYear<-format(as.Date(RData$Dates$start[nTimeOld]), "%Y")
          targetDates<-NULL
          
          for (iYear in c(sYear:eYear)) {
            sDate <- as.Date(paste0(iYear,"/", month,"/01"))
            edayMonth <- monthDays(as.Date(paste0(iYear,"/", month,"/01")))
            eDate <- as.Date(paste0(iYear,"/", month,"/", edayMonth))
            ## List of dates that should be in dataset
            if(is.null(targetDates)) {
              targetDates<-seq(sDate, eDate, "days")
            } else {
              targetDates<-c(targetDates, seq(sDate, eDate, "days"))
            }
          }
          #print(targetDates)
          
          ## Get the ndexnumbers of the missing dates
          # missingIndexes <- which(is.na(match(targetDates,as.Date(RData$Dates$start))))
          indexes <- match(targetDates,as.Date(RData$Dates$start))
          nTimeNew <- length(targetDates)
          
          RDataNew<-RData
          RDataNew$Dates$start <- format(targetDates, "%Y-%m-%d %X GMT")
          RDataNew$Dates$end <- format(targetDates+1, "%Y-%m-%d %X GMT")
          RDataNew$Data <-array(NA, dim = c(dim(RData$Data)[1],nTimeNew,dim(RData$Data)[3],dim(RData$Data)[4]))
          
          iTimeOld <- 1
          for (iTime in c(1:nTimeNew)) {
#            print(paste(iTime, iTimeOld))
            if (is.na(indexes[iTime])){
              RDataNew$Data[,iTime,,] <- 0
            } else {
              RDataNew$Data[,iTime,,] <- RData$Data[,iTimeOld,,]
              iTimeOld <- iTimeOld + 1
            }
          }
          attr(RDataNew$Data,"dimensions") <- attributes(RData$Data)[2]$dimensions
          RData <- RDataNew
        }
        #######################
      }
      
      ## Convert Units
      if (variableName == "rsds" || variableName == "rlds") {
        RData<-convert(RData, fromUnit = "1 W m-2", toUnit = variableInfo[[variableName]]$units)
      } else {
        RData<-convert(RData, toUnit = variableInfo[[variableName]]$units)
        # RData<-convert(RData, fromUnit = variableInfo[[variableName]]$unitsEcoms, toUnit = variableInfo[[variableName]]$units)
      }
      
      # ## check if grids are the same as mask
      # ## if not: make the same as mask
      # if (RData$xyCoords$x[1] != locationInfo[[sprintf("res%s",resolution)]][[locName]]$lonmin ||
      #     RData$xyCoords$x[length(RData$xyCoords$x)] != locationInfo[[sprintf("res%s",resolution)]][[locName]]$lonmax ||
      #     RData$xyCoords$y[1] != locationInfo[[sprintf("res%s",resolution)]][[locName]]$latmin ||
      #     RData$xyCoords$y[length(RData$xyCoords$y)] != locationInfo[[sprintf("res%s",resolution)]][[locName]]$latmax) {
      # 
      #   indexesLat<-c(which(RData$xyCoords$y==mask$xyCoords$y[1]):which(RData$xyCoords$y==mask$xyCoords$y[length(mask$xyCoords$y)]))
      #   indexesLon<-c(which(RData$xyCoords$x==mask$xyCoords$x[1]):which(RData$xyCoords$x==mask$xyCoords$x[length(mask$xyCoords$x)]))
      #   RData$xyCoords$x<-RData$xyCoords$x[indexesLon]
      #   RData$xyCoords$y<-RData$xyCoords$y[indexesLat]
      #   attr(RData$Data,"projection") <- "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs +towgs84=0,0,0"
      #   RData$Data<-RData$Data[,indexesLat,indexesLon]
      #   attr(RData$Data,"dimensions") <- c("time","lat","lon")
      # }
      attr(RData$Data,"projection") <- "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs +towgs84=0,0,0"
      
      if (resolution == "0.50") {
        # newGrid<-getGrid(mask)
        # print("Regridding")
        # RData <- interpGrid(RData, new.coordinates =  newGrid, method = "bilinear")
        
        ## Save file...
        outFileTmp<-paste0(outFile,".tmp")
        R2Netcdf(outFileTmp, RData)
        rm(RData)
        outFileGrid<-paste0(outFile,"grid.txt")
        
        gridString<-paste0("gridtype = lonlat\n",
                           "xsize    = ", length(mask$xyCoords$x), "\n",
                           "ysize    = ", length(mask$xyCoords$y), "\n",
                           "xfirst   = ", mask$xyCoords$x[1], "\n",
                           "xinc     = 0.5\n",
                           "yfirst   = ", mask$xyCoords$y[1], "\n",
                           "yinc     = 0.5")
        # print(outFileGrid)
        write(gridString, file = outFileGrid)
        
        system(paste0("cdo remapbil,", outFileGrid, " ", outFileTmp, " ", outFile),wait = TRUE)
        RData <- Netcdf2R(outFile, variableName)
        file.remove(outFileGrid)
        file.remove(outFileTmp)
      }
      
      ## Apply mask
      for (iTime in 1:length(RData$Dates$start)) {
        for (iMember in 1:length(RData$Members)) {
          RData$Data[iMember,iTime,,]<-RData$Data[iMember,iTime,,]*mask$Data[1,,]
        }
      }
      
      #      ## Make NA values really NA values
      #      RData$Data[is.na(RData$Data)] <- NaN
      
      ## add some extra attributes
      attr(RData,"contact") <- "Wietse Franssen (wietse.franssen@wur.nl)"
      
      ## Save file...
      R2Netcdf(outFile, RData)
      rm(RData)
    }
  }
}

