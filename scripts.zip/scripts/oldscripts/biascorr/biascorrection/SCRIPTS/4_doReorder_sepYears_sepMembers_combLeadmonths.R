rm(list=ls())
source(file = "./functions/functionsGeneral.R")
source(file = "./functions/functionR2Netcdf.R")
source(file = "./functions/functionNetcdf2R.R")
source(file = "./functions/functionConvert.R")
source(file = "./functions/infoGeneral.R")

submitscript <- FALSE

if (submitscript) {
  members      <- c(1:15)
  initYears    <- c(1981:2010)
  initMonths   <- c(X:X)
  locName      <- 'X'
  resolution   <- 'X'
  bcInfo       <- 'X'
  inPath       <- sprintf("../DATA/System4_seasonal_15_rev5.0/%sdeg/%s_%s_biasformat", resolution, locName, bcInfo)
  outPath      <- sprintf("../DATA/System4_seasonal_15_rev5.0/%sdeg/%s_%s", resolution, locName, bcInfo)
} else {
  members      <- c(1:15)
  initYears    <- c(1981:2010)
  initMonths   <- c(1:12)
  locName      <- "GHA"
  #locName      <- "EU"
  resolution   <- "0.75"
  bcInfo       <- "BC"
  inPath       <- sprintf("../DATA/System4_seasonal_15_rev4.0/%sdeg/%s_%s_biasformat", resolution, locName, bcInfo)
  outPath      <- sprintf("../DATA/System4_seasonal_15_rev4.0/%sdeg/%s_%s", resolution, locName, bcInfo)
}

variables<-names(variableInfo)

leadMonths<-c(0:6)

print("start")
for (initMonth in initMonths) {
  for (variableName in variables) {
    outPathTmp<-sprintf("%s/%s/", outPath, variableName)
    dir.create(outPathTmp, recursive = TRUE, showWarnings = FALSE)
    allocatedOutputArray<-FALSE
    
    for (leadMonth in leadMonths) {
      indexesYearsLeadMonths<-indexesForYearsPerLeadMonth(initYears[1],initYears[length(initYears)],initMonth)
      
      targetMonth <- getInitTargetInfo( initYear = 0000, initMonth = initMonth, leadMonth = leadMonth )$targetMonth
      targetSYear <- getInitTargetInfo( initYear = initYears[1], initMonth = initMonth, leadMonth = leadMonth )$targetYear
      targetEYear <- getInitTargetInfo( initYear = initYears[length(initYears)], initMonth = initMonth, leadMonth = leadMonth )$targetYear
    
      iPrefix <- sprintf("%s/%s/%s_forcing_seas15_%s_%s_E%02d-%02d_TAR%4d-%4d_%02d_LM%d",
                         inPath, variableName, variableName, locName, bcInfo,
                         members[1], members[length(members)],
                         targetSYear, targetEYear,
                         targetMonth, leadMonth)
      print(iPrefix)
      #load(sprintf("%s.RData",iPrefix))
      RData<-Netcdf2R(sprintf("%s.nc4",iPrefix),variableName)      
#      gc(reset = TRUE)
#      showMemoryUse(decreasing=TRUE, limit=5)

      if (!allocatedOutputArray) {
        ## allocate arrays
        finalList<-NULL
        listNames<-NULL
        for (iLM in 1:7) {
          finalList[[iLM]] <- RData
          listNames<-c(listNames,paste0("LeadMonth_",iLM-1))
          totalDays<-indexesYearsLeadMonths$eIndexes[as.character(initYears[length(initYears)]),iLM]
          
          finalList[[iLM]]$Data<-array(NA,dim=c(length(members),totalDays,length(RData$xyCoords$y),length(RData$xyCoords$x)))
          finalList[[iLM]]$Dates$start<-character(length=totalDays)
          finalList[[iLM]]$Dates$end<-character(length=totalDays)
        }
        names(finalList)<-listNames
        allocatedOutputArray<-TRUE
      }
      finalList[[paste0("LeadMonth_",leadMonth)]]<-RData
#      gc(reset = TRUE)
#      showMemoryUse(decreasing=TRUE, limit=5)
    }
    
    for (initYear in initYears) {
      indexes<-indexesOfDaysPerMonth(initMonth, 7, initYear = initYear)
      
      ## Init structure
      RData<-finalList[["LeadMonth_0"]]
      RData$Data<-array(NA,dim=c(indexes[7,"eIndex"],length(RData$xyCoords$y),length(RData$xyCoords$x)))
      attr(RData$Data,"dimensions")<-c("time", "lat", "lon")
      RData$Dates$start<-array("",dim=c(indexes[7,"eIndex"]))
      RData$Dates$end<-array("",dim=c(indexes[7,"eIndex"]))

      for (iMember in members) {
        ## Fill with data
        for (iLM in 1:7) {
          month<-indexes[iLM,"month"]
          year<-indexes[iLM,"year"]
          datesInCurrMonth <- seq(as.Date(as.Date(sprintf("%04d-%02d-01", year, month))),by = "1 day", length=indexes[iLM,"nDaysTotalInMonth"])
          iDates<-which(is.element(as.Date(finalList[[iLM]]$Dates$start),datesInCurrMonth),TRUE)
          RData$Dates$start[indexes[iLM,"sIndex"]:indexes[iLM,"eIndex"]]<-finalList[[iLM]]$Dates$start[iDates]
          RData$Dates$end[indexes[iLM,"sIndex"]:indexes[iLM,"eIndex"]]<-finalList[[iLM]]$Dates$end[iDates]
          RData$Data[indexes[iLM,"sIndex"]:indexes[iLM,"eIndex"],,]<-finalList[[iLM]]$Data[iMember,iDates,,]
        }
        RData$Members<-finalList[[iLM]]$Members[which(initYears==initYear)]
        RData$InitializationDates<-finalList[[iLM]]$InitializationDates[which(initYears==initYear)]

        ## Save to file...
        outFile <- sprintf("%s/%s_forcing_seas15_%s_%s_E%02d_INIT%04d_%02d", outPathTmp, variableName, locName, bcInfo, iMember, initYear, initMonth)
        R2Netcdf(outFile = sprintf("%s.nc4",outFile), RData)
      }
    }
  }
}
