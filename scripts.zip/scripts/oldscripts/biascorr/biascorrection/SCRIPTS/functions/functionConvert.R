library(udunits2)

convert <- function(RData, fromUnit = NULL, toUnit) {
  if (is.null(attr(RData$Variable,"units")) && is.null(fromUnit)) {
    stop("cannot find unit attribute in RData! Please also specify 'fromUnit'")
  }
  if (is.null(fromUnit)) {
    fromUnit<-attr(RData$Variable,"units")
  }
  if (fromUnit != toUnit) {
    print(paste0("Convert from ", fromUnit, " to ", toUnit))
    ## START: Exception handling
    fromUnit_org<-fromUnit
    toUnit_org<-toUnit
    if (fromUnit == "kg m-2 s-1") fromUnit <- "mm s-1"
    if (toUnit_org == "kg m-2 s-1") toUnit <- "mm s-1"
    ## END: Exception handling
    
    RData$Data[]<-ud.convert(RData$Data[],fromUnit,toUnit)
    attr(RData$Variable,"units")<-toUnit_org
  } else {
    print(paste0("No conversion needed: fromUnit = ", fromUnit, " and toUnit = ", toUnit))
  }
  return(RData)
}
