library(ncdf4)
library(stringr)

Netcdf2R <- function(inFile, variableName) {
  
  ## OPEN NC-DATA
  print(paste0("Opening: ", inFile))
  ncid <- nc_open(inFile)
  ncatt_get(ncid,0)
  #ncid$var$tas$dim[[3]]$name
  #ncid$var$tas$atts
  
  ## Define the oder of the dimension for the current variable
  dimensions<-NULL
  for (id in 1:length(ncid$var[[variableName]]$dimids)) {
    dimensions<-c(dimensions,ncid$var[[variableName]]$dim[[id]]$name)
  }
  
  ncid$var[[variableName]]$name
  ncid$dim$time$units
  
  # TIME
  timeUnits<-word(ncid$dim$time$units,1)
  timeSince<-as.Date(word(ncid$dim$time$units,3))
  timeSince<-word(ncid$dim$time$units,3)
  timeSeries<-ncid$dim$time$vals
  if (timeUnits == "days") {
    startDates<-as.character(as.POSIXct(timeSeries*86400, origin = timeSince, tz = "GMT"))   # in UTC
    endDates<-as.character(as.POSIXct((timeSeries+1)*86400, origin = timeSince, tz = "GMT"))   # in UTC
  } else if (timeUnits == "minutes") {
    startDates<-as.character(as.POSIXct(timeSeries*1440, origin = timeSince, tz = "GMT"))   # in UTC
    endDates<-as.character(as.POSIXct((timeSeries+1)*1440, origin = timeSince, tz = "GMT"))   # in UTC
  } else {
    stop(paste0("!!!!!!! Timeunit is not days of minutes! (but: ",timeUnits,")"))
  }
  
  ## Define r-datastructure
  # Variable
  lVariable <- list(varName = ncid$var[[variableName]]$name, isStandard = TRUE, level = NULL)
  attributeList<-ncatt_get(ncid,variableName)
  if ('_FillValue' %in% names(attributeList)) {
    attributeList['_FillValue']<-NULL  
  }
  for (iAttribute in 1:length(attributeList)) {
    attr(lVariable,names(attributeList[iAttribute])) <- attributeList[[iAttribute]]
  }
  # Members
  if ('_FillValue' %in% names(attributeList)) {
    lMembers <- ncatt_get(ncid,0)$Members
    RData <- c(RData, Members = strsplit(lMembers, ","))
    attributeList["Members"]<-NULL
  }
  
  
  
  # data
  lData <- ncvar_get(ncid,variableName)
  
  attr(lData,"dimensions") <- dimensions
  attr(lData,"dim") <- ncid$var[[variableName]]$size
  
  # xyCoords
  lxyCoords <- list(x = ncid$dim$lon$vals, y = ncid$dim$lat$vals) 
  
  # Dates
  lDates <- list(start = startDates,end = endDates)
  # Combining everything
  RData <- list(Variable = lVariable, Data = lData, xyCoords = lxyCoords, Dates = lDates)
  
  ## Add some extras
  # Init Dates
  attributeList<-ncatt_get(ncid,0)
  if ('InitializationDates' %in% names(attributeList)) {
    lInitDates <- ncatt_get(ncid,0)$InitializationDates
    RData <- c(RData, InitializationDates = strsplit(lInitDates, ","))
    attributeList["InitializationDates"]<-NULL
  }
  # Members
  if ('Members' %in% names(attributeList)) {
    lMembers <- ncatt_get(ncid,0)$Members
    RData <- c(RData, Members = strsplit(lMembers, ","))
    attributeList["Members"]<-NULL
  }
  
  for (iAttribute in 1:length(attributeList)) {
    if(grepl("xyCoords_", names(attributeList[iAttribute]))) {
      attr(RData$xyCoords, gsub("xyCoords_", "", names(attributeList[iAttribute]))) <- attributeList[[iAttribute]]
    } else {
      attr(RData,names(attributeList[iAttribute])) <- attributeList[[iAttribute]]
    }
  }
  RData<-FixRDataDimensionorder(RData)
  
  nc_close(ncid)
  return(RData)
}