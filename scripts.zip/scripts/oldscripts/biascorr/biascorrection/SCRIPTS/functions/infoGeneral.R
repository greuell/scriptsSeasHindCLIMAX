locationInfo <- list(
  res0.75 = list(
    GHA    = list(lonmin = 27.75,  lonmax = 49.50,  latmin =-12.00,  latmax = 18.00, longName = "Greater Horn of Africa"),
    SA     = list(lonmin =-83.00,  lonmax =-32.00,  latmin =-57.00,  latmax = 14.00, longName = "South America"),
    EU     = list(lonmin =-24.75,  lonmax = 39.75,  latmin = 33.00,  latmax = 72.00, longName = "Europe"),
    GLOBAL = list(lonmin =-180.00, lonmax = 180.00, latmin = -90.00, latmax = 90.00, longName = "Global"),
    S_ASIA = list(lonmin = 85.00,  lonmax =  95.00, latmin =  20.00, latmax = 30.00, longName = "South Asia")
  ),
  res0.50 = list(
    GHA    = list(lonmin = 28.25,  lonmax = 49.25,  latmin =-11.75,  latmax = 17.75, longName = "Greater Horn of Africa"),
    SA     = list(lonmin =-83.25,  lonmax =-32.25,  latmin =-57.25,  latmax = 14.25, longName = "South America"),
    EU     = list(lonmin =-24.25,  lonmax = 39.75,  latmin = 33.25,  latmax = 71.75, longName = "Europe"),
    GLOBAL = list(lonmin =-179.75, lonmax = 179.75, latmin = -89.75, latmax = 89.75, longName = "Global"),
    S_ASIA = list(lonmin = 85.25,  lonmax = 94.75,  latmin = 20.25,  latmax = 29.75, longName = "South Asia")
  )
)

variableInfo <- list(
  tas     = list(standardName = "air_temperature",                           longName = "Near-Surface Air Temperature",               unitsEcoms = "Celsius",         unitsEasy = "Celsius",  units = "K", aggr = "none"),
  tasmin  = list(standardName = "air_min_temperature",                       longName = "Daily Minimum Near-Surface Air Temperature", unitsEcoms = "Celsius",         unitsEasy = "Celsius",  units = "K", aggr = "none"),
  tasmax  = list(standardName = "air_max_temperature",                       longName = "Daily Maximum Near-Surface Air Temperature", unitsEcoms = "Celsius",         unitsEasy = "Celsius",  units = "K", aggr = "none"),
  pr      = list(standardName = "precipitation_flux",                        longName = "Precipitation",                              unitsEcoms = "mm day-1",        unitsEasy = "mm day-1", units = "kg m-2 s-1", ecomsName = "tp", aggr = "none"),
#  psl     = list(standardName = "air_pressure_at_sea_level",                 longName = "Sea level pressure",                         unitsEcoms = "Pa",              unitsEasy = "Pa",       units = "Pa", aggr = "mean"),
  rsds    = list(standardName = "surface_downwelling_shortwave_flux_in_air", longName = "Surface Downwelling Shortwave Radiation",    unitsEcoms = "1/86400^2 W m-2", unitsEasy = "W m-2",    units = "W m-2", aggr = "none"),
  rlds    = list(standardName = "surface_downwelling_longwave_flux_in_air",  longName = "Surface Downwelling Longwave Radiation",     unitsEcoms = "1/86400^2 W m-2", unitsEasy = "W m-2",    units = "W m-2", aggr = "none"),
  huss    = list(standardName = "specific_humidity",                         longName = "Near-Surface Specific Humidity",             unitsEcoms = "kg kg-1",         unitsEasy = "kg kg-1",  units = "kg kg-1", aggr = "mean"),
  sfcWind = list(standardName = "wind_speed",                                longName = "Near-Surface Wind Speed",                    unitsEcoms = "m s-1",           unitsEasy = "m s-1",    units = "m s-1", ecomsName = "wss", aggr = "mean")
)

colorbarLimits <- list(
  tas     = list(minValue =  -20, maxValue =  40,   diffMin = -0.5, diffMax = 0.5),
  tasmin  = list(minValue =  -20, maxValue =  40,   diffMin = -0.5, diffMax = 0.5),
  tasmax  = list(minValue =  -20, maxValue =  40,   diffMin = -0.5, diffMax = 0.5),
  pr      = list(minValue =    0, maxValue =  10,   diffMin = -0.2, diffMax = 0.2),
#  psl     = list(minValue =    0, maxValue =  10,   diffMin = -0.2, diffMax = 0.2),
  rsds    = list(minValue =    0, maxValue = 400,   diffMin = -1.0, diffMax = 1.0),
  rlds    = list(minValue = -200, maxValue = 500,   diffMin = -1.0, diffMax = 1.0),
  huss    = list(minValue =    0, maxValue =  0.02, diffMin = -0.001, diffMax = 0.001),
  sfcWind = list(minValue =    0, maxValue =  10,   diffMin = -0.2, diffMax = 0.2)
)
