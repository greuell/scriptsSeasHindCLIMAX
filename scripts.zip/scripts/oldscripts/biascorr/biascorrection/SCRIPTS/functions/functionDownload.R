library(fields) # e.g: using the fields library
library(abind)
library(ncdf4)
library(ecomsUDG.Raccess)
source(file = "./functions/infoGeneral.R")
source(file = "./functions/functionsGeneral.R")
source(file = "./functions/functionR2Netcdf.R")

loginECOMS_UDG(username = "wietsefranssen", password = "ECOMS")

downloadSeas15 <- function(variableInfo, locationInfo, member, initYear, initMonth) {
  indexes<-indexesOfDaysPerMonth(initMonth,7,initYear)
  print(indexes)
  nDaysTotal<-indexes[(dim(indexes)[1]),"eIndex"]
  variableName<-names(variableInfo)[1]
  locationName<-names(locationInfo)[1]
  locationInfo<-locationInfo[[locationName]]
  variableInfo<-variableInfo[[variableName]]
  
  if ('ecomsName' %in% names(variableInfo)) {
    variableNameECOMS<-variableInfo$ecomsName
  } else {
    variableNameECOMS<-variableName
  }
  
  madeNewArray<-FALSE
  
  for (iMonth in 1:7) {
    print(paste0("DOWNLOAD: ", variableName, ", location: ", locationName, ", member: ", member, ", initYear: ", indexes[iMonth,"year"], ", season: ", month.name[indexes[iMonth,"month"]],", leadMonth: ", indexes[iMonth,"leadMonth"]))
    RData <- loadECOMS(dataset = "System4_seasonal_15", 
                       var = variableNameECOMS,
                       members = member, 
                       lonLim = c(locationInfo$lonmin, locationInfo$lonmax),
                       latLim = c(locationInfo$latmin, locationInfo$latmax), 
                       season = indexes[iMonth,"month"], 
                       years = indexes[iMonth,"year"], 
                       # years = initYear, 
                       leadMonth = indexes[iMonth,"leadMonth"],
                       time = "DD")
    #     nameFileRout <- sprintf(paste0(outPath,"RDataLM%1d.RData"), indexes[iMonth,"leadMonth"])
    #     print(paste0("Saving: ", nameFileRout))
    #     save(RData,file=nameFileRout)
    #     ## READIN FROM FILE    
    #         nameFileRin <- sprintf(paste0(outPath,"/../data/RDataLM%1d.RData"), indexes[iMonth, "leadMonth"])
    #         print(paste0("Opening: ", nameFileRin))
    #         load(nameFileRin)
    
    if (variableName == "rsds" || variableName == "rlds") {
      if (iMonth ==1) {
        print("fixing rsds and rlds extra first day issue of leadmonth 0...")
        RData$Dates$start<-RData$Dates$start[2:length(RData$Dates$start)]
        RData$Dates$end<-RData$Dates$end[2:length(RData$Dates$end)]
        RData$Data<-RData$Data[2:length(RData$Data[,1,1]),,]
      }
    }
    
    #print(RData$Dates$start)
    ## Make new array
    if (madeNewArray==FALSE) {
      RDataNew<-RData
      RDataNew$Data<-array(NA,dim = c(nDaysTotal,dim(RData$Data)[2],dim(RData$Data)[3]))
      RDataNew$Dates$start<-array(NA,dim = c(nDaysTotal))
      RDataNew$Dates$end<-array(NA,dim = c(nDaysTotal))
      madeNewArray<-TRUE
    }    
    
    ## Paste datasets
    ## Fill new array
    RDataNew$Data[indexes[iMonth,"sIndex"]:indexes[iMonth,"eIndex"],,]<-RData$Data[1:indexes[iMonth,"nDaysTotalInMonth"],,]
    RDataNew$Dates$start[indexes[iMonth,"sIndex"]:indexes[iMonth,"eIndex"]]<-RData$Dates$start[1:indexes[iMonth,"nDaysTotalInMonth"]]
    RDataNew$Dates$end[indexes[iMonth,"sIndex"]:indexes[iMonth,"eIndex"]]<-RData$Dates$end[1:indexes[iMonth,"nDaysTotalInMonth"]]
  }
  RData<-RDataNew
  
  RData$xyCoords$x<-round(RData$xyCoords$x,2)
  RData$xyCoords$y<-round(RData$xyCoords$y,2)
  
  # Check units
  RData$Variable$varName<-variableName
  attr(RData$Variable,"standard_name")<-variableInfo$standardName
  attr(RData$Variable,"long_name")<-variableInfo$longName
  attr(RData$Variable,"units")<-variableInfo$unitsEcoms
  
  ## add some extra attributes
  attr(RData,"contact") <- "Wietse Franssen (wietse.franssen@wur.nl)"
  
  return(RData)
}
