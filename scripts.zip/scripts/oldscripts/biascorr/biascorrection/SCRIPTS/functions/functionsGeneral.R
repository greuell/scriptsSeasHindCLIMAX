## Sets all kinds of RData orders to the fixed order:
## c("member", "time","lat","lon") or
## c("time","lat","lon")
FixRDataDimensionorder<-function(RData) {
  nDim<-length(dim(RData$Data))
  
  order_old<-attr(RData$Data,"dimensions")
  if (is.null(order_old)) {
    stop("'dimensions' attribute must be defined!")
  }
  
  if (nDim == 4) {  
    order_new<-c("member", "time","lat","lon")
  } else if (nDim == 3) {  
    order_new<-c("time","lat","lon")
  } else {
    stop("number of dimensions should be 3 or 4!")
  }
  to<-match(order_new,order_old)
  dims_old<-dim(RData$Data)
  RData$Data<-aperm(RData$Data, c(to))
  attr(RData$Data,"dimensions")<-order_new
  cat("old order: ");print(sprintf("%s (%s)",order_old,dims_old ))
  cat("new order: ");print(sprintf("%s (%s)",order_new,dim(RData$Data) ))
  return(RData)
}

## Calculation of the index numbers of a set of months
## eg: indexes<-indexesOfDaysPerMonth(1,7,1980)
indexesOfDaysPerMonth <- function(initMonth, nMonths, initYear) {
  indexes <-matrix(0,nMonths,6)
  colnames(indexes) <- c("sIndex","eIndex","nDaysTotalInMonth","year","month","leadMonth")
  dates<-seq(as.Date(paste0(initYear,"-",initMonth,"-1")), by = "1 month", length=nMonths+1)
  for (iMonth in 1:nMonths) {
    indexes[iMonth,6]<-iMonth - 1
    indexes[iMonth,5]<-as.numeric(format(dates[iMonth], "%m"))
    indexes[iMonth,4]<-as.numeric(format(dates[iMonth], "%Y"))
    indexes[iMonth,3]<-difftime(dates[iMonth+1] ,dates[iMonth] , units = c("days"), tz = "GMT")
    indexes[iMonth,2]<-difftime(dates[iMonth+1] ,dates[1] , units = c("days"), tz = "GMT")
    indexes[iMonth,1]<-indexes[iMonth,2]-indexes[iMonth,3]+1
  }
  return(indexes)
}

## Calculation of the index numbers of a set of years for one month
## eg: indexesOfDaysYears(2,1981,1990)
indexesOfDaysYears <- function(month,sYear,eYear) {
  nYears<-eYear-sYear+1
  indexes <-matrix(0,nYears,5)
  colnames(indexes) <- c("sIndex","eIndex","nDaysTotalInMonth","year","month")
  dates<-seq(as.Date(paste0(sYear,"-",month,"-1")), by = "1 year", length=nYears)
  for (iYear in 1:nYears) {
    indexes[iYear,"month"]<-as.numeric(format(dates[iYear], "%m"))
    indexes[iYear,"year"]<-as.numeric(format(dates[iYear], "%Y"))
    currAndNextMonth<-seq(dates[iYear], by = "1 month", length=2)
    indexes[iYear,"nDaysTotalInMonth"]<-difftime(currAndNextMonth[2] ,currAndNextMonth[1] , units = c("days"), tz = "GMT")
    if (indexes[iYear,"year"] == sYear){
      indexes[iYear,"eIndex"]<-indexes[iYear,3]
    } else {
      indexes[iYear,"eIndex"]<-indexes[iYear-1,"eIndex"]+indexes[iYear,"nDaysTotalInMonth"]
    }
    indexes[iYear,"sIndex"]<-indexes[iYear,"eIndex"]-indexes[iYear,"nDaysTotalInMonth"]+1
  }
  return(indexes)
}


## Calculation of the index numbers for a set of years and a set of lead months
## eg: indexesOfDaysYears(2,1981,1990)
indexesForYearsPerLeadMonth<-function(sYear,eYear,initMonth,nLM=7) {
  months<-indexesOfDaysPerMonth(initMonth, nLM, sYear)[,"month"]
  years<-indexesOfDaysPerMonth(initMonth, nLM, sYear)[,"year"]
  nYears<-eYear-sYear+1
  sIndexes <-matrix(0,nYears,nLM)
  colnames(sIndexes) <- months
  rownames(sIndexes) <- c(sYear:eYear)
  eIndexes<-sIndexes
  i<-1
  for (iMonth in months) {
    sIndexes[,i]<-indexesOfDaysYears(iMonth,years[i],years[i]+nYears-1)[,"sIndex"]
    eIndexes[,i]<-indexesOfDaysYears(iMonth,years[i],years[i]+nYears-1)[,"eIndex"]
    i<-i+1
  }
  indexes <- list(
    sIndexes = sIndexes,
    eIndexes = eIndexes
  )
  return(indexes)
}

getInitInfo<-function(targetYear, targetMonth, leadMonth) {
  minInitYearInData <- 1981
  maxInitYearInData <- 2010
  
  targetDate <- as.Date(sprintf("%04d-%02d-01", targetYear, targetMonth))
  substractMonthsString <- sprintf("-%d months",leadMonth)
  initDate <- seq(targetDate, length = 2, by = substractMonthsString)[2]  
  initYear <- as.numeric(format(initDate, "%Y"))
  initMonth <- as.numeric(format(initDate, "%m"))
  
  availableInSystem4 <- FALSE
  if (initYear >= minInitYearInData && initYear <= maxInitYearInData) availableInSystem4 <- TRUE
  
  return(list(initYear = initYear, initMonth = initMonth,availableInSystem4 = availableInSystem4))
}

getInitTargetInfo<-function(initYear = NULL, initMonth = NULL, leadMonth = NULL, targetYear = NULL, targetMonth = NULL) {
  minInitYearInData <- 1981
  maxInitYearInData <- 2010
  
  ## If target Year and Month were given
  if (!is.null(targetYear) && !is.null(targetMonth)) {
    targetDate <- as.Date(sprintf("%04d-%02d-01", targetYear, targetMonth))
    substractMonthsString <- sprintf("-%d months",leadMonth)
    initDate <- seq(targetDate, length = 2, by = substractMonthsString)[2]  
    initYear <- as.numeric(format(initDate, "%Y"))
    initMonth <- as.numeric(format(initDate, "%m"))
  } else if (!is.null(initYear) && !is.null(initMonth)) {
    ## If target Year and Month were given
    initDate <- as.Date(sprintf("%04d-%02d-01", initYear, initMonth))
    addMonthsString <- sprintf("%d months",leadMonth)
    targetDate <- seq(initDate, length = 2, by = addMonthsString)[2]  
    targetYear <- as.numeric(format(targetDate, "%Y"))
    targetMonth <- as.numeric(format(targetDate, "%m"))
  } else if (!is.null(initYear) && !is.null(targetMonth)) {
    initMonth <- targetMonth - leadMonth
    if (initMonth < 1) initMonth<-initMonth+12
    initDate <- as.Date(sprintf("%04d-%02d-01", initYear, initMonth))
    addMonthsString <- sprintf("%d months",leadMonth)
    targetDate <- seq(initDate, length = 2, by = addMonthsString)[2]  
    targetYear <- as.numeric(format(targetDate, "%Y"))
    targetMonth <- as.numeric(format(targetDate, "%m"))
  } else if (!is.null(targetYear) && !is.null(initMonth)) {
    targetMonth <- initMonth + leadMonth
    if (targetMonth > 12) targetMonth<-targetMonth-12
    targetDate <- as.Date(sprintf("%04d-%02d-01", targetYear, targetMonth))
    substractMonthsString <- sprintf("-%d months",leadMonth)
    initDate <- seq(targetDate, length = 2, by = substractMonthsString)[2]  
    initYear <- as.numeric(format(initDate, "%Y"))
    initMonth <- as.numeric(format(initDate, "%m"))
  } else {
    stop("error: Please give a leadMonth and a year/month combination!") 
  }
  availableInSystem4 <- FALSE
  if (initYear >= minInitYearInData && initYear <= maxInitYearInData) availableInSystem4 <- TRUE
  
  return(list(initYear = initYear, targetYear = targetYear, initMonth = initMonth, targetMonth = targetMonth, leadMonth =leadMonth, availableInSystem4 = availableInSystem4))
}

## get the available target years (in system-4) for the certain targetMonth and leadMonth
getAvailableTargetYears <- function(targetYears, targetMonth, leadMonth) {
  arrayAvailableInSystem4<-NULL
  for (targetYear in targetYears) {
    result<-getInitInfo(targetYear = targetYear, targetMonth = targetMonth, leadMonth = leadMonth)[["availableInSystem4"]]
    arrayAvailableInSystem4<-c(arrayAvailableInSystem4,result)
  }
  yearsNew<-targetYears[arrayAvailableInSystem4==TRUE]
  return(targetYears = yearsNew)
}

multiplot <- function(..., plotlist=NULL, file, cols=1, layout=NULL) {
  library(grid)
  
  # Make a list from the ... arguments and plotlist
  plots <- c(list(...), plotlist)
  
  numPlots = length(plots)
  
  # If layout is NULL, then use 'cols' to determine layout
  if (is.null(layout)) {
    # Make the panel
    # ncol: Number of columns of plots
    # nrow: Number of rows needed, calculated from # of cols
    layout <- matrix(seq(1, cols * ceiling(numPlots/cols)),
                     ncol = cols, nrow = ceiling(numPlots/cols))
  }
  
  if (numPlots==1) {
    print(plots[[1]])
    
  } else {
    # Set up the page
    grid.newpage()
    pushViewport(viewport(layout = grid.layout(nrow(layout), ncol(layout))))
    
    # Make each plot, in the correct location
    for (i in 1:numPlots) {
      # Get the i,j matrix positions of the regions that contain this subplot
      matchidx <- as.data.frame(which(layout == i, arr.ind = TRUE))
      
      print(plots[[i]], vp = viewport(layout.pos.row = matchidx$row,
                                      layout.pos.col = matchidx$col))
    }
  }
}


