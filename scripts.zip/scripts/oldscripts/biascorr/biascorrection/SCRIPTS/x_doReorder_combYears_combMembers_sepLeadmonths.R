rm(list=ls())
source(file = "./functions/functionsGeneral.R")
source(file = "./functions/functionNetcdf2R.R")
source(file = "./functions/functionR2Netcdf.R")
source(file = "./functions/infoGeneral.R")

submitscript <- FALSE

if (submitscript) {
  members      <- c(1:15)
  initYears    <- c(1981:2010)
  initMonths   <- c(X:X)
  locName      <- 'X'
  resolution   <- 'X'
  bcInfo       <- 'X'
  inPath       <- sprintf("../DATA/System4_seasonal_15_rev4.0/%sdeg/%s_%s", resolution, locName, bcInfo)
  outPath      <- sprintf("../DATA/System4_seasonal_15_rev4.0/%sdeg/%s_%s_biasformat", resolution, locName, bcInfo)
} else {
  members      <- c(1:2)
  initYears    <- c(1981:1982)
  initMonths   <- 1
  locName      <- "GHA"
  #locName      <- "EU"
  locName      <- "SA"
  resolution   <- "0.75"
  resolution   <- "0.50"
  #  bcInfo       <- "BC"
  bcInfo       <- "noBC"
  inPath       <- sprintf("../DATA/System4_seasonal_15_rev4.0/%sdeg/%s_%s", resolution, locName, bcInfo)
  outPath      <- sprintf("../DATA/System4_seasonal_15_rev4.0/%sdeg/%s_%s_biasformat2", resolution, locName, bcInfo)
}

variables<-names(variableInfo)

leadMonths<-c(0:6)

dir.create(outPath, recursive = TRUE, showWarnings = FALSE)

print("start")
for (initMonth in initMonths) {
  for (variableName in variables) {
    allocatedOutputArray<-FALSE
    strMembers<-NULL
    strInitDates<-NULL
    # indexesOfDaysYears(1,sYear,eYear)
    for (initYear in initYears) {
      for (iMember in members) {
        initDates<-NULL
        iInitYear<-1
        
        indexesYearsLeadMonths<-indexesForYearsPerLeadMonth(initYears[1],initYears[length(initYears)],initMonth)

        ## Open file...
        inFile <- sprintf("%s/%s/%s_forcing_seas15_%s_%s_E%02d_INIT%04d_%02d", inPath, variableName, variableName, locName, bcInfo, iMember, initYear, initMonth)
        RData <- Netcdf2R(inFile = sprintf("%s.nc4",inFile), variableName)
        if (!allocatedOutputArray) {
          ## allocate arrays
          finalList<-NULL
          listNames<-NULL
          for (iLM in 1:7) {
            finalList[[iLM]] <- RData
            listNames<-c(listNames,paste0("LeadMonth_",iLM-1))
            totalDays<-indexesYearsLeadMonths$eIndexes[as.character(initYears[length(initYears)]),iLM]
            
            finalList[[iLM]]$Data<-array(0,dim=c(length(members),totalDays,length(RData$xyCoords$y),length(RData$xyCoords$x)))
            finalList[[iLM]]$Dates$start<-character(length=totalDays)
            finalList[[iLM]]$Dates$end<-character(length=totalDays)
            attr(finalList[[iLM]]$Data,"dimensions") <- c("member","time","lat","lon")
          }
          names(finalList)<-listNames
          allocatedOutputArray<-TRUE
        }

        ## Split the seven months
        indexes<-indexesOfDaysPerMonth(initMonth, 7, initYear = initYear)
        ## Split the data in seperate months
        parts<-NULL
        for (iLM in 1:7) {
          month            <- indexes[iLM,"month"]
          year             <- indexes[iLM,"year"]
          datesInCurrMonth <- seq(as.Date(as.Date(sprintf("%04d-%02d-01", year, month))),by = "1 day", length=indexes[iLM,"nDaysTotalInMonth"])
          iDates           <- c(indexesYearsLeadMonths$sIndexes[as.character(initYear),iLM]:indexesYearsLeadMonths$eIndexes[as.character(initYear),iLM])
          finalList[[iLM]]$Dates$start[iDates]    <- RData$Dates$start[indexes[iLM,"sIndex"]:indexes[iLM,"eIndex"]]
          finalList[[iLM]]$Dates$end[iDates]      <- RData$Dates$end[indexes[iLM,"sIndex"]:indexes[iLM,"eIndex"]]
          finalList[[iLM]]$Data[iMember,iDates,,] <- RData$Data[indexes[iLM,"sIndex"]:indexes[iLM,"eIndex"],,]
          tmp<-c(indexes[iLM,"sIndex"]:indexes[iLM,"eIndex"])
        }
        
        initDates[iInitYear]<-RData$Dates$start[1]
        iInitYear<-iInitYear+1

        if (iMember == members[1]) {
          strInitDates<-c(strInitDates, RData$InitializationDates)
        }
      }

      
      strMembers<-c(strMembers,paste0("Member_",iMember))
      for (iLM in 1:7) {
        finalList[[iLM]]$Members <- strMembers
        finalList[[iLM]]$InitializationDates <- strInitDates
      }
    }
    
    for (leadMonth in 1:7) {
      targetMonth <- getInitTargetInfo( initYear = 0000, initMonth = initMonth, leadMonth = leadMonth-1 )$targetMonth
      targetSYear <- getInitTargetInfo( initYear = initYears[1], initMonth = initMonth, leadMonth = leadMonth-1 )$targetYear
      targetEYear <- getInitTargetInfo( initYear = initYears[length(initYears)], initMonth = initMonth, leadMonth = leadMonth-1 )$targetYear
      
      RData<-finalList[[leadMonth]]
 
      print(sprintf("targetmonth: %s, leadMonth: %s",targetMonth, leadMonth-1))
      oPrefix <- sprintf("%s/%s_forcing_seas15_%s_%s_E%02d-%02d_TAR%4d-%4d_%02d_LM%d",
                         outPath, variableName, locName, bcInfo,
                         members[1], members[length(members)],
                         targetSYear, targetEYear,
                         targetMonth, leadMonth-1)
                        
      print(oPrefix)
      R2Netcdf(paste0(oPrefix, ".nc4"), RData)
    }
  }
}
