rm(list=ls())
library(fields) # e.g: using the fields library
library(abind)
library(ncdf4)
library(loadeR.ECOMS)
source(file = "./functions/infoGeneral.R")
source(file = "./functions/functionsGeneral.R")
source(file = "./functions/functionR2Netcdf.R")

loginUDG(username = "wietsefranssen", password = "ECOMS")

RData <- loadECOMS(dataset = "System4_seasonal_15", 
                   var = "tas",
                   members = 1, 
                   lonLim = c(-180,180),
                   latLim = c(-90,90), 
                   season = 1, 
                   years = 1990, 
                   leadMonth = 1,
                   time = "DD",
                   aggr.d = "mean")
RData2 <- loadECOMS(dataset = "System4_seasonal_15", 
                   var = "tas",
                   members = 1, 
                   lonLim = c(-179,180),
                   latLim = c(-90,90), 
                   season = 1, 
                   years = 1990, 
                   leadMonth = 1,
                   time = "DD",
                   aggr.d = "mean")
RData3 <- loadECOMS(dataset = "System4_seasonal_15", 
                    var = "tas",
                    members = 1, 
                    lonLim = c(-179,179),
                    latLim = c(-90,90), 
                    season = 1, 
                    years = 1990, 
                    leadMonth = 1,
                    time = "DD",
                    aggr.d = "mean")
RData4 <- loadECOMS(dataset = "System4_seasonal_15", 
                    var = "tas",
                    members = 1, 
                    lonLim = c(-180,180),
                    latLim = c(-70,70), 
                    season = 1, 
                    years = 1990, 
                    leadMonth = 1,
                    time = "DD",
                    aggr.d = "mean")
RData5 <- loadECOMS(dataset = "System4_seasonal_15", 
                    var = "tas",
                    members = 1, 
                    lonLim = c(-179,180),
                    latLim = c(-70,70), 
                    season = 1, 
                    years = 1990, 
                    leadMonth = 1,
                    time = "DD",
                    aggr.d = "mean")
RData6 <- loadECOMS(dataset = "System4_seasonal_15", 
                    var = "tas",
                    members = 1, 
                    lonLim = c(-179,179),
                    latLim = c(-70,70), 
                    season = 1, 
                    years = 1990, 
                    leadMonth = 1,
                    time = "DD",
                    aggr.d = "mean")

RData$xyCoords$x[]<-round(RData$xyCoords$x[],2)
RData2$xyCoords$x[]<-round(RData2$xyCoords$x[],2)
RData3$xyCoords$x[]<-round(RData3$xyCoords$x[],2)
RData4$xyCoords$x[]<-round(RData4$xyCoords$x[],2)
RData5$xyCoords$x[]<-round(RData5$xyCoords$x[],2)
RData6$xyCoords$x[]<-round(RData6$xyCoords$x[],2)

print(RData$xyCoords$x)
print(RData2$xyCoords$x)
print(RData3$xyCoords$x)

RData$xyCoords$x[1:3]
RData2$xyCoords$x[1:3]
RData3$xyCoords$x[1:3]
RData4$xyCoords$x[1:3]
RData5$xyCoords$x[1:3]
RData6$xyCoords$x[1:3]
length(RData$xyCoords$x)
length(RData2$xyCoords$x)
length(RData3$xyCoords$x)
RData$xyCoords$x[479:481]
RData2$xyCoords$x[478:480]
RData3$xyCoords$x[477:479]
RData4$xyCoords$x[479:481]
RData5$xyCoords$x[478:480]
RData6$xyCoords$x[477:479]

RData$Data[1,1:2,1:3]
RData2$Data[1,1:2,1:3]
RData3$Data[1,1:2,1:3]
RData4$Data[1,1:2,1:3]
RData5$Data[1,1:2,1:3]
RData6$Data[1,1:2,1:3]

RData$Data[1,1:2,479:481]
RData2$Data[1,1:2,478:480]
RData3$Data[1,1:2,477:479]

RData$Data[1,1,]
RData2$Data[1,1,]
RData3$Data[1,1,]
RData4$Data[1,1,]
