#!/bin/bash
#SBATCH -N 1                            ## Ensure that all cores are on one machine
#SBATCH --comment=5120776-01            ## Is het WUR projectnummer (5120867-01 = Euporias; 5120776-01 = IMPACT2C)
#SBATCH --time=5000                     ## Na deze (echte) tijd in minuten wordt job in ieder geval beeindigd
#SBATCH --mem=4048                      ## Is het maximale geheugen in MByte; als de computer meer nodig heeft, beeindigt hij de job
#SBATCH --ntasks=1                      ## Aantal processoren
#SBATCH --output=output_%j.txt
#SBATCH --error=error_output_%j.txt
#SBATCH --job-name=acq_forcing            
#SBATCH --partition=ESG_Std             ## Low kan eruitgegooid worden

# print date and time
date 

# Er komen aparte loops voor 3 datatypes
declare -a typevar=( 'static' '6' '24' )
ntypes=${#typevar[*]} 

dir_acqforcrun=dir_acqforcrun_ph
dir_acqforcoutput=dir_acqforcoutput_ph
dir_acqforcstatic=dir_acqforcstatic_ph
dir_scripts=dir_scripts_ph
dir_forcadj=dir_forcadj_ph

finiyear=finiyear_ph                                                                                                  
liniyear=liniyear_ph
domain=domain_ph
southb=southb_ph
northb=northb_ph
str_dur=str_dur_ph
westb=westb_ph
eastb=eastb_ph
lmem=lmem_ph
dl_grib=dl_grib_ph

nsecday=$((24*3600))

dir_temp=$dir_acqforcoutput'temporary/'
mkdir -p $dir_temp
rm -f $dir_temp/*
dir_grib=$dir_acqforcoutput'gribfiles/'
mkdir -p $dir_grib

fileSurfElev=$dir_acqforcstatic'SurfElev.nc'

# make a grid for the regridding to 0.5 x 0.5 degrees
dirgrid=$dir_scripts'grids/'
filegrid=$dirgrid'grid_'$domain'.txt'
if [ ! -e $filegrid ]
then

   file_emptygrid=$dirgrid'grid_empty.txt'
   cp $file_emptygrid $filegrid

   dgrid=$(echo "0.5" | bc)
   halfdgrid=$(echo "scale=8; 0.5 * $dgrid" | bc)
   dlon=$(echo "scale=8; $eastb - $westb" | bc)
   nlon=$(echo "$dlon / $dgrid" | bc)
   dlat=$(echo "scale=8; $northb - $southb" | bc)
   nlat=$(echo "$dlat / $dgrid" | bc)
   ncells=$((nlon*nlat))
   lonw=$(echo "$westb + $halfdgrid" | bc)
   lats=$(echo "$southb + $halfdgrid" | bc)

   sed -i "s|ncells_ph|$ncells|g" $filegrid
   sed -i "s|dgrid_ph|$dgrid|g" $filegrid
   sed -i "s|nlon_ph|$nlon|g" $filegrid
   sed -i "s|nlat_ph|$nlat|g" $filegrid
   sed -i "s|lonw_ph|$lonw|g" $filegrid
   sed -i "s|lats_ph|$lats|g" $filegrid
   
fi  

# Initialise presence of the following variables
PSeaL_pres='n'
PSurf_pres='n'
Tair_pres='n'
Tdew_pres='n'
Uwind_pres='n'
Vwind_pres='n'

for iniyear in $(seq $finiyear $liniyear); do
   for inimth in $(seq 1 12); do

      inimthstr=$inimth
      if [ "$inimth" -lt "10" ]
      then
         inimthstr='0'$inimth
      fi 
      
      all_files_6=''
      all_files_24=''
      nr_files_6=0
      nr_files_24=0
      
      dirout=$dir_forcadj'ini'$iniyear$inimthstr'_dur'$str_dur'/'
      mkdir -p $dirout         

      # Loop over three types of data: 6-hourly, 24-hourly ansd static      
      for (( itype=0; itype < $ntypes; itype++ ))
      do

          typehere=${typevar[$itype]}
         
          if [ "$typehere" == "static" ]
          then
             declare -a varname=( 'orography' )
          elif [ "$typehere" == "6" ]
          then
             declare -a varname=( '2m_temperature' 'mean_sea_level_pressure' \
                                  '2m_dewpoint_temperature' '10m_u_component_of_wind' \
                                  '10m_v_component_of_wind' )
             nvar6=${#varname[*]}
             declare -a parname6
          elif [ "$typehere" == "24" ]
          then
             declare -a varname=( 'total_precipitation' \
                                  'maximum_2m_temperature_in_the_last_24_hours' \
                                  'minimum_2m_temperature_in_the_last_24_hours' \
                                  'surface_solar_radiation_downwards' \
                                  'surface_thermal_radiation_downwards' )
             nvar24=${#varname[*]}
             declare -a parname24
          fi                        
                           
          nvartype=${#varname[*]}

          # De file met de hoogte van het oppervlak moet maar één maal opgehaald worden
          if [ "$typehere" == "static" ]
          then
             if [ -e $fileSurfElev ]
             then
                continue
             fi
             if [ "$nvartype" -eq "1" -a "${varname[0]}" != "orography" ]
             then
                echo 'There is something wrong with downloading static fields'
                exit
             fi
          fi

          # The form for downloading the data is filled with the variables names          
          varform='[ '
          for (( ivar=0; ivar < $((nvartype-1)); ivar++ ))
          do
             varhere=${varname[$ivar]}
             varform=$varform"'"$varhere"'"', '
          done
          varform=$varform"'"${varname[$((nvartype-1))]}"'"' ]'

          cd $dir_acqforcrun

          # Take the form for the 6-hourly, 24-hourly or the static data  
          case $typehere in
             '6')  cp form_acq_forc6_all.py form_acq_forc.py    ;; 
             '24') cp form_acq_forc24_all.py form_acq_forc.py   ;;
             'static') cp form_acq_stat_all.py form_acq_forc.py ;;
          esac 

          # Substitute the correct year and month of initialisation,
          #    and the names of the required variables         
          sed -i "s|inimthstr_ph|$inimthstr|g" form_acq_forc.py
          sed -i "s|varform_ph|$varform|g" form_acq_forc.py
          sed -i "s|iniyear_ph|$iniyear|g" form_acq_forc.py
          
          # Download grib from CDS ('y') or take files that have already been downloaded ('n')
          file_grib_type=$dir_grib'download_type'$typehere'_ini'$iniyear$inimthstr'_dur'$str_dur'.grib'
          if [ "$dl_grib" == "y" ]
          then
             python form_acq_forc.py
          elif [ "$dl_grib" == "n" ]
          then
             downl_file=$dir_temp'download.grib'
             cp $file_grib_type $downl_file
          fi
          
          # All the data will be downloaded into and
          #     manipulated within a temporary directory
          cd $dir_temp
          # Copy the grib to netcdf files
          cdo -f nc copy download.grib rawfile.nc
          cp download.grib $file_grib_type
          
          for (( ivar=0; ivar < $nvartype; ivar++ ))
          do

             varhere=${varname[$ivar]}
                      
             echo 'year='$iniyear '  month='$inimth '  varhere='$varhere
         
             # Let op: geen spaties in longname
             # Meer info over variabelen en hun parameter ID op 
             #    https://confluence.ecmwf.int/display/COPSRV/List+of+requested+variables en op
             #    https://cds.climate.copernicus.eu/cdsapp#!/dataset/seasonal-original-single-levels?tab=overview
             # Volgens de laatste pagina is de mean sea level pressure toch een instantane waarde       
             case $varhere in
                '2m_temperature') unit='K'; parid=167; parname='Tair'; longname='instantaneous_2_m_temperature' ;;
                '2m_dewpoint_temperature') unit='C'; parid=168; parname='Tdew'; longname='instantaneous_2_m_dew_point_temperature' ;;
                '10m_u_component_of_wind') unit='m/s'; parid=165; parname='Uwind'; longname='instantaneous_10_m_u-component_of_wind_speed' ;;
                '10m_v_component_of_wind') unit='m/s'; parid=166; parname='Vwind'; longname='instantaneous_10_m_v-component_of_wind_speed' ;;
                'minimum_2m_temperature_in_the_last_24_hours') unit='C'; parid=52; parname='Tmin'; longname='daily_minimum_2_m_temperature' ;;
                'maximum_2m_temperature_in_the_last_24_hours') unit='C'; parid=51; parname='Tmax'; longname='daily_maximum_2_m_temperature' ;;
                'mean_sea_level_pressure') unit='kPa'; parid=151; parname='PSeaLevel'; longname='instantaneous_sea_level_pressure' ;;
                'orography') unit='m';  parid=129; parname='SurfElev'; longname='Surface_elevation' ;;
                'surface_solar_radiation_downwards') unit='W/m2'; parid=169; parname='SWdown'; longname='daily_mean_surface_incoming_solar_radiation' ;;
                'surface_thermal_radiation_downwards') unit='W/m2'; parid=175; parname='LWdown'; longname='daily_mean_surface_incoming_long-wave_radiation' ;;
                'total_precipitation') unit='mm'; parid=228; parname='Precip'; longname='daily_sum_of_precipitation' ;;
                *) exit 'No variable type assigned' ;;
             esac
         
             if [ "$typehere" == "6" ]
             then
                parname6parname[$ivar]=$parname
             elif [ "$typehere" == "24" ]
             then
                parname24[$ivar]=$parname
             fi
             
             file_varhere='file_'$parname'.nc'
             file_varhere_uncorr='file_'$parname'_uncorr.nc'
             varstr='var'$parid

             # Provide the correct longname, variable name and unit         
             # o: overwrite
             # c: create attribute
             ncrename -v $varstr,$parname rawfile.nc
             ncatted -O -a long_name,$parname,o,c,$longname rawfile.nc
             ncatted -O -a unit,$parname,o,c,$unit rawfile.nc

             # Select the array for a single variable
             cdo select,name=$parname rawfile.nc $file_varhere_uncorr

             # Het bestand met de hoogte boven zeeniveau
             #    moet slechts eenmalig opgehaald te worden
             # In fact, it is geopotential and hence needs to be divided
             #    by g according to Eduardo Penabad from CDS
             if [ "$varhere" == "orography" ]
             then
                cdo divc,9.81 $file_varhere_uncorr file_corr_values.nc
                cdo seltimestep,1 file_corr_values.nc $fileSurfElev
                rm file_corr_values.nc
                continue
             # For some other variables, the unit is changed, so values must be adapted
             elif [ "$varhere" == "total_precipitation" ]
             then
                cdo mulc,1000.0 $file_varhere_uncorr $file_varhere
             elif [ "$varhere" == "surface_solar_radiation_downwards" ]
             then
                cdo divc,$nsecday $file_varhere_uncorr $file_varhere
                elif [ "$varhere" == "surface_thermal_radiation_downwards" ]
             then
                cdo divc,$nsecday $file_varhere_uncorr $file_varhere
             elif [ "$varhere" == "mean_sea_level_pressure" ]
             then
                PSeaL_pres='y'
                cdo divc,1000.0 $file_varhere_uncorr $file_varhere
             elif [ "$varhere" == "2m_temperature" ]
             then
                Tair_pres='y'
                cdo div $fileSurfElev $file_varhere_uncorr fileElevDivByTemp.nc
                cdo divc,-29.263 fileElevDivByTemp.nc fileFactExpPress.nc
                ncatted -O -a long_name,$parname,o,c,'exponential_factor_for_calculation_surface_pressure_from_sea_level_pressure' fileFactExpPress.nc
                ncatted -O -a unit,$parname,o,c,'m/K' fileFactExpPress.nc
                ncrename -v $parname,FactExpPress fileFactExpPress.nc
                cdo -O merge $file_varhere_uncorr fileFactExpPress.nc $file_varhere
             elif [ "$varhere" == "2m_dewpoint_temperature" ]
             then
                Tdew_pres='y'
                cdo subc,273.15 $file_varhere_uncorr $file_varhere
             elif [ "$varhere" == "maximum_2m_temperature_in_the_last_24_hours" ]
             then
                cdo subc,273.15 $file_varhere_uncorr $file_varhere
             elif [ "$varhere" == "minimum_2m_temperature_in_the_last_24_hours" ]
             then
                cdo subc,273.15 $file_varhere_uncorr $file_varhere
             elif [ "$varhere" == "10m_u_component_of_wind" ]
             then
                Uwind_pres='y'
                cp $file_varhere_uncorr $file_varhere
             elif [ "$varhere" == "10m_v_component_of_wind" ]
             then
                Vwind_pres='y'
                cp $file_varhere_uncorr $file_varhere
             else 
                cp $file_varhere_uncorr $file_varhere
             fi

             # String is made with names of all files with 6-hourly data
             if [ "$typehere" == "6" ]
                then
                all_files_6=$all_files_6$file_varhere' '
                nr_files_6=$((nr_files_6+1))
             # String is made with names of all files with 24-hourly data
             elif [ "$typehere" == "24" ]
             then
                all_files_24=$all_files_24$file_varhere' '
                nr_files_24=$((nr_files_24+1))
             fi

             rm $file_varhere_uncorr

          done   # End of the loop over the variables
          
          rm download.grib
          rm rawfile.nc
                
      done   # End of the loop over the type of variables
      
      if [ "$PSeaL_pres" == "y" -a "$Tair_pres" == "y" ]
      then 
         cdo -O merge file_PSeaLevel.nc file_Tair.nc file_compPSurf.nc
         # All of the following equations have been checked and found ok (01-11-18)     
         # Compute surface pressure with the equation from
         #    https://www.sandhurstweather.org.uk/barometric.pdf
         cdo expr,'PSurf=PSeaLevel*exp(FactExpPress);' file_compPSurf.nc file_PSurf.nc
         ncatted -O -a long_name,PSurf,o,c,'surface_pressure' file_PSurf.nc
         ncatted -O -a unit,PSurf,o,c,'kPa' file_PSurf.nc
         all_files_6=$all_files_6'file_PSurf.nc '
         nr_files_6=$((nr_files_6+1))
         PSurf_pres='y'
      fi
      
      if [ $Tdew_pres == 'y' ]
      then 
         # Vapor pressure is computed with the equation of Tetens,
         #    copied from https://en.wikipedia.org/wiki/Vapour_pressure_of_water
         # Finally, the humidity mixing ratio is computed
         cdo expr,'Vappr=0.61078*exp(17.27*Tdew/(Tdew+237.3));' file_Tdew.nc file_Vappr.nc      
         ncatted -O -a long_name,Vappr,o,c,'2_m_vapor_pressure' file_Vappr.nc
         ncatted -O -a unit,Vappr,o,c,'kPa' file_Vappr.nc
         all_files_6=$all_files_6'file_Vappr.nc '
         nr_files_6=$((nr_files_6+1))
      fi
      
      if [ $Uwind_pres == 'y' -a $Vwind_pres == 'y' ]
      then
         cdo -O merge file_Uwind.nc file_Vwind.nc file_twocompWind.nc
         cdo expr,'Wind=sqrt(sqr(Uwind)+sqr(Vwind));' file_twocompWind.nc file_Wind.nc
         ncatted -O -a long_name,Wind,o,c,'10_m_wind_speed' file_Wind.nc
         ncatted -O -a unit,Wind,o,c,'m/s' file_Wind.nc
         all_files_6=$all_files_6'file_Wind.nc '
         nr_files_6=$((nr_files_6+1))
      fi
      
      if [ $Tdew_pres == 'y' -a $PSurf_pres == 'y' ]
      then
         cdo -O merge file_Vappr.nc file_PSurf.nc file_compQair.nc
         # Calculation of the water vapour mixing ratio, 
         #    i.e. weight of vapour divided by weight of dry air
         cdo expr,'Qair=0.622*Vappr/(PSurf-Vappr);' file_compQair.nc file_Qair.nc
         ncatted -O -a long_name,Qair,o,c,'2_m_water_vapor_mixing_ratio' file_Qair.nc
         ncatted -O -a unit,Qair,o,c,'kg/kg' file_Qair.nc
         all_files_6=$all_files_6'file_Qair.nc '
         nr_files_6=$((nr_files_6+1))
      fi

      # Daily averages are calculated for all variables with 6-hourly data      
      if [ "$nr_files_6" -ne "0" ]
      then
         if [ "$nr_files_6" -eq "1" ]
         then
            cp $all_files_6 file_allvar6.nc
         else
            cdo -O merge $all_files_6 file_allvar6.nc
         fi
         # This type of variable is present as momentaneous values
         #    at 6, 12, 18, 24, 36 hours etc.
         # For computing daily means, the values are shifted by 3 hours,
         #    so that each daily mean is the mean of 4 values
         cdo shifttime,-3hour file_allvar6.nc file_allvar6_timesh.nc
         cdo dayavg file_allvar6_timesh.nc file_dayavg6.nc
      fi
      
      # Daily averages are calculated for all variables with 24-hourly data      
      if [ "$nr_files_24" -ne "0" ]
      then
         if [ "$nr_files_24" -eq "1" ]
         then
            cp $all_files_24 file_allvar24.nc
         else
            cdo -O merge $all_files_24 file_allvar24.nc
         fi
         # This type of variable is the sum over the past 24 hours.
         # For synchronisation with the 6-hourly values,
         #    the time axis is shifted by 12 hours
         cdo shifttime,-12hour file_allvar24.nc file_allvar24_timesh.nc
         #cdo dayavg file_allvar24_timesh.nc file_dayavg24_timebnds.nc
         #cdo delete,param=time_bnds file_dayavg24_timebnds.nc file_dayavg24.nc
         cp file_allvar24_timesh.nc file_dayavg24.nc
      fi
      
      # A file with daily averages of all variables is produced
      if [ -e file_dayavg6.nc -a  -e file_dayavg24.nc ]
      then
         cdo -O merge file_dayavg6.nc file_dayavg24.nc file_dayavg.nc
      else
         if [ -e file_dayavg6.nc ]
         then
            cp file_dayavg6.nc file_dayavg.nc
         elif [ -e file_dayavg24.nc ]
         then
            cp file_dayavg24.nc file_dayavg.nc
         fi
      fi

      # Remapping to half degree 
      # file_interpol.nc was checked and found ok on 11-27-2018                       
      cdo remapbil,$filegrid file_dayavg.nc file_interpol.nc
      
      nsam=$(cdo ntime file_dayavg.nc)
      ntime=$((nsam/lmem))
 
      # Separation into members 
      # Was checked on 29-11-2018 and found ok     
      for imem in $(seq 1 $lmem); do
      
         if [ "$imem" -lt "10" ]
         then
            mem_name='E0'$imem
         else
            mem_name='E'$imem
         fi

         # De volgorde is first / last / increment
         fsam=$(((imem-1)*ntime+1))
         lsam=$((fsam+ntime-1))
         filemem_temp=$mem_name'.nc'
         cdo seltimestep,$fsam/$lsam/1 file_interpol.nc $filemem_temp
         
         # Split file into separate files, each for a single variable
         cdo splitname $filemem_temp $mem_name'_'
         
         # for (( ivar6=0; ivar6 < $(($nvar6)); ivar6++ ))
         # do
         #    parhere=${parname6[$ivar6]}
         #    cdo splityear $mem_name$parhere'.nc' $mem_name$parhere
         # done    # End of the loop 6-hour variables 

         for (( ivar24=0; ivar24 < $(($nvar24)); ivar24++ ))
         do
         
             parhere=${parname24[$ivar24]}
             # Some of the 24-hourly variables are stored as cumulations 
             #    over entire forecast time on the CDS 
             #    and hence need to be recalculated to daily sums or daily fluxes 
             # The de-cumulation part was checked on 29-11-2018 and found ok       
             cumul='n'         
             case $parhere in
                'Tmin') cumul='n' ;;
                'Tmax') cumul='n' ;;
                'SWdown') cumul='y' ;;
                'LWdown') cumul='y' ;;
                'Precip') cumul='y' ;;
                *) exit 'No parameter assigned' ;;
             esac
             
             if [ "$cumul" == "y" ]
             then
                file_cum=$mem_name'_'$parhere'.nc'
                cdo shifttime,+1day $file_cum file_shift.nc
                cdo select,timestep=1 $file_cum file1.nc
                cdo delete,timestep=1 $file_cum file2.nc
                cdo delete,timestep=-1 file_shift.nc file3.nc
                cdo sub file2.nc file3.nc file4.nc
                cdo -O mergetime file1.nc file4.nc file5.nc
                cp file5.nc $file_cum
             fi
         
             # cdo splityear $mem_name$parhere'.nc' $mem_name$parhere

         done    # End of the loop 24-hour variables 

         # Save the result
         dirout_mem=$dirout$mem_name'/'
         mkdir -p $dirout_mem         
         cp $mem_name'_'* $dirout_mem 
         
      done   # End of the loop over the members
      
      rm *
      
      echo 'toi'   
      exit

   done   # End of the loop over the months of the year
   
done   # End of the loop over the years

  
