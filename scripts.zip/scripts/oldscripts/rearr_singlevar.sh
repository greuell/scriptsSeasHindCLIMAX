#!/bin/bash
#SBATCH -N 1                            ## Ensure that all cores are on one machine
#SBATCH --comment=5120776-01            ## Is het WUR projectnummer (5120867-01 = Euporias; 5120776-01 = IMPACT2C)
#SBATCH --time=5000                     ## Na deze (echte) tijd in minuten wordt job in ieder geval beeindigd
#SBATCH --mem=36000                     ## Is het maximale geheugen in MByte; als de computer meer nodig heeft, beeindigt hij de job
#SBATCH --ntasks=1                      ## Aantal processoren
#SBATCH --output=output_%j.txt
#SBATCH --error=error_output_%j.txt
#SBATCH --job-name=acq_forcing            
#SBATCH --qos=std                       ## Low kan eruitgegooid worden

# print date and time
date 

domain='global'
varname='surface_thermal_radiation_downwards'
fyear=1993
lyear=2006

lus_backup='/lustre/backup/WUR/ESG/greue002/'
dir_bas=$lus_backup'CLIMAX/'$domain'/forcing/ecmwf_5/1degree_noBC/data/'
dir_grib=$dir_bas'grib/'
dir_netcdf=$dir_bas'netcdf/'

case $varname in
   'surface_thermal_radiation_downwards') varnr=175;;
esac

cd $dir_bas
for inimth in $(seq 1 12); do

   inimthstr=$inimth
   if [ "$inimth" -lt "10" ]
   then
      inimthstr='0'$inimth
   fi 
   
   gribfile=$dir_grib$varname'_mth'$inimthstr'.grib'
   netcdffile=$dir_netcdf$varname'/S5_'$inimthstr'01_'$varnr'.nc'
   
   # Copy the grib to netcdf files
   #cdo -f nc copy $gribfile $netcdffile
   
   for year in $(seq $fyear $lyear); do
      netcdfmth=$dir_netcdf$varname'/S5_'$year$inimthstr'01_'$varnr'.nc'
      cdo selyear,$year $netcdffile $netcdfmth   
   done
   
   exit
   
done
