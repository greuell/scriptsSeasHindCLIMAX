#!/bin/bash

# Maak files met het klimaat

datatype="obs"       # can be either obs or hdc (hindcasts)
                     # for vartype=hydro, obs refers to the pseudo-obs
vartype="meteo"      # can be either meteo or hydro

if [ "$vartype" == "meteo" ]
then

   if [ "$datatype" == "obs" ]
   then
      declare -a varname=( 'Evappr' 'LWdown' 'Precip' 'PSurf' 'Qair' \
                           'Tair' 'SWdown' 'Tmax' 'Tmin' 'Wind' )
      source='WFDEI'
      source_vers='aug2018'
      dur=1
      lmem=0
   elif [ "$datatype" == "hdc" ]
   then
      declare -a varname=( 'Precip' )
      clim_model='ecmwf'
      clim_model_vers='5'
      dur=7
      lmem=25
   fi
   
elif [ "$vartype" == "hydro" ]
then

   if [ "$datatype" == "obs" ]
   then
      declare -a varname=( 'runoff'  'qs' 'qsb' 'dis' 'evap' )
      hyd_model='VIC'
      forcing='WFDEI'
      forc_vers='aug2018'
      dur=1
      lmem=0
   elif [ "$datatype" == "hdc" ]
   then
      declare -a varname=( 'runoff'  'qs' 'qsb' 'dis' 'evap' )
      hyd_model='VIC'
      clim_model='ecmwf'
      clim_model_vers='5'
      dur=7
      lmem=25
   fi
   
fi
   
   
nvar=${#varname[*]} 

resolution='halfdegree'
domain='SA'

if [ "$domain" == "SA" ]
then
   nreg=10
   declare -a latmax=( 999.0   1.0  12.5 -25.0 -40.5 -22.0   9.5 -19.0 -15.0  -0.5 )    
   declare -a lonmax=( 999.0 -79.0 -73.0 -69.5 -63.5 -49.5 -53.5 -51.0 -44.0 -35.0 )
   declare -a latmin=( 999.0  -7.0   5.0 -34.0 -49.0 -31.5  -4.0 -25.0 -21.0  -7.0 )
   declare -a lonmin=( 999.0 -81.0 -76.0 -72.0 -69.5 -59.0 -65.0 -55.0 -47.0 -50.0 )
   declare -a namereg=( 'South_America' 'coast_Ecuador' 'Northwest_Columbia'  
                        'North_Chile' 'Patagonia' 'Southeast_South_America' 
                        'North_Amazonia' 'rio_Paraná' 'rio_São_Francisco' 
                        'Northeast_Brazil' ) 
fi

nmth=12

biascorr='noBC'
maxlead=$((dur-1))
lus_backup='/lustre/backup/WUR/ESG/greue002/'
dir_domain=$lus_backup'CLIMAX/'$domain'/'
dirin1=$dir_domain'forcing/'$forcing'_'$forc_vers'/'$resolution'_noBC_'

if [ "$datatype" == "obs" ]
then
   dirin2='daily/data/'
elif [ "$datatype" == "hdc" ]
then
   dirin2='monthly_leadtime/'
fi
dirin=$dirin1$dirin2
dirout=$dirin1'climate/data/'
dirouttemp=$dirout'temp/'

mkdir -p $dirout
mkdir -p $dirouttemp

for (( ivar=0; ivar < $nvar; ivar++ ))
do

   varhere=${varname[$ivar]}
   echo $varhere
   
   for (( lead=0; lead <= $maxlead; lead++ ))
   do

      if [ "$datatype" == "obs" ]   
      then

         filein=$dirin$varhere'.nc'

         fileymonavg_b=$dirout$varhere'_ymonavg'
         fileymonstd_b=$dirout$varhere'_ymonstd'
         fileymoncfv_b=$dirout$varhere'_ymoncfv'

      elif [ "$datatype" == "hdc" ]
      then
      
         filemem1=$dirin$varhere'mean_monthly_'$forcing'_'$forc_vers'_'
         filemem2=$forcing'_'$forc_vers'_'$domain'_'$biascorr'_E'

         files_all_mem=''
      
         for (( mem=1; mem <= $lmem; mem++ ))
         do
      
            if [ "$mem" -lt "10" ]
            then
               str_mem='0'$mem
            else
               str_mem=$mem
            fi

            filemem3=$str_mem'_lead'$lead'.nc4'
            filemem=$filemem1$filemem2$filemem3
            
            files_all_mem=$files_all_mem$filemem' '
            
         done

         filein=$dirin$varhere'_median_of_mean_monthly_lead'$lead'.nc4' 
         
         cdo --no_warnings -O -s enspctl,50 $files_all_mem $filein
         
         fileymonavg_b=$dirout$varhere'_lead'$lead'_ymonavg'
         fileymonstd_b=$dirout$varhere'_lead'$lead'_ymonstd'
         fileymoncfv_b=$dirout$varhere'_lead'$lead'_ymoncfv'

      fi
      
      fileymonavg=$fileymonavg_b'.nc'
      fileymonstd=$fileymonstd_b'.nc'
      fileymoncfv=$fileymoncfv_b'.nc'

      cdo -s ymonavg $filein $fileymonavg
      # Het volgende statement levert een foutief resultaat op
      # cdo ymonstd $filein $fileymonstd

      # Derhalve reken ik via een omweg
      filemonavg=$dirouttemp'monavg.nc'
      cdo -s monavg $filein $filemonavg
 
      files_all_std=''
           
      for (( mth=1; mth <= $nmth; mth++ ))
      do

         mthstr=$mth
         if [ "$mth" -lt "10" ]
         then
            mthstr='0'$mth
         fi 
         
         date='2000-'$mthstr'-01'
   
         filemth=$dirouttemp'selmonth'$mth'.nc'
         cdo -s selmonth,$mth $filemonavg $filemth
         filemthstd=$dirouttemp'stdmonth'$mth'.nc'
         cdo -s timstd $filemth $dirouttemp'aap.nc'
         cdo --no_warnings -s setdate,$date $dirouttemp'aap.nc' $filemthstd
         files_all_std=$files_all_std$filemthstd' '
         
      done
      
      cdo -O -s mergetime $files_all_std $fileymonstd 
      cdo -s div $fileymonstd $fileymonavg $fileymoncfv
      
      # Compute regional means      
      for (( ireg=0; ireg < $nreg; ireg++ ))
      do

         reghere=${namereg[$ireg]}

         if [ "$ireg" != 0 ]
         then
            coor1=${lonmin[$ireg]}
            coor2=${lonmax[$ireg]}
            coor3=${latmin[$ireg]}
            coor4=${latmax[$ireg]}
            fileymonavgreg=$dirouttemp'ymonavgreg'$ireg'.nc'
            cdo -s sellonlatbox,$coor1,$coor2,$coor3,$coor4 $fileymonavg $fileymonavgreg
            fileymonstdreg=$dirouttemp'ymonstdreg'$ireg'.nc'
            cdo -s sellonlatbox,$coor1,$coor2,$coor3,$coor4 $fileymonstd $fileymonstdreg
         else
            fileymonavgreg=$fileymonavg
            fileymonstdreg=$fileymonstd
         fi
         
         fileymoncfvreg=$dirouttemp'ymoncfvreg'$ireg'.nc'
         cdo -s div $fileymonstdreg $fileymonavgreg $fileymoncfvreg
         
         fileymonavgregmean=$fileymonavg_b'_'$reghere'_mean.nc'
         cdo -s fldmean $fileymonavgreg $fileymonavgregmean
         fileymonstdregmean=$fileymonstd_b'_'$reghere'_mean.nc'
         cdo -s fldmean $fileymonstdreg $fileymonstdregmean
         fileymoncfvregmean=$fileymoncfv_b'_'$reghere'_mean.nc'
         cdo -s fldmean $fileymoncfvreg $fileymoncfvregmean
      done
      
      rm $dirouttemp/*
      
   done    # End of the loop over the lead times
   
done    # End of the loop over the variables
