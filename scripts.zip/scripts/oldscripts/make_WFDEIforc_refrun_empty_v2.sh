#!/bin/bash
#SBATCH -N 1                            ## Ensure that all cores are on one machine
#SBATCH --comment=5120776-01            ## Is het WUR projectnummer (5120867-01 = Euporias; 5120776-01 = IMPACT2C)
#SBATCH --time=5000                     ## Na deze (echte) tijd in minuten wordt job in ieder geval beeindigd
#SBATCH --mem=4048                      ## Is het maximale geheugen in MByte; als de computer meer nodig heeft, beeindigt hij de job
#SBATCH --ntasks=1                      ## Aantal processoren
#SBATCH --output=output_%j.txt
#SBATCH --error=error_output_%j.txt
#SBATCH --job-name=acq_WFDEI            
#SBATCH --partition=ESG_Std             ## Low kan eruitgegooid worden

# All modules used will be listed in the output
module list

dir_forcdata=dir_forcdata_ph
fyear=finiyear_ph
lyear=liniyear_ph 
VICdt_hrs=VICdt_hrs_ph
westb=westb_ph
eastb=eastb_ph
southb=southb_ph
northb=northb_ph
prectype=prectype_ph

facprec=$(($VICdt_hrs*3600))

case $VICdt_hrs in
   3) freqin='3hourly';;
   6) freqin='6hourly';;
  24) freqin='daily';;
esac

nmth=12
dir_in='/lustre/backup/WUR/ESG/data/CLIMATE_DATA/WATCH/WATCH_WFDEI_GRIDDED/'$freqin'/'
dir_temp=$dir_forcdata'temporary/' 
mkdir -p $dir_temp
cd $dir_temp
      
declare -a varname=( 'Rainf' 'LWdown' 'PSurf' 'Snowf' \
                     'SWdown' 'Tair' 'Wind' 'Qair' )
nvar=${#varname[*]} 

for (( year=$fyear; year <= $lyear; year++ ))
do

   for (( ivar=0; ivar < $nvar; ivar++ ))
   do

      varhere=${varname[$ivar]}

      precfileadd=''
      if [ $varhere == 'Rainf' -o $varhere == 'Snowf' ]
      then
         precfileadd='_'$prectype
      fi
      
      echo 'year='$year '  variable='$varhere

      dir_var=$dir_in$varhere'_'$freqin'_WFDEI'$precfileadd'/'
      fileinvar=$varhere'_'$freqin'_WFDEI'$precfileadd'_'$year'.nc'
      filetot=$dir_var$fileinvar
                  
      ## Copy file to directory for temporary files
      cp $filetot .
         
      ## Select desired lat-lon box
      filevarreg=$varhere'_'$year'_reg.nc'
      cdo sellonlatbox,$westb,$eastb,$southb,$northb $fileinvar $filevarreg
         
      filevarunit=$varhere'_'$year'_unit.nc'
      filevaryear=$dir_forcdata$varhere'_'$year'.nc'
      filevarmeanyear=$dir_forcdata$varhere'_mean_'$year'.nc'
      ## Units must be changed
      case $varhere in
         'Rainf') cdo mulc,$facprec $filevarreg $filevarunit;
                  cdo setunit,'mm' $filevarunit $filevaryear;
                  #ncatted -O -a long_name,Rainf,o,c,'Rainfall over the previous three hours' $filevaryear
                  fileRainf=$filevaryear;;
         'Snowf') cdo mulc,$facprec $filevarreg $filevarunit;
                  cdo setunit,'mm' $filevarunit $filevaryear;
                  #ncatted -O -a long_name,Snowf,o,c,'Snowfall over the previous three hours' $filevaryear
                  fileSnowf=$filevaryear;;
         'Tair')  cdo subc,273.15 $filevarreg $filevarunit;
                  cdo setunit,'C' $filevarunit $filevaryear;;
         'PSurf') cdo divc,1000 $filevarreg $filevarunit;
                  cdo setunit,'kPa' $filevarunit $filevaryear;
                  filePsurf=$filevaryear;;
         'Qair')  cp $filevarreg $filevaryear;
                  fileQair=$filevaryear;;
         *)       cp $filevarreg $filevaryear;;
      esac
      
      cdo timmean $filevaryear $filevarmeanyear
      
   done      ## End of loop over variables

   # Bereken waterdampdruk uit de specifieke vochtigheid en druk    
   varhere='Evappr'
   filevaryear=$dir_forcdata$varhere'_'$year'.nc'
   cdo mulc,0.378 $fileQair 'tdata1.nc' 
   cdo addc,0.622 'tdata1.nc' 'tdata2.nc'
   cdo mul $fileQair $filePsurf 'tdata3.nc'
   cdo div 'tdata3.nc' 'tdata2.nc' $filevaryear 
   ncrename -v Qair,$varhere $filevaryear
   ncatted -O -a long_name,$varhere,o,c,'Two meter water vapour pressure at time stamp' $filevaryear
   ncatted -O -a title,$varhere,o,c,$varhere $filevaryear
   ncatted -O -a units,$varhere,o,c,'kPa' $filevaryear
   filevarmeanyear=$dir_forcdata$varhere'_mean_'$year'.nc'
   cdo timmean $filevaryear $filevarmeanyear
   
   # Neerslag is som van regen en sneeuw
   varhere='Precip'
   filevaryear=$dir_forcdata$varhere'_'$year'.nc'
   cdo add $fileRainf $fileSnowf $filevaryear
   ncrename -v Rainf,$varhere $filevaryear
   ncatted -O -a long_name,$varhere,o,c,'Precipitation over the previous three hours' $filevaryear
   ncatted -O -a title,$varhere,o,c,$varhere $filevaryear
   filevarmeanyear=$dir_forcdata$varhere'_mean_'$year'.nc'
   cdo timmean $filevaryear $filevarmeanyear
       
done         ## End of loops over years 

rm -rf $dir_temp
         
