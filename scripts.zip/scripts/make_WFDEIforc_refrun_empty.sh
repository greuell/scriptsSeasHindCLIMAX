#!/bin/bash
#SBATCH -N 1                            ## Ensure that all cores are on one machine
#SBATCH --comment=5120776-01            ## Is het WUR projectnummer (5120867-01 = Euporias; 5120776-01 = IMPACT2C)
#SBATCH --time=5000                     ## Na deze (echte) tijd in minuten wordt job in ieder geval beeindigd
#SBATCH --mem=4048                      ## Is het maximale geheugen in MByte; als de computer meer nodig heeft, beeindigt hij de job
#SBATCH --ntasks=1                      ## Aantal processoren
#SBATCH --output=output_%j.txt
#SBATCH --error=error_output_%j.txt
#SBATCH --job-name=acq_WFDEI            
#SBATCH --qos=std                       ## Low kan eruitgegooid worden

# All modules used will be listed in the output
module list

dir_forcdata=dir_forcdata_ph
fyear=finiyear_ph
lyear=liniyear_ph 
dtWFDEI=dtWFDEI_ph
westb=westb_ph
eastb=eastb_ph
southb=southb_ph
northb=northb_ph
prectype=prectype_ph

facprec=$(($dtWFDEI*3600))

case $dtWFDEI in
   3) freqin='3hourly';;
   6) freqin='6hourly';;
  24) freqin='daily';;
esac

nmth=12
dir_in='/lustre/backup/WUR/ESG/data/CLIMATE_DATA/WATCH/WATCH_WFDEI_GRIDDED/'$freqin'/'

# Create a directory for temporary files
dir_temp=$dir_forcdata'temporary/' 
mkdir -p $dir_temp
cd $dir_temp
      
declare -a varname=( 'Rainf' 'LWdown' 'PSurf' 'Snowf' \
                     'SWdown' 'Tair' 'Wind' 'Qair' )
nvar=${#varname[*]} 

for (( year=$fyear; year <= $lyear; year++ ))
do

   for (( ivar=0; ivar < $nvar; ivar++ ))
   do

      varhere=${varname[$ivar]}

      precfileadd=''
      if [ $varhere == 'Rainf' -o $varhere == 'Snowf' ]
      then
         precfileadd='_'$prectype
      fi
      
      echo 'year='$year '  variable='$varhere

      # Name of the input file
      dir_var=$dir_in$varhere'_'$freqin'_WFDEI'$precfileadd'/'
      fileinvar=$varhere'_'$freqin'_WFDEI'$precfileadd'_'$year'.nc'
      filetot=$dir_var$fileinvar
                  
      # Copy file to directory for temporary files
      cp $filetot .
         
      # Select desired lat-lon box
      filevarreg=$varhere'_'$year'_reg.nc'
      cdo sellonlatbox,$westb,$eastb,$southb,$northb $fileinvar $filevarreg
         
      # Units must be changed
      # Create a file with all values for a variable in a specific year
      #    and a file with the mean of a variable in a specific year
      filevarunit=$varhere'_'$year'_unit.nc'
      filevaryear=$dir_forcdata$varhere'_'$year'.nc'
      filevarmeanyear=$dir_forcdata$varhere'_'$year'_mean.nc'
      case $varhere in
         'Rainf') cdo mulc,$facprec $filevarreg $filevarunit;
                  cdo setunit,'mm' $filevarunit $filevaryear;
                  if [ "$dtWFDEI" -eq "3" ]
                  then
                     ncatted -O -a long_name,$varhere,o,c,'Rainfall sum during the previous three hours' $filevaryear
                  elif [ "$dtWFDEI" -eq "24" ]
                  then
                     ncatted -O -a long_name,$varhere,o,c,'Daily rainfall sum' $filevaryear
                  fi
                  fileRainf=$filevaryear;;
         'LWdown') cp $filevarreg $filevaryear;
                  if [ "$dtWFDEI" -eq "3" ]
                  then
                     ncatted -O -a long_name,$varhere,o,c,'Mean surface long-wave incoming radiation during the previous three hours' $filevaryear
                  elif [ "$dtWFDEI" -eq "24" ]
                  then
                     ncatted -O -a long_name,$varhere,o,c,'Daily mean surface long-wave incoming radiation' $filevaryear
                  fi;;
         'SWdown') cp $filevarreg $filevaryear;
                  if [ "$dtWFDEI" -eq "3" ]
                  then
                     ncatted -O -a long_name,$varhere,o,c,'Mean surface short-wave incoming radiation during the previous three hours' $filevaryear
                  elif [ "$dtWFDEI" -eq "24" ]
                  then
                     ncatted -O -a long_name,$varhere,o,c,'Daily mean surface short-wave incoming radiation' $filevaryear
                  fi;;
         'Snowf') cdo mulc,$facprec $filevarreg $filevarunit;
                  cdo setunit,'mm' $filevarunit $filevaryear;
                  if [ "$dtWFDEI" -eq "3" ]
                  then
                     ncatted -O -a long_name,$varhere,o,c,'Snowfall sum during the previous three hours' $filevaryear
                  elif [ "$dtWFDEI" -eq "24" ]
                  then
                     ncatted -O -a long_name,$varhere,o,c,'Daily snowfall sum' $filevaryear
                  fi
                  fileSnowf=$filevaryear;;
         'Tair')  cdo subc,273.15 $filevarreg $filevarunit;
                  cdo setunit,'C' $filevarunit $filevaryear;
                  if [ "$dtWFDEI" -eq "3" ]
                  then
                     ncatted -O -a long_name,$varhere,o,c,'Momentaneous 2m air temperature' $filevaryear
                  elif [ "$dtWFDEI" -eq "24" ]
                  then
                     ncatted -O -a long_name,$varhere,o,c,'Daily mean 2m air temperature based on 3-hourly values from 0-21h' $filevaryear
                  fi;;
         'PSurf') cdo divc,1000 $filevarreg $filevarunit;
                  cdo setunit,'kPa' $filevarunit $filevaryear;
                  if [ "$dtWFDEI" -eq "3" ]
                  then
                     ncatted -O -a long_name,$varhere,o,c,'Momentaneous surface pressure' $filevaryear
                  elif [ "$dtWFDEI" -eq "24" ]
                  then
                     ncatted -O -a long_name,$varhere,o,c,'Daily mean surface pressure based on 3-hourly values from 0-21h' $filevaryear
                  fi;
                  filePsurf=$filevaryear;;
         'Qair')  cp $filevarreg $filevaryear;
                  if [ "$dtWFDEI" -eq "3" ]
                  then
                     ncatted -O -a long_name,$varhere,o,c,'Momentaneous 2m specific humidity' $filevaryear
                  elif [ "$dtWFDEI" -eq "24" ]
                  then
                     ncatted -O -a long_name,$varhere,o,c,'Daily mean 2m specific humidity based on 3-hourly values from 0-21h' $filevaryear
                  fi;
                  fileQair=$filevaryear;;
         'Wind')  cp $filevarreg $filevaryear;
                  if [ "$dtWFDEI" -eq "3" ]
                  then
                     ncatted -O -a long_name,$varhere,o,c,'Momentaneous 10m wind speed' $filevaryear
                  elif [ "$dtWFDEI" -eq "24" ]
                  then
                     ncatted -O -a long_name,$varhere,o,c,'Daily mean 10m wind speed based on 3-hourly values from 0-21h' $filevaryear
                  fi;
                  fileQair=$filevaryear;;
         *)       echo $varhere 'is missing';;
      esac
      
      cdo timmean $filevaryear $filevarmeanyear
      
   done      ## End of loop over variables

   # Compute water vapour pressure from specific humidity and pressure  
   varhere='Evappr'
   echo 'year='$year '  variable='$varhere
   filevaryear=$dir_forcdata$varhere'_'$year'.nc'
   cdo mulc,0.378 $fileQair 'tdata1.nc' 
   cdo addc,0.622 'tdata1.nc' 'tdata2.nc'
   cdo mul $fileQair $filePsurf 'tdata3.nc'
   cdo div 'tdata3.nc' 'tdata2.nc' $filevaryear 
   ncrename -v Qair,$varhere $filevaryear
   if [ "$dtWFDEI" -eq "3" ]
   then
      ncatted -O -a long_name,$varhere,o,c,'Momentaneous 2m water vapour pressure' $filevaryear
   elif [ "$dtWFDEI" -eq "24" ]
   then
      ncatted -O -a long_name,$varhere,o,c,'Daily mean 2m water vapour pressure based on 3-hourly values from 0-21h' $filevaryear
   fi
   ncatted -O -a title,$varhere,o,c,$varhere $filevaryear
   ncatted -O -a units,$varhere,o,c,'kPa' $filevaryear
   filevarmeanyear=$dir_forcdata$varhere'_'$year'_mean.nc'
   cdo timmean $filevaryear $filevarmeanyear
   
   # Compute precipitation as the sum of rain and snow
   varhere='Precip'
   echo 'year='$year '  variable='$varhere
   filevaryear=$dir_forcdata$varhere'_'$year'.nc'
   cdo add $fileRainf $fileSnowf $filevaryear
   ncrename -v Rainf,$varhere $filevaryear
   if [ "$dtWFDEI" -eq "3" ]
   then
      ncatted -O -a long_name,$varhere,o,c,'Precipitation sum during the previous three hours' $filevaryear
   elif [ "$dtWFDEI" -eq "24" ]
   then
      ncatted -O -a long_name,$varhere,o,c,'Daily precipitation sum' $filevaryear
   fi
   ncatted -O -a title,$varhere,o,c,$varhere $filevaryear
   filevarmeanyear=$dir_forcdata$varhere'_'$year'_mean.nc'
   cdo timmean $filevaryear $filevarmeanyear
   
   # Daily minimum- and maximum temperature are calculated
   if [ "$freqin" == "daily" ]
   then 

      varhere='Tair_3hourly'
      echo 'year='$year '  variable='$varhere
      
      dir_in_3h='/lustre/backup/WUR/ESG/data/CLIMATE_DATA/WATCH/WATCH_WFDEI_GRIDDED/3hourly/'
      dir_Tair=$dir_in_3h$varhere'_WFDEI/'
      fileinTair=$varhere'_WFDEI_'$year'.nc'
      filetot=$dir_Tair$fileinTair

      # Copy file to directory for temporary files
      cp $filetot .
         
      # Select desired lat-lon box
      filevarreg=$varhere'_'$year'_reg.nc'
      filevarunit=$varhere'_'$year'_unit.nc'
      cdo sellonlatbox,$westb,$eastb,$southb,$northb $fileinTair $filevarreg
      cdo subc,273.15 $filevarreg $filevarunit;
      ncatted -O -a units,'Tair',o,c,'C' $filevarunit

      # Determine the daily minimum temperature 
      fileTminyear=$dir_forcdata'Tmin_'$year'.nc'
      fileTminmeanyear=$dir_forcdata'Tmin_'$year'_mean.nc'
      cdo daymin $filevarunit Tmin_$year.nc
      ncrename -v Tair,Tmin Tmin_$year.nc
      ncatted -O -a long_name,'Tmin',o,c,'Daily minimum temperature' Tmin_$year.nc
      ncatted -O -a title,'Tmin',o,c,'Tmin' Tmin_$year.nc
      cp Tmin_$year.nc $fileTminyear
      cdo timmean $fileTminyear $fileTminmeanyear

      # Determine the daily maximum temperature 
      fileTmaxyear=$dir_forcdata'Tmax_'$year'.nc'
      fileTmaxmeanyear=$dir_forcdata'Tmax_'$year'_mean.nc'
      cdo daymax $filevarunit $fileTmaxyear
      ncrename -v Tair,Tmax $fileTmaxyear
      ncatted -O -a long_name,'Tmax',o,c,'Daily maximum temperature' $fileTmaxyear
      ncatted -O -a title,'Tmax',o,c,'Tmax' $fileTmaxyear
      cdo timmean $fileTmaxyear $fileTmaxmeanyear
      
   fi
   
   comm1=$dir_forcdata'*'$year'.nc'
   ls $comm1
   
   # Split files in month files (needed for the bias correction)
   files_split=$(ls $comm1)
   echo $files_split  
   
   for f in $files_split
   do
      outf=$(echo $f | cut -f 1 -d '.')
      echo $f   $outf   
      cdo splitmon $f $outf
   done

done         ## End of loops over years 

rm -rf $dir_temp
         
