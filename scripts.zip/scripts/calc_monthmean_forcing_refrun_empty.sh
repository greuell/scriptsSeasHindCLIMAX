#!/bin/bash
#SBATCH -N 1                            ## Ensure that all cores are on one machine
#SBATCH --comment=5120776-01            ## Is het WUR projectnummer (5120867-01 = Euporias; 5120776-01 = IMPACT2C)
#SBATCH --time=5000                     ## Na deze (echte) tijd in minuten wordt job in ieder geval beeindigd
#SBATCH --mem=4048                      ## Is het maximale geheugen in MByte; als de computer meer nodig heeft, beeindigt hij de job
#SBATCH --ntasks=1                      ## Aantal processoren
#SBATCH --output=output_%j.txt
#SBATCH --error=output_%j.txt
#SBATCH --job-name=monthlymean            
#SBATCH --qos=std                       ## Low kan eruitgegooid worden

fyear=finiyear_ph
lyear=liniyear_ph

declare -a varname=( 'Evappr' 'LWdown' 'Precip' 'PSurf' \
                     'Qair' 'SWdown' 'Tair' 'Tmax' 'Tmin' 'Wind' )
nvar=${#varname[*]} 

tempfile=tempfile.nc

for (( ivar=0; ivar < $nvar; ivar++ ))
do

   varhere=${varname[$ivar]}
   
   echo $varhere
   
   files=''
      
   for (( year=$fyear; year <= $lyear; year++ ))
   do
      filehere=$varhere'_'$year'.nc'
      files=$files' '$filehere
   done
   
   fileallyear=$varhere'.nc'
   cdo -O -s mergetime $files $fileallyear
   # The following file is used by StatModelPrec.R
   filemonthmean=$varhere'_monthmean.nc'
   cdo -s monmean $fileallyear $filemonthmean
   
done

