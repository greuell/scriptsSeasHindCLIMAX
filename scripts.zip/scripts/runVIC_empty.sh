#!/bin/bash
#SBATCH -N 1                            ## Ensure that all cores are on one machine
#SBATCH --comment=5160957624            ## Is het WUR projectnummer (5160957624 = CLIMAX)
#SBATCH --time=600                      ## Na deze (echte) tijd in minuten wordt job in ieder geval beeindigd
#SBATCH --mem=12144                     ## Is het maximale geheugen in MByte; als de computer meer nodig heeft, beeindigt hij de job
#SBATCH --ntasks=n_tasks_ph             ## Aantal processoren
#SBATCH --output=output_%j.txt
#SBATCH --error=output_%j.txt
#SBATCH --job-name=seasonHC            
#SBATCH --qos=std                       ## Low kan eruitgegooid worden

# print date and time
date                                                                                                   

# Give the name of the global parameter file for the actual case
gpfhere=gpfhere_ph 

echo 'Run VIC'
# change to the directory containing the executable
cd /home/WUR/greue002/VIC/VICmodel/vic/drivers/image
# run VIC
./vic_image.exe -g $gpfhere

# de volgende tekst mag niet in de output file voorkomen
# slurmstepd: error: get_exit_code task 0 died by signal

# print date and time
date


