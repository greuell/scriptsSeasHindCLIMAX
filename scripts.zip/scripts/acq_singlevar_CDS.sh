#!/bin/bash
#SBATCH -N 1                            ## Ensure that all cores are on one machine
#SBATCH --comment=5160957624            ## Is het WUR projectnummer (5160957624 = CLIMAX)
#SBATCH --time=5000                    ## Na deze (echte) tijd in minuten wordt job in ieder geval beeindigd
#SBATCH --mem=36000                     ## Is het maximale geheugen in MByte; als de computer meer nodig heeft, beeindigt hij de job
#SBATCH --ntasks=1                      ## Aantal processoren
#SBATCH --output=output_%j.txt
#SBATCH --error=output_%j.txt
#SBATCH --job-name=acq_forcing            
#SBATCH --qos=std                       ## Low kan eruitgegooid worden

# This script is for downloading SEAS5 data from the Climate Data Store (CDS)
# SEAS5 has completely been downloaded for the variables in the list
#    below (varname) for the period 1981-2016.
# The script can perform two tasks, namely
# 1) download data from the CDS and
# 2) split the downloaded data into separate files for different years,
#    which is required for VIC
# Normally both tasks need to be performed
#    but the script provides the option to only split the data

# print date and time
date 

domain='global'

# For downloading global data, the following variables have to be set:

   # Select a variable from the following options
   #varname='2m_temperature'                                 #done 1981-2016 
   #varname='mean_sea_level_pressure'                        #done 1981-2016 
   #varname='2m_dewpoint_temperature'                        #done 1981-2016 
   #varname='10m_u_component_of_wind'                        #done 1981-2016
   #varname='10m_v_component_of_wind'                        #done 1981-2016
   #varname='minimum_2m_temperature_in_the_last_24_hours'    #done 1981-2016 
   #varname='maximum_2m_temperature_in_the_last_24_hours'    #done 1981-2016
   #varname='surface_thermal_radiation_downwards'            #done 1981-2016
   #varname='surface_solar_radiation_downwards'              #done 1981-2016
   varname='total_precipitation'                             #done 1981-2016

   fyear=2016    # First Year.
                 # Must also manually be adapted in the form. 
   lyear=2016    # Last Year.
                 # Must also manually be adapted in the form. 
   finimth=11    # First initial month of hindcasts to be downloaded
   linimth=12    # Last initial month of hindcasts to be downloaded

   # Only split years (in the case the download succeeded but splitting not) 
   only_split='n'

   # Basis directory for storing the data
   lus_backup='/lustre/backup/WUR/ESG/greue002/'
   
   # Directory with the empty forms
   dir_empty_forms='/home/WUR/greue002/CLIMAX/scripts/forms/'
   
# End of the variables that frequently need to be adapted according
#    to the case

nlead=7       # Number of lead months

# dth is the number of hours between data points
case $varname in
   '2m_dewpoint_temperature') varnr=168; dth=6;;
   '2m_temperature') varnr=167; dth=6;;
   '10m_u_component_of_wind') varnr=165; dth=6;;
   '10m_v_component_of_wind') varnr=166; dth=6;;
   'maximum_2m_temperature_in_the_last_24_hours') varnr=51; dth=24;;
   'mean_sea_level_pressure') varnr=151; dth=6;;
   'minimum_2m_temperature_in_the_last_24_hours') varnr=52; dth=24;;
   'surface_solar_radiation_downwards') varnr=169; dth=24;;
   'surface_thermal_radiation_downwards') varnr=175; dth=24;;
   'total_precipitation') varnr=228; dth=24;;
esac

dir_bas=$lus_backup'CLIMAX/'$domain'/forcing/ecmwf_5/1degree_noBC/'
dir_forms=$dir_bas'forms/'
dir_data=$dir_bas'data/netcdf/'$varname'/'

cd $dir_forms
for inimth in $(seq $finimth $linimth); do

   inimthstr=$inimth
   if [ "$inimth" -lt "10" ]
   then
      inimthstr='0'$inimth
   fi 
   
   outfile=$dir_data'S5_'$inimthstr'01_'$varnr'_'$fyear$lyear'.nc'

   # There are different forms for 6 and for 24 hourly data.
   # The appropriate form is copied, and 
   #    the month of initialisation, the name of the output file
   #    and the variable name are entered in the form. 
   form_mth_here='form_'$varname'_mth'$inimthstr'.py'      
   if [ "$dth" -eq "6" ]
   then
      empty_form=$dir_empty_forms'form_singlevar_06_emptymth.py'
   elif [ "$dth" -eq "24" ]
   then
      empty_form=$dir_empty_forms'form_singlevar_24_emptymth.py'
   fi
   cp $empty_form $form_mth_here
   sed -i "s|inimthstr_ph|$inimthstr|g" $form_mth_here
   sed -i "s|outfile_ph|$outfile|g" $form_mth_here
   sed -i "s|varname_ph|$varname|g" $form_mth_here

   # Download the data  
   if [ "$only_split" != "y" ]
   then
      python $form_mth_here
   fi

   # Split the downloaded file into annual files   
   for year in $(seq $fyear $lyear); do
      outfileyear=$dir_data'/S5_'$year$inimthstr'01_'$varnr'.nc'
      startdate=$year'-'$inimthstr'-01T00:00:00'
      endmth=$((inimth+nlead+1))
      endyear=$year
      if [ $endmth -gt 12 ]
      then
         endmth=$((endmth-12))
         endyear=$((endyear+1))
      fi
      endmthstr=$endmth
      if [ "$endmth" -lt "10" ]
      then
         endmthstr='0'$endmth
      fi 
      enddate=$endyear'-'$endmthstr'-01T00:00:00'
      echo $outfile
      echo $year  $inimth  $startdate  $enddate
      cdo seldate,$startdate,$enddate $outfile $outfileyear   
   done

done
