     rm(list=ls())	#remove all the variables from the workspace
     
     library (metGeneratoR)

     dirin='dirin_ph'
     iniyear=iniyear_ph
     inimth=inimth_ph
     dir_data='dir_data_ph'
     southb_gpHydMod=southb_gpHydMod_ph
     northb_gpHydMod=northb_gpHydMod_ph
     westb_gpHydMod=westb_gpHydMod_ph
     eastb_gpHydMod=eastb_gpHydMod_ph
     typerun='typerun_ph'
     fmem=fmem_ph
     lmem=lmem_ph
     dur=dur_ph
     
     lengthmth <- c(31,28,31,30,31,30,31,31,30,31,30,31)

     if (typerun == "SH") {
        # So that a fourth dimension with a single element
        #    (e.g. ensemble member) is eliminated 
        metGen$settings$timeUnitsName <- "unit"
        metGen$settings$uselessDim <- T
     } else if (typerun == "SREF") {
        metGen$settings$uselessDim <- F
        finimth <- 0
        linimth <- 0
     }
         
     ## Set the latlonbox
     mgsetLonlatbox(c(westb_gpHydMod, eastb_gpHydMod, southb_gpHydMod, northb_gpHydMod))
     
     #for (year in (fyear:lyear)) {

        # For the reference simulation finimth = linimth = fmem = lmem = 0
		#for (inimth in (finimth:linimth)) {
			
	       if (inimth < 10) {
		      strinimth <- paste ("0", inimth, sep = "")
	       } else {
		      strinimth <- paste (inimth)
	       }
	  
           ## Set the period to run
           if (typerun == "SREF") {
              start_str = paste (toString(iniyear), "-1-1", sep = "")
              end_str = paste (toString(iniyear), "-12-31", sep = "")
           } else if (typerun == "SH") {
              start_str = paste (toString(iniyear), "-", inimth, "-1", sep = "")
              yearend <- iniyear
              endmth <- inimth + dur - 1 
              if (endmth > 12) {
		    	 endmth <- endmth - 12
			     yearend <- yearend + 1
			  }
			  lday <- lengthmth[endmth]
			  
			  # test schrikkeljaar
			  leapyr <- F
			  if (((yearend %% 4) == 0 & (yearend %% 100) != 0) | (yearend %% 400) == 0) leapyr <- T
			  if (leapyr & endmth == 2) lday <- lday + 1
			  
              end_str   = paste (toString(yearend), "-", endmth, "-", lday, sep = "")
           }
           mgsetPeriod(startdate = start_str, enddate = end_str)
           
		   for (imem in (fmem:lmem)) {

	          if (imem < 10) {
		         strmem <- paste ("0", imem, sep = "")
	          } else {
		         strmem <- paste (imem)
	          }
	          
              ## Set the input files                 
              ## and the output filename(s) structure and path(s)
              ## mgsetOutName("output/<VAR>/<VAR>_<SYEAR><SMONTH><SDAY>_<EYEAR><EMONTH><EDAY>.nc", message = TRUE)
              if (typerun == "SREF") {
                 mgsetInVars (list (
                    pr     = list (ncname = "Precip", filename = paste (dirin, "Precip_", iniyear, ".nc", sep = "")),
                    tasmin = list (ncname = "Tmin",   filename = paste (dirin, "Tmin_",   iniyear, ".nc", sep = "")),
                    tasmax = list (ncname = "Tmax",   filename = paste (dirin, "Tmax_",   iniyear, ".nc", sep = "")),
                    wind   = list (ncname = "Wind",   filename = paste (dirin, "Wind_",   iniyear, ".nc", sep = "")),
                    lwdown = list (ncname = "LWdown", filename = paste (dirin, "LWdown_", iniyear, ".nc", sep = "")),
                    swdown = list (ncname = "SWdown", filename = paste (dirin, "SWdown_", iniyear, ".nc", sep = "")),
                    qair   = list (ncname = "Qair",   filename = paste (dirin, "Qair_",   iniyear, ".nc", sep = "")),
                    psurf  = list (ncname = "PSurf",  filename = paste (dirin, "PSurf_",  iniyear, ".nc", sep = ""))
                 ))
              } else if (typerun == "SH") {
				 input_file <- paste (dirin, iniyear, strinimth, "/E", strmem, "/E", strmem, sep = "")
				 print (paste ("Input from ", input_file, sep = "")) 
                 mgsetInVars (list (
                    pr     = list (ncname = "Precip", filename = paste (input_file, "_Precip.nc", sep = "")),
                    tasmin = list (ncname = "Tmin",   filename = paste (input_file, "_Tmin.nc",   sep = "")),
                    tasmax = list (ncname = "Tmax",   filename = paste (input_file, "_Tmax.nc",   sep = "")),
                    wind   = list (ncname = "Wind",   filename = paste (input_file, "_Wind.nc",   sep = "")),
                    lwdown = list (ncname = "LWdown", filename = paste (input_file, "_LWdown.nc", sep = "")),
                    swdown = list (ncname = "SWdown", filename = paste (input_file, "_SWdown.nc", sep = "")),
                    qair   = list (ncname = "Qair",   filename = paste (input_file, "_Qair.nc",   sep = "")),
                    psurf  = list (ncname = "PSurf",  filename = paste (input_file, "_PSurf.nc",  sep = ""))
                 ))
              }
         
              ## Set the timesteps in hours
              mgsetInDt(24)  # 24 hourly input
              mgsetOutDt(3)  # 3 hourly output
        
              ## Set the output variables
              outvars <- c ("tas", "pr", "wind", "vp", "psurf", "swdown", "lwdown")
              mgsetOutVars (outvars)

              if (typerun == "SREF") {
                 files_out <- paste (dir_data, "<VAR>", iniyear, ".nc", sep = "")
              } else if (typerun == "SH") {
				 dirout <- paste (dir_data, "/E", strmem, "/", sep = "")
				 system (paste ("mkdir -p ", dirout, sep = ""))
				 outbase <- paste (dirout, "E", strmem, sep = "")
                 files_out <- paste (outbase, "_", "<VAR>", ".nc", sep = "")
				 print (paste ("Output to ", outbase, sep = "")) 
              }
              
              mgsetOutName (files_out, message = TRUE)

              ## Run the metGeneratoR based on the settings above
              metGenRun()
              
              if (typerun == "SH") {
				  
				 for (outvar in outvars) {
				 
				    # The forcing file must be split with regard to year
				    #    because this is required by VIC
					file_compl <- paste (dirout, "E", strmem, "_", outvar, ".nc", sep = "")
					file_year_base <- paste (dirout, "E", strmem, "_", outvar, sep = "")
					cdo_comm1 <- paste ("cdo -z zip splityear", file_compl, file_year_base, sep = " ")
				    system (cdo_comm1)
				    cdo_comm2 <- paste ("rm", file_compl, sep = " ")
				    system (cdo_comm2)
				 }
		      }

              #if (typerun == "SREF") {
				 #for (outvar in outvars) {
					#file_year <- paste (dir_3hr, outvar, "_", year, ".nc", sep = "")
					#file_mth_base <- paste (dir_3hr, outvar, "_", year, sep = "")
					#cdo_comm <- paste ("cdo splitmon", file_year, file_mth_base, sep = " ")
				    #system (cdo_comm)
				 #}
		      #}
		      
           }    ## End of the loop over the members

        #}    ## End of the loop over the months of initialisation

     #}    ## End of the loop over the years

