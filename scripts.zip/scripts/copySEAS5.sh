#!/bin/bash
#SBATCH -N 1                            ## Ensure that all cores are on one machine
#SBATCH --comment=5160957624            ## Is het WUR projectnummer (5160957624 = CLIMAX)
#SBATCH --time=5000                    ## Na deze (echte) tijd in minuten wordt job in ieder geval beeindigd
#SBATCH --mem=36000                     ## Is het maximale geheugen in MByte; als de computer meer nodig heeft, beeindigt hij de job
#SBATCH --ntasks=1                      ## Aantal processoren
#SBATCH --output=output_%j.txt
#SBATCH --error=output_%j.txt
#SBATCH --job-name=copySEAS5           
#SBATCH --qos=std                       ## Low kan eruitgegooid worden

cd /lustre/backup/WUR/ESG/greue002/CLIMAX/global/forcing/ecmwf_5/1degree_noBC/data
pwd
destdir='/archive/ESG/greue002/SEAS5/'
comm='cp -r netcdf/* '$destdir
echo $comm
$comm
