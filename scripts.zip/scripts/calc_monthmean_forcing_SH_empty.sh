#!/bin/bash
#SBATCH -N 1                            ## Ensure that all cores are on one machine
#SBATCH --comment=5160957624            ## Is het WUR projectnummer (5160957624 = CLIMAX)
#SBATCH --time=5000                     ## Na deze (echte) tijd in minuten wordt job in ieder geval beeindigd
#SBATCH --mem=4048                      ## Is het maximale geheugen in MByte; als de computer meer nodig heeft, beeindigt hij de job
#SBATCH --ntasks=1                      ## Aantal processoren
#SBATCH --output=output_%j.txt
#SBATCH --error=output_%j.txt
#SBATCH --job-name=monthlymean            
#SBATCH --qos=std                       ## Low kan eruitgegooid worden

finiyear=finiyear_ph
liniyear=liniyear_ph
finimth=finimth_ph
linimth=linimth_ph
fmem=fmem_ph
lmem=lmem_ph
forcing=forcing_ph
forc_vers=forc_vers_ph
domain=domain_ph
biascorr=biascorr_ph
HydModResolStr=HydModResolStr_ph

declare -a varname=( 'Tair' 'LWdown' 'Precip' 'PSurf' 'Vappr' \
                     'Qair' 'SWdown' 'Tmax' 'Tmin' 'Wind' )
nvar=${#varname[*]} 

dirout='../'$HydModResolStr'_'$biascorr'_monthly/'
mkdir -p $dirout
mkdir -p temp

for (( iniyear=$finiyear; iniyear <= $liniyear; iniyear++ ))
do

   for (( inimth=$finimth; inimth <= $linimth; inimth++ ))
   do

      if [ $inimth -lt 10 ]
      then
         nameinimth='0'$inimth
      else
         nameinimth=$inimth
      fi 

      for (( imem=$fmem; imem <= $lmem; imem++ ))
      do
      
         echo 'year = '$iniyear'  month = '$inimth'  member = '$imem
   
         if [ $imem -lt 10 ]
         then
            namemem='0'$imem
         else
            namemem=$imem
         fi
         
         dirin=$iniyear$nameinimth'/E'$namemem'/'
         
         files_merge=''
      
         for (( ivar=0; ivar < $nvar; ivar++ ))
         do

            varhere=${varname[$ivar]}
                
            file=$dirin'E'$namemem'_'$varhere'.nc'
            file_mm='temp/'$varhere'_monthlymeans.nc'
            cdo -s monmean $file $file_mm
            ncrename -v $varhere,$varhere'_mean' $file_mm
            files_merge=$files_merge$file_mm' '
            
         done

         file_allvarp1=$dirout'/forcing_'$forcing'_'$forc_vers'_'
         file_allvarp2=$domain'_'$biascorr'_E'$namemem'_INIT'$iniyear'_'
         file_allvarp3=$nameinimth'_stats.nc4'
         file_allvar=$file_allvarp1$file_allvarp2$file_allvarp3        
         cdo -O -s merge $files_merge $file_allvar
         
         rm temp/*

       done   # End of the loop over the members
       
   done   # End of the loop over the initial months
   
done   # End of the loop over the initial years

