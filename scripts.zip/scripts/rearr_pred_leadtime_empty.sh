#!/bin/bash
#SBATCH -N 1                            ## Ensure that all cores are on one machine
#SBATCH --comment=5160957624            ## Is het WUR projectnummer (5160957624 = CLIMAX)
#SBATCH --time=5000                     ## Na deze (echte) tijd in minuten wordt job in ieder geval beeindigd
#SBATCH --mem=36000                     ## Is het maximale geheugen in MByte; als de computer meer nodig heeft, beeindigt hij de job
#SBATCH --ntasks=1                      ## Aantal processoren
#SBATCH --output=output_%j.txt
#SBATCH --error=output_%j.txt
#SBATCH --job-name=rearr_to_leadtime            
#SBATCH --qos=std                       ## Low kan eruitgegooid worden

model=model_ph 
NWPsyst=NWPsyst_ph
domain=domain_ph
biascorr=biascorr_ph
spec_run=spec_run_ph
finiyear=finiyear_ph
liniyear=liniyear_ph
finimth=finimth_ph
linimth=linimth_ph
fmem=fmem_ph
lmem=lmem_ph
HydModResolStr=HydModResolStr_ph 
str_dur=str_dur_ph
version=version_ph

dirlustredata='/lustre/backup/WUR/ESG/data/'
dirlustregreue002='/lustre/backup/WUR/ESG/greue002/'

case $spec_run in
   'noESP') spec_run_str='';;
   *      ) spec_run_str=$spec_run'_';;
esac

# With CLIMAX new directory and file names were introduced
case $NWPsyst in
   'ecmwf_5') CLIMAXtype='y';;
   'seas15') CLIMAXtype='n';;
esac

if [ "$CLIMAXtype" == 'n' ]
then    
   case $model in
      'LPJ')    modelfile='LPJml';
                dirinbase=$dirlustredata'PROJECT_DATA/EUPORIAS/MODEL_OUTPUT/LPJml/0.50deg/'$domain'_HINDCAST_'$biascorr'_rev4.0/';
                dirin=$dirinbase'statistics/';
                begininfile='Outputwatermodels_stats_'$modelfile
                endinfile=''
                diroutbase='/lustre/backup/WUR/ESG/greue002/LPJ/netcdfout/'$NWPsyst'_'$domain/$spec_run/$biascorr/;
                dirtemp=$diroutbase'temporary/';
                dirlead=$diroutbase'leadtime/';
                declare -a varname=( 'runoff' 'dis' 'evap' 'swe' 'soilmoist' \
                                     'pet' 'precip' 'rainf' 'snowf' 'qs' 'qsb' );;
      'seas15') modelfile='';
                dirinbase=$dirlustredata'PROJECT_DATA/EUPORIAS/FORCING_DATA/System4_seasonal_15_rev4.0/0.50deg/'$domain'_'$biascorr;
                dirin=$dirinbase'_stats/';
                begininfile='forcing'
                endinfile='_stats'
                diroutbase=$dirlustregreue$NWPsyst'_'$domain/$biascorr/;
                dirtemp=$diroutbase'temporary/';
                dirlead=$diroutbase'leadtime/'; 
                declare -a varname=( 'tas' 'pr' 'rsds' 'rlds' 'huss' 'sfcWind' );;
      'VIC')    modelfile='VIC421g';
                if [ "$biascorr" == "BC" ]
                then
                   if [ "$spec_run" == "ESPall" ]
                   then
                      revision='4.1';
                   elif [ "$spec_run" == "ESPsnow" ]
                   then
                      revision='4.1';
                   elif [ "$spec_run" == "ESPsoilm" ]
                   then
                      revision='4.1';
                   elif [ "$spec_run" == "noESP" ]
                   then
                      revision='4.0';
                   elif [ "$spec_run" == "revESP" ]
                   then
                      revision='4.2';
                   fi
                elif [ "$biascorr" == "noBC" ]
                then
                   if [ "$spec_run" == "InitSHWFDEI" ]
                   then
                      revision='4.3'
                   else
                      revision='3.2'
                   fi
                fi
                dirinbase=$dirlustredata'/PROJECT_DATA/EUPORIAS/MODEL_OUTPUT/VIC/'
                dirin=$dirinbase$domain'_HINDCAST_'$spec_run_str$biascorr'_rev'$revision'/NetCDFmonthly/';
                begininfile='Outputwatermodels_stats_'$modelfile
                endinfile=''
                diroutbase=$dirlustregreue002'VIC/netcdfout/'$NWPsyst'_'$domain/$spec_run/$biascorr/;
                dirtemp=$diroutbase'temporary/';
                dirlead=$diroutbase'leadtime/';
                declare -a varname=( 'runoff' 'snowf' 'evap' 'qs' 'qsb' 'swe' 'soilmoist' \
                                     'potevap' 'precip' 'dis' );;
      *)        exit;;
   esac
   
else   # For CLIMAX
   
   case $model in
      'ecmwf_5') typemod='forcing';;
      'VIC')     typemod='hydmodel';;
   esac
   
   if [ "$typemod" == "forcing" ]
   then
      dirbase_forc=$dirlustregreue002'CLIMAX/'$domain'/forcing/'$model'/'$HydModResolStr'_'$biascorr
      dirin=$dirbase_forc'_monthly/'
      begininfile='forcing'
      dirlead=$dirbase_forc'_monthly_leadtime/'
      dirtemp=$dirlead'temporary/';
      declare -a varname=( 'Vappr' 'LWdown' 'Precip' 'PSurf' 'Tair' \
                           'Qair' 'SWdown' 'Tmax' 'Tmin' 'Wind' )
      declare -a varname=( 'Tair' 'Precip' )
   elif [ "$typemod" == "hydmodel" ]
   then
      dirbase_hydmod1=$dirlustregreue002'CLIMAX/'$domain'/'$model'/'$NWPsyst'/'
      dirbase_hydmod2=$HydModResolStr'_'$spec_run'_SH_'$biascorr'_'$version'/'
      dirbase_hydmod=$dirbase_hydmod1$dirbase_hydmod2      
      begininfile='Output'$model
      endinfile='_stats'
      dirlead=$dirbase_hydmod'monthly_leadtime/'
      dirtemp=$dirlead'temporary/';
      declare -a varname=( 'runoff' 'evap' 'dis' 'qs' 'qsb' 'prec' )
   fi
   
   spec_run_str=''
   endinfile='_stats'

fi

mkdir -p $dirtemp
mkdir -p $dirlead
rm -f $dirtemp*

nlead=7

nvar=${#varname[*]} 

for (( ivar=0; ivar < $nvar; ivar++ ))
do

   varnamehere=${varname[$ivar]}

   case $varnamehere in
      'dis')       varnamein=$varnamehere;;
      'evap')      varnamein=$varnamehere;;
      'prec')      varnamein=$varnamehere;;
      'qs')        varnamein=$varnamehere;;
      'qsb')       varnamein=$varnamehere;;
      'runoff')    varnamein=$varnamehere;;
      'soilmoist') varnamein=$varnamehere;;
      'swe')       varnamein=$varnamehere;;
      *)           varnamein=$varnamehere'_mean';;
   esac
   
   for (( imem=$fmem; imem <= $lmem; imem++ ))
   do
   
      if [ $imem -lt 10 ]
      then
         namemem='0'$imem
      else
         namemem=$imem
      fi
      
      for (( inimth=$finimth; inimth <= $linimth; inimth++ ))
      do

         if [ $inimth -lt 10 ]
         then
            nameinimth='0'$inimth
         else
            nameinimth=$inimth
         fi 

         for (( year=$finiyear; year <= $liniyear; year++ ))
         do

            echo $varnamehere 'member =' $imem 'initmonth =' $inimth 'inityear =' $year
            
            if [ "$typemod" == "forcing" ]
            then
               dirinhere=$dirin
            elif [ "$typemod" == "hydmodel" ]
            then
               dirinhere=$dirbase_hydmod'ini'$year$nameinimth'_dur'$str_dur'_E'$namemem'/'
            fi

            filemth1=$dirinhere$begininfile'_'$NWPsyst'_'$domain'_'$biascorr'_'
            filemth2=$spec_run_str'E'$namemem'_INIT'$year'_'$nameinimth$endinfile'.nc4'
            filemth=$filemth1$filemth2
            
 # Haal de juiste variabele uit de file met maandwaardes
            filevarmth=$dirtemp'temporary.nc4'
            cdo -O -s selname,$varnamein $filemth $filevarmth
            
 # Separeer de tijdstappen en plaats het 2D (lat,lon) resultaat in de filevarlead
            for (( ilead=0; ilead < $nlead; ilead++ ))
            do
               filevarlead=$dirtemp$varnamehere'_'$year'_'$nameinimth'_lead'$ilead'.nc4'
               timestep=$((ilead+1))
               cdo -O -s seltimestep,$timestep $filevarmth $filevarlead
            done
            
         done
         
      done
      
      for (( ilead=0; ilead < $nlead; ilead++ ))
      do
         filessel=$dirtemp'*_lead'$ilead'.nc4'
         filelead=$dirlead$varnamehere'mean_monthly_'$model'_'$NWPsyst'_'$domain'_'$spec_run_str$biascorr'_E'$namemem'_lead'$ilead'.nc4'
         cdo -O -s --no_history mergetime $filessel $filelead
      done
      
      rm $dirtemp/*
      
# Einde van de loop over de ensembleleden
   done
   
# Einde van de loop over de variabelen
done   
