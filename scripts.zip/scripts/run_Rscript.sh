#!/bin/bash
#SBATCH -N 1                            ## Ensure that all cores are on one machine
#SBATCH --comment=5160957624            ## Is het WUR projectnummer (5160957624 = CLIMAX)
#SBATCH --time=1500                     ## Na deze (echte) tijd in minuten wordt job in ieder geval beeindigd
#SBATCH --mem=20000                     ## Is het maximale geheugen in MByte; als de computer meer nodig heeft, beeindigt hij de job
#SBATCH --ntasks=1                      ## Aantal processoren
#SBATCH --output=output_%j.txt
#SBATCH --error=output_%j.txt
#SBATCH --job-name=Rscript            
#SBATCH --qos=std                       ## Low kan eruitgegooid worden

# Gebruik dit script a.v.: sbatch ./run_Rscript.sh ../../R/myscripts/make_verif_plots_v18.R
ScriptR=$1 
Rscript $ScriptR
