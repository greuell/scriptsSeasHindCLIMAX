#!/bin/bash
#SBATCH -N 1                            ## Ensure that all cores are on one machine
#SBATCH --comment=5160957624            ## Is het WUR projectnummer (5160957624 = CLIMAX)
#SBATCH --time=5000                     ## Na deze (echte) tijd in minuten wordt job in ieder geval beeindigd
#SBATCH --mem=36000                     ## Is het maximale geheugen in MByte; als de computer meer nodig heeft, beeindigt hij de job
#SBATCH --ntasks=1                      ## Aantal processoren
#SBATCH --output=output_%j.txt
#SBATCH --error=output_%j.txt
#SBATCH --job-name=rearr_to_leadtime            
#SBATCH --qos=std                       ## Low kan eruitgegooid worden

DirInitStates=DirInitStates_ph
finiyear=finiyear_ph
liniyear=liniyear_ph
finimth=finimth_ph
linimth=linimth_ph

cd $DirInitStates

for (( inimth=$finimth; inimth <= $linimth; inimth++ ))
do

   echo month = $inimth

   if [ $inimth -lt 10 ]
   then
      nameinimth='0'$inimth
   else
      nameinimth=$inimth
   fi 
 
   # Collect the initial files for all years  
   FilesIn=''
   for (( year=$finiyear; year <= $liniyear; year++ ))
   do
      FileIn='initstat.'$year$nameinimth'01_00000.nc'
      FilesIn=$FilesIn$FileIn' '       
   done

   # Compute the average initial state 
   FileTemp='tempfile.nc'  
   nces $FilesIn -O $FileTemp
   
   # According to VIC the variables dz_node is wrong
   #    though the reason is not clear.
   # As a work-around dz_node is removed from the average file
   #    and then add dz_node from the initial file of the last year 
   File_dznode='dznodefile.nc'
   File_dznode_rm='temp_without_dznode.nc'
   FileOut='mean_initstats_'$nameinimth'_'$finiyear'-'$liniyear'.nc'
   
   # make file with dz_node only
   ncks -v dz_node,node_depth $FileIn $File_dznode
   # remove dz_node from mean file
   ncks -x -v dz_node,node_depth $FileTemp $File_dznode_rm
   # add dz_node to mean file
   ncks -A -v dz_node,node_depth $File_dznode $File_dznode_rm
   cp $File_dznode_rm $FileOut
   
   rm $FileTemp
   rm $File_dznode
   rm $File_dznode_rm
   
done
   


