import cdsapi

c = cdsapi.Client()

c.retrieve(
    'seasonal-original-single-levels',
    {
        'originating_centre':'ecmwf',
        'system':'5',
        'format':'grib',
        'variable': '2m_temperature',   
                'area': [ '-59.0', '-84.5', '15.5', '-31.5' ], # swlat swlon nelat nelon
                'year':'1981',
        'month':'01',
        'day':'01',
        'leadtime_hour':[
            '24']
    },
    './testCDSdownload.grib')
