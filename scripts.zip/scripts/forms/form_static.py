import cdsapi

c = cdsapi.Client()

c.retrieve(
    'seasonal-original-single-levels',
    {
        'originating_centre':'ecmwf',
        'system':'5',
        'format':'netcdf',
        'variable':'orography',   
		'year':'1993',
        'month':'01',
        'day':'01',
        'leadtime_hour':[ '0' ]
   },
    '../data/netcdf/static/orography.nc')
