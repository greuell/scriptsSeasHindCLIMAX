rm(list=ls())	#remove all the variables from the workspace

# On 27-03-2019 I checked this routine
# If cross_val = F and remove_neg = F,
#    the binned distribution of the corrected forecasts
#    exactly coincides with binned distribution of the observations.
# This provides confidence in the routine.
# If cross_val = T and remove_neg = F,
#   differences between the two mentioned distributions are small
#   but negligible.
# If remove_neg = T, differences are still negligible,
#    with both settings of cross_val 
library (ncdf4)

# VIC gebruikt de volgende inputvariabelen
#    d.w.z. Tmin en Tmax moeten nog in Tatm per 3 uur omgezet worden
variables <- c("Precip", "Tmin", "Tmax", "PSurf", "SWdown", "LWdown",
               "Qair", "Wind")
variables <- "Precip"
domain <- "SA"
forcing <- "ecmwf"
forc_vers <- 5
str_spat_res <- "halfdegree"
fyear <- 1993
lyear <- 1998
finimth <- 1
linimth <- 12
flead <- 2
llead <- 6
nmem <- 5

# if graph_check = T every 100'th bias correction will be graphically
#    checked
graph_check <- F
nbin = 100
# if cross_val = T each year will be separately corrected,
#    using the data for all of the other years
cross_val <- T
# remove_neg = T: for variables that cannot physically become negative
#    (e.g. precipitation), negative values after bias correction
#     are set equal to zero
remove_neg <- T

maxdmth <- 31
nvar <- length (variables)
nyear <- lyear - fyear + 1
npred <- nyear * nmem * maxdmth

dir_backup <- "/lustre/backup/WUR/ESG/greue002/"
dir_bas_forec_in <- paste (dir_backup, "CLIMAX/", domain, "/forcing/", forcing,
                         "_", forc_vers, "/", str_spat_res, "_noBC_daily/",
                         sep = "")
dir_obs <- paste (dir_backup, "CLIMAX/", domain, "/forcing/WFDEI_aug2018/",
                  str_spat_res, "_noBC_daily/data/", sep = "")                                
                         
for (var in variables) {
   
   # Most variables should never be negative
   neg_poss = F
   if (var == "Tmin" | var == "Tmax") neg_poss = T

   for (inimth in (finimth:linimth)) {
	   
	  if (inimth < 10) {
		 strinimth <- paste ("0", inimth, sep = "")
	  } else {
		 strinimth <- paste (inimth)
	  }
	  
      for (leadmth in (flead:llead)) {
		  
		 tarmth <- inimth + leadmth 
		 if (tarmth > 12) tarmth <- tarmth - 12

	     if (tarmth < 10) {
		    strtarmth <- paste ("0", tarmth, sep = "")
	     } else {
		    strtarmth <- paste (tarmth)
	     }
	     
         # For each variable, initial and lead month a correction is made
	     
	     for (year in (fyear:lyear)) {
			 
			iyear <- year - fyear + 1
			print (year)
			 
			for (mem in (1:nmem)) {
				
	           if (mem < 10) {
		          strmem <- paste ("0", mem, sep = "")
	           } else {
		          strmem <- paste (mem)
	           }
	           
	           print (mem)
	     
			   dir_forec_in <- paste (dir_bas_forec_in, year, strinimth, "/E",
			                        strmem, "/", sep = "")
			   file_forec_in <- paste (dir_forec_in, "E", strmem, "_", var,
			                         strtarmth, ".nc", sep = "")
			                         
               ncforecin <- nc_open(file_forec_in)
               forecyearmem <- ncvar_get(ncforecin, varid = var)

               if (year == fyear & mem == 1 ) {
                  if (var == variables[1] & inimth == finimth & 
                      leadmth == flead ) {
                     lon <- ncvar_get(ncforecin, varid = "lon")
                     nlon <- length (lon)
                     lat <- ncvar_get(ncforecin, varid = "lat")
                     nlat <- length (lat)
                     forecall <- array (NA, dim = c(nyear, nmem, nlon, nlat, maxdmth))
                     obsall   <- array (NA, dim = c(nyear, nmem, nlon, nlat, maxdmth))
                  } else {
                     forecall[] <- NA
                     obsall[]   <- NA
                  }
               }
               
               if (mem == 1) {
                  dayhere <- ncvar_get(ncforecin, varid = "time")
                  ndayhere <- length (dayhere)
               }
                             				   
               forecall[iyear, mem, , ,1:ndayhere] <- forecyearmem
               
               nc_close(ncforecin)
               			   
			}   # Einde loop over members
			
			# Get the observations
			file_obs <- paste (dir_obs, var, "_", year, strtarmth, ".nc", sep = "")
            ncobs <- nc_open(file_obs)
			obsyear <- ncvar_get(ncobs, varid = var)
			obsall[iyear, 1, , ,1:ndayhere] <- obsyear 
			nc_close(ncobs)
	        
         }   # Einde loop over jaren 
         
         for (imem in (2:nmem)) obsall[ , imem, , ,] <- obsall[ , 1, , ,]
         
minobs = 28 * nyear * nmem      # 28 is the minimum number of days for the 12 months
epsilon = 0.00001
         
setbin = F
year_nocv <- 0

# Due to set.seed, the same random numbers are generated each time
#    the routine is run
set.seed (423)
rannumdis <- runif(npred, -0.5, 0.5)	     
set.seed (187)
rannum0   <- runif(npred,  0.0, 1.0)

iplot <- 0	     

for (ilon in (1:nlon)) {
	
print (paste (ilon, Sys.time(), sep = "   "))

for (ilat in (1:nlat)) {

   # Selection of all data for a single cell	
   obscellall <- obsall  [ , , ilon, ilat, ]
   frccellall <- forecall[ , , ilon, ilat, ]
   
   # To avoid that non-zero values occur more than once
   indab0 <- which (frccellall != 0.0)
   frccellall[indab0] <- frccellall[indab0] + epsilon * rannumdis[indab0]

   # Most variables cannot be less than 0   
   if (!neg_poss) {
	  indbel0 <- which (frccellall < 0.0)
      frccellall[indbel0] = 0.0
   }
 
   # The array with the corrected hindcasts gets the same structure as the
   #    hindcasts  
   corcellall <- frccellall
   corcellall[] <- NA
   
   # Determine the indices of the valid observations and hindcasts    
   indvalobs  <- which (!is.na (obscellall) == T, arr.ind = T)
   indvalpred <- which (!is.na (frccellall) == T)
   nobsall <- dim(indvalobs)[1]
   
   # Go to next cell if there are no valid observations and hindcasts 
   if (nobsall == 0) next
   if (length (indvalpred) == 0) next

   if (nobsall < minobs) stop ("Less observations than expected")
   
   if (cross_val) {
	  fyear_corr <- fyear
	  lyear_corr <- lyear
   } else {
	  fyear_corr <- year_nocv
	  lyear_corr <- year_nocv
   }

   for (year in (fyear_corr:lyear_corr)) {
	   
      # obscelleq and frccelleq are the observations and forecasts
      #    that are used to determine the correction
      # frccellap are the forecasts to which the correction is applied
      # frccellcr are the corrected forecasts	   
      if (cross_val) {
	     iyear <- year - fyear + 1
         obscelleq <- obscellall[-iyear, , ]		   	    
         frccelleq <- frccellall[-iyear, , ]
         frccellap <- frccellall[ iyear, , ]
         indvalcrv  <- which (!is.na (obscelleq) == T)
         obsval = obscelleq[indvalcrv]   
         frcval = frccelleq[indvalcrv]
      } else {		   	    
         obscelleq <- obscellall		   	    
         frccelleq <- frccellall
         frccellap <- frccellall
         obsval = obscelleq[indvalobs]   
         frcval = frccelleq[indvalobs]
      }
      # To get the same dimensions for these two arrays
      frccellcr <- frccellap
      
      # Select valid observations and the corresponding predictions
      if (sum (is.na (frcval)) > 0) stop ("NaN in hindcasts")
   
      # Set bin properties, once per data set
      if (!setbin) {
	     nobs0 = length(obsval)
	     # Boundaries of the bins (counts)
	     # bounnsam can be a non-integer
	     # ibts and iets are indices of that delimit the bins containing the
	     #    sorted observations and hindcasts
	     # nsambin is the number of samples per bin   
	     bounnsam <- seq(0, nobs0, length.out = nbin + 1)
	     ibts <- floor(bounnsam[1:nbin]   + 1)
	     iets <- floor(bounnsam[2:(nbin+1)])
	     nsambin <- iets - ibts + 1
	     meanobsbin <- vector ("double", nbin)
	     meanfrcbin <- vector ("double", nbin)
	     thrfrcbin  <- vector ("double", nbin+1)
	     thrfrcbin[1]      = -999.0e8
	     thrfrcbin[nbin+1] = +999.0e8
	     nsimbin   <- vector ("integer", nbin)
	     sumsimbin <- vector ("double", nbin)
	     setbin = T
      }
      
      nsimbin[] = 0
      sumsimbin[] = 0.0

      nobscell <- length(obsval)
      if (nobscell != nobs0) stop ("number of observations differs between cells")

      # Sort the observations and the predictions   
      obssort  <- sort (obsval)
      frcsort <- sort (frcval)

      # Compute bin mean values, the correction for each bin and
      #    the correction for each bin   
      for (ibin in 1:nbin) {
	     obsbin = obssort [ibts[ibin]:iets[ibin]]
	     meanobsbin[ibin] = mean(obsbin)
	     frcbin = frcsort [ibts[ibin]:iets[ibin]]
	     meanfrcbin[ibin] = mean(frcbin)
	     if (ibin != nbin) thrfrcbin[ibin+1] = 0.5 * (frcsort[iets[ibin]] + 
	                                           frcsort[iets[ibin] + 1])
      }
      diffbin = meanobsbin - meanfrcbin
      
      # Number of bins with zeros
      # morepred0 = T: more forecasts than observations equal to zero
      nbins0obs <- length (which (meanobsbin == 0))
      nbins0frc <- length (which (meanfrcbin == 0))
      morepred0 = F
   
      # If there are more bins with zeros in the hindcasts
      #    than in the observations (morepred0 = T), there is an issue,
      #    for which the solution is prepared here.
      # This is only relevant for variables that cannot be negative
      # allcumsum0bins is the cumulative number of zeros 
      #    over the bins containing zeros (in the hindcasts)
      # thrattrrandom is the same as allcumsum0bins but rescaled to {0,1]
      if (nbins0frc > nbins0obs & !neg_poss) {
	     morepred0 = T 
	     nsam0bins = nsambin[1:nbins0frc]
	     cumsumsam0bins <- cumsum (nsam0bins)
	     n0transbin = 0
	     if (nbins0frc != nbin) {
		    itrbin = nbins0frc + 1
		    n0transbin <- length (which (frcsort [ibts[itrbin]:iets[itrbin]] == 0))
	     }
	     n0tot <- sum (nsam0bins) + n0transbin  
	     allcumsum0bins <- c (cumsumsam0bins, n0tot)
	     thrattrrandom <- c(0, 1.0 * allcumsum0bins / n0tot)
      }

      # This replaces coding of the previous version,
      #    which achieved exactly the same correction
      #    (this was checked on 03-22-2019) as this version.
      # Replacement was made to make the code faster.
   
      # Copy NaN to the array with corrected values (corcellall)  
      #indnan <- which (is.na(frccellap))
      #frccellap[indnan] <- NaN 
   
      # Initialize an array of bin indices with the dimensions
      #    of the corrected forecasts
      indbinsel <- array (0, dim = dim(frccellap))  

      if (!morepred0) {
	     indval <- which (!is.na(frccellap), arr.ind = T)
      } else {
	     # if there are more zero predictions than zero observations
	     ind0 <- which (frccellap == 0, arr.ind = T)
	     n0 <- dim(ind0)[1]
	     rnvec <- rannum0[1:n0]
         indbinsel[ind0] <- .bincode (rnvec, thrattrrandom)
         frccellcr[ind0] <- frccellap[ind0] + diffbin[indbinsel[ind0]+1]
         # select elements with positive values
	     indval <- which (!is.na(frccellap) & frccellap != 0, arr.ind = T)
      }
      indbinsel[indval] <- .bincode (frccellap[indval], thrfrcbin, right = F)
      frccellcr[indval] <- frccellap[indval] + diffbin[indbinsel[indval]]
 
      # Most variables cannot be less than 0   
      if (!neg_poss & remove_neg) {
         indbel0 <- which (frccellcr < 0.0) 
         frccellcr[indbel0] = 0.0
      }
   
      if (cross_val) {
         corcellall[iyear, , ] <- frccellcr	   	    
      } else {		   	    
         corcellall <- frccellcr	   	    
      }
      
   }   # End of the loop over the years (for cross-validation)
   
      # Checks 
      #meansimbin = sumsimbin / nsimbin
      #diffmean = abs (mean (corcellall, na.rm = T) - mean (obscell, na.rm = T)) 
      #diffbinmax  = max (abs (meansimbin - meanobsbin), na.rm = T) 	
      #if (diffmean > 0.01) {
      #   print (paste (ilon, ilat, diffmean, diffbinmax, morepred0, length(indbel0), sep = "   "))
      #}

   iplot <- iplot + 1
   
   # a graphical check can be made
   if (graph_check & iplot == 100) {

	  bounnsamall <- seq(0, nobsall, length.out = nbin + 1)
	  ibtsall <- floor(bounnsamall[1:nbin]   + 1)
	  ietsall <- floor(bounnsamall[2:(nbin+1)])
	  meanobsbinall <- vector ("double", nbin)
	  meanfrcbinall <- vector ("double", nbin)
	  meancorbinall <- vector ("double", nbin)

      sortobsall <- sort (obscellall)
      sortfrcall <- sort (frccellall, index.return = T)
      sortcorall <- sort (corcellall)
      for (ibin in 1:nbin) {
	     obsbinall = sortobsall [ibtsall[ibin]:ietsall[ibin]]
	     meanobsbinall[ibin] = mean(obsbinall)
	     # In the case of February there are problems here.
	     # I assume that there is a bug in the saved indices
	     indfrcbin <- sortfrcall$ix[ibtsall[ibin]:ietsall[ibin]]
	     frcbinall <- frccellall [indfrcbin]
	     meanfrcbinall[ibin] = mean(frcbinall)
	     corbinall <- corcellall [indfrcbin]
	     meancorbinall[ibin] = mean(corbinall)
      }
      
      minall <- min (c (obscellall, frccellall, corcellall), na.rm = T)
      maxall <- max (c (obscellall, frccellall, corcellall), na.rm = T)

      plot (1, type = "n", xlab = "var", 
            ylab = "Cumulative fraction of the data", 
            xlim = c (minall, maxall), ylim = c (0, 1)) 
      lowy  <- 0.5 / nbin
      highy <- 1 - lowy     
      yplot <- seq (lowy, highy, length.out = nbin)
      lines (meanobsbinall, yplot, col = "red")
      lines (meanfrcbinall, yplot, col = "blue")
      lines (meancorbinall, yplot, col = "green")
 
      readline (prompt = "Press [enter] to continue")     
      iplot <- 0
      
   }     

}
}

stop ("plop")

			                        	  
      }   # Einde loop over lead months
      
   }   # Einde loop over inimth
   
}   # Einde loop over variabelen	  
