biasCorr <- function (obs, frcEns, neg_poss, cross_val, nBin = 100,
                      remove_neg = T, graph_check = F) {

# This function makes a bias correction with the quantile mapping method
# described in Themeßl, M. J., Gobiet, A., & Leuprecht, A. (2011). 
# Empirical‐statistical downscaling and error correction 
# of daily precipitation from regional climate models. 
# International Journal of Climatology, 31(10), 1530-1544.
						  
# obs:        double. A 2D array [nYear,nDay] with observations 
#             with dimensions nYear (number of years) and nDay (number of days);
#             missing values should be NA.
# frcEns:     double. A 3D array [nYear,nMem,nDay] with the ensemble forecasts
#             with dimensions nYear, nMem (number of members) and nDay;						  
#             missing values should be NA.
# neg_poss:   logical. TRUE if the variable can be negative 
#             (e.g. temperature in Celsius). FALSE if negative values
#             are physically impossible (e.g. precipitation).
# cross_val:  logical. TRUE if the bias-correction is performed by
#             cross-validation, i.e. the correction is made separately
#             for each year. In that case, to make a correction for a certain year,
#             the corrections are derived from the data of all years 
#             except for the year under consideration.
#             Then, the corrections are applied to the considered year.
#             FALSE if all data are taken to derive the corrections,
#             which are then applied to the same data.
# nBin:       integer. Number of bins (default: 100).
# remove_neg  logical. If TRUE values that are negative after correction
#             will be set equal to 0. If FALSE negative values
#             will not be changed. This parameter is only considered if
#             neg_poss = FALSE. Default: TRUE.
# graph_check If TRUE, a graph that checks with cumulative
#             distributions will be produced.
#             If cross_val=FALSE and remove_neg=FALSE, the red (observations)
#             abd green curve (corrected forecasts) should coincide.
#             If FALSE (is default), no graph will be produced.           

# The function returns the corrected forecasts as a 3D array with the 
# same structure as that of the raw forecasts (frcEns).

   dimObs <- dim (obs)
   nYear <- dimObs[1]
   nDay  <- dimObs[2]

   dimFrc <- dim (frcEns)
   nYearFrc <- dimFrc[1]
   nMem     <- dimFrc[2]
   nDayFrc  <- dimFrc[3]
   
   nFrc <- nYear * nMem * nDay
   # Introduce variables to avoid identical forecasts,
   #    which cause problems
   epsilon = 0.00001
   # Due to set.seed, the same random numbers are generated each time
   #    the routine is run
   set.seed (423)
   rannumdis <- runif(nFrc, -0.5, 0.5)	     
   set.seed (187)
   rannum0   <- runif(nFrc,  0.0, 1.0)
   
   if (nYear != nYearFrc | nDay != nDayFrc) { 
      stop ("number of elements in observations and forecasts are inconsistent")
   }

   # Pairs of observations and forecasts are needed,
   #    so observations are copied to have observations for each
   #    member of the forecasts   
   obsEns <- array (NA, dim = c(nYear, nMem, nDay))   
   for (iMem in (1:nMem)) obsEns[ , iMem, ] <- obs
   
   # To avoid that non-zero values occur more than once
   indab0 <- which (frcEns != 0.0)
   frcEns[indab0] <- frcEns[indab0] + epsilon * rannumdis[indab0]

   # Most variables cannot be less than 0   
   if (!neg_poss) {
	  indbel0 <- which (frcEns < 0.0)
      frcEns[indbel0] = 0.0
   }
 
   # The array with the corrected hindcasts gets the same structure as the
   #    hindcasts  
   corFrcEns <- frcEns
   corFrcEns[] <- NA
   
   # Determine the indices of the valid observations and hindcasts    
   indValObs  <- which (!is.na (obsEns) == T, arr.ind = T)
   indValFrc <- which (!is.na (frcEns) == T)
   nobsall <- dim(indValObs)[1]
   
   # Go to next cell if there are no valid observations and hindcasts 
   if (nobsall == 0) return (NULL)
   if (length (indValFrc) == 0) return (NULL)

   fYearLoop <- 1
   if (cross_val) {
	  lYearLoop <- nYear
   } else {
	  lYearLoop <- 1
   }

   for (iYear in (fYearLoop:lYearLoop)) {
	   
      # obsEnsEq and frcEnsEe are the observations and forecasts
      #    that are used to determine the correction
      # frcEnsApp are the raw forecasts to which the correction will applied
      # frcEnsCor are the corrected forecasts within a for-loop
      # obsval and frcval are all values not equal to NA	   
      if (cross_val) {
         obsEnsEq  <- obsEns[-iYear, , ]		   	    
         frcEnsEq  <- frcEns[-iYear, , ]
         frcEnsApp <- frcEns[ iYear, , ]
         indvalcrv <- which (!is.na (obsEnsEq) == T)
         obsval = obsEnsEq[indvalcrv]   
         frcval = frcEnsEq[indvalcrv]
      } else {		   	    
         obsEnsEq  <- obsEns		   	    
         frcEnsEq  <- frcEns
         frcEnsApp <- frcEns
         obsval = obsEnsEq[indValObs]   
         frcval = frcEnsEq[indValObs]
      }

	  nObsVal = length(obsval)
	  if (nBin > (nObsVal / nMem)) {
		 stop ("The number of bins exceeds the number of observations")
	  }
	  
      # Boundaries of the bins (counts)
      # bounnsam can be a non-integer
	  # ibts and iets are indices that delimit the bins containing the
	  #    sorted observations and hindcasts
	  # nsambin is the number of samples per bin   
	  bounnsam <- seq(0, nObsVal, length.out = nBin + 1)
	  ibts <- floor(bounnsam[1:nBin]   + 1)
	  iets <- floor(bounnsam[2:(nBin+1)])
	  nsambin <- iets - ibts + 1
	  meanobsbin <- vector ("double", nBin)
	  meanfrcbin <- vector ("double", nBin)
	  thrfrcbin  <- vector ("double", nBin+1)
	  thrfrcbin[1]      = -999.0e8
	  thrfrcbin[nBin+1] = +999.0e8
	  nsimbin   <- vector ("integer", nBin)
	  sumsimbin <- vector ("double", nBin)
      
      # Initialise frcEnsCor with the same dimensions as frcEnsApp
      frcEnsCor <- frcEnsApp
      
      # Select valid observations and the corresponding forecasts
      if (sum (is.na (frcval)) > 0) stop ("NaN in hindcasts")
   
      nsimbin[] = 0
      sumsimbin[] = 0.0

      # Sort the observations and the forecasts   
      obssort  <- sort (obsval)
      frcsort <- sort (frcval)

      # Compute bin mean values and the correction for each bin   
      for (ibin in 1:nBin) {
	     obsbin = obssort [ibts[ibin]:iets[ibin]]
	     meanobsbin[ibin] = mean(obsbin)
	     frcbin = frcsort [ibts[ibin]:iets[ibin]]
	     meanfrcbin[ibin] = mean(frcbin)
	     if (ibin != nBin) thrfrcbin[ibin+1] = 0.5 * (frcsort[iets[ibin]] + 
	                                           frcsort[iets[ibin] + 1])
      }
      diffbin = meanobsbin - meanfrcbin
      
      # Number of bins with zeros
      # morepred0 = T: more forecasts than observations equal to zero
      nbins0obs <- length (which (meanobsbin == 0))
      nbins0frc <- length (which (meanfrcbin == 0))
      morepred0 = F
   
      # If there are more bins with zeros in the hindcasts
      #    than in the observations (morepred0 = T), there is an issue,
      #    for which the solution is prepared here.
      # This is only relevant for variables that cannot be negative
      # allcumsum0bins is the cumulative number of zeros 
      #    over the bins containing zeros (in the hindcasts)
      # thrattrrandom is the same as allcumsum0bins but rescaled to {0,1]
      if (nbins0frc > nbins0obs & !neg_poss) {
	     morepred0 = T 
	     nsam0bins = nsambin[1:nbins0frc]
	     cumsumsam0bins <- cumsum (nsam0bins)
	     n0transbin = 0
	     if (nbins0frc != nBin) {
		    itrbin = nbins0frc + 1
		    n0transbin <- length (which (frcsort [ibts[itrbin]:iets[itrbin]] == 0))
	     }
	     n0tot <- sum (nsam0bins) + n0transbin  
	     allcumsum0bins <- c (cumsumsam0bins, n0tot)
	     thrattrrandom <- c(0, 1.0 * allcumsum0bins / n0tot)
      }

      # This replaces coding of the previous version,
      #    which achieved exactly the same correction
      #    (this was checked on 03-22-2019) as this version.
      # Replacement was made to make the code faster.
   
      # Copy NaN to the array with corrected values (corFrcEns)  
      #indnan <- which (is.na(frcEnsApp))
      #frcEnsApp[indnan] <- NaN 
   
      # Initialize an array of bin indices with the dimensions
      #    of the corrected forecasts
      indbinsel <- array (0, dim = dim(frcEnsApp))  

      if (!morepred0) {
	     indval <- which (!is.na(frcEnsApp), arr.ind = T)
      } else {
	     # if there are more zero forecasts than zero observations
	     ind0 <- which (frcEnsApp == 0, arr.ind = T)
	     n0 <- dim(ind0)[1]
	     rnvec <- rannum0[1:n0]
         indbinsel[ind0] <- .bincode (rnvec, thrattrrandom)
         frcEnsCor[ind0] <- frcEnsApp[ind0] + diffbin[indbinsel[ind0]+1]
         # select elements with positive values
	     indval <- which (!is.na(frcEnsApp) & frcEnsApp != 0, arr.ind = T)
      }
      indbinsel[indval] <- .bincode (frcEnsApp[indval], thrfrcbin, right = F)
      frcEnsCor[indval] <- frcEnsApp[indval] + diffbin[indbinsel[indval]]
 
      # Most variables cannot be less than 0   
      if (!neg_poss & remove_neg) {
         indbel0 <- which (frcEnsCor < 0.0) 
         frcEnsCor[indbel0] = 0.0
      }
   
      if (cross_val) {
         corFrcEns[iYear, , ] <- frcEnsCor	   	    
      } else {		   	    
         corFrcEns <- frcEnsCor	   	    
      }
      
   }   # End of the loop over the years (for cross-validation)

   if (graph_check) {

	  bounnsamall <- seq(0, nobsall, length.out = nBin + 1)
	  ibtsall <- floor(bounnsamall[1:nBin]   + 1)
	  ietsall <- floor(bounnsamall[2:(nBin+1)])
	  meanobsbinall <- vector ("double", nBin)
	  meanfrcbinall <- vector ("double", nBin)
	  meancorbinall <- vector ("double", nBin)

      sortobsall <- sort (obsEns)
      sortfrcall <- sort (frcEns, index.return = T)
      sortcorall <- sort (corFrcEns)
      for (ibin in 1:nBin) {
	     obsbinall = sortobsall [ibtsall[ibin]:ietsall[ibin]]
	     meanobsbinall[ibin] = mean(obsbinall)
	     # In the case of February there are problems here.
	     # I assume that there is a bug in the saved indices
	     indfrcbin <- sortfrcall$ix[ibtsall[ibin]:ietsall[ibin]]
	     frcbinall <- frcEns [indfrcbin]
	     meanfrcbinall[ibin] = mean(frcbinall)
	     corbinall <- corFrcEns [indfrcbin]
	     meancorbinall[ibin] = mean(corbinall)
      }
      
      minall <- min (c (meanobsbinall, meanfrcbinall, meancorbinall), na.rm = T)
      maxall <- max (c (meanobsbinall, meanfrcbinall, meancorbinall), na.rm = T)

      plot (1, type = "n", xlab = "var", 
            ylab = "Cumulative fraction of the data", 
            xlim = c (minall, maxall), ylim = c (0, 1)) 
      lowy  <- 0.5 / nBin
      highy <- 1 - lowy     
      yplot <- seq (lowy, highy, length.out = nBin)
      lines (meanobsbinall, yplot, col = "red")
      lines (meanfrcbinall, yplot, col = "blue")
      lines (meancorbinall, yplot, col = "green")
 
      readline (prompt = "Press [enter] to continue")     
      
   }   # End if-statement graphical check    

   return (corFrcEns)   

}
