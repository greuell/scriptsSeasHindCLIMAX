rm(list=ls())	#remove all the variables from the workspace

# On 27-03-2019 I checked this routine
# If cross_val = F and remove_neg = F,
#    the binned distribution of the corrected forecasts
#    exactly coincides with binned distribution of the observations.
# This provides confidence in the routine.
# If cross_val = T and remove_neg = F,
#   differences between the two mentioned distributions are small
#   but negligible.
# If remove_neg = T, differences are still negligible,
#    with both settings of cross_val 
library (ncdf4)
source ("biasCorr.R")

# VIC gebruikt de volgende inputvariabelen
#    d.w.z. Tmin en Tmax moeten nog in Tatm per 3 uur omgezet worden
variables <- c("Precip", "Tmin", "Tmax", "PSurf", "SWdown", "LWdown",
               "Qair", "Wind")
variables <- "Precip"
domain <- "SA"
forcing <- "ecmwf"
forc_vers <- 5
str_spat_res <- "halfdegree"
fyear <- 1981
lyear <- 2015
finimth <- 1
linimth <- 12
flead <- 2
llead <- 6
nmem <- 25

# if graph_check = T every 100'th bias correction will be graphically
#    checked
graph_check <- T
nbin = 100
# if cross_val = T each year will be separately corrected,
#    using the data for all of the other years
cross_val <- T
# remove_neg = T: for variables that cannot physically become negative
#    (e.g. precipitation), negative values after bias correction
#     are set equal to zero
remove_neg <- T

maxdmth <- 31
nvar <- length (variables)
nyear <- lyear - fyear + 1
npred <- nyear * nmem * maxdmth

dir_backup <- "/lustre/backup/WUR/ESG/greue002/"
dir_bas_forec_in <- paste (dir_backup, "CLIMAX/", domain, "/forcing/", forcing,
                         "_", forc_vers, "/", str_spat_res, "_noBC_daily/",
                         sep = "")
dir_obs <- paste (dir_backup, "CLIMAX/", domain, "/forcing/WFDEI_aug2018/",
                  str_spat_res, "_noBC_daily/data/", sep = "")                                
                         
for (var in variables) {
   
   # Most variables should never be negative
   neg_poss = F
   if (var == "Tmin" | var == "Tmax") neg_poss = T

   for (inimth in (finimth:linimth)) {
	   
	  if (inimth < 10) {
		 strinimth <- paste ("0", inimth, sep = "")
	  } else {
		 strinimth <- paste (inimth)
	  }
	  
      for (leadmth in (flead:llead)) {
		  
		 tarmth <- inimth + leadmth 
		 if (tarmth > 12) tarmth <- tarmth - 12

	     if (tarmth < 10) {
		    strtarmth <- paste ("0", tarmth, sep = "")
	     } else {
		    strtarmth <- paste (tarmth)
	     }
	     
         # For each variable, initial and lead month a correction is made
	     
	     for (year in (fyear:lyear)) {
			 
			iyear <- year - fyear + 1
			print (year)
			 
			for (mem in (1:nmem)) {
				
	           if (mem < 10) {
		          strmem <- paste ("0", mem, sep = "")
	           } else {
		          strmem <- paste (mem)
	           }
	           
	           print (mem)
	     
			   dir_forec_in <- paste (dir_bas_forec_in, year, strinimth, "/E",
			                        strmem, "/", sep = "")
			   setwd (dir_forec_in)
			   file_forec_in <- paste ("E", strmem, "_", var, ".nc", sep = "")
			   cdo_comm <- paste ("cdo splitmon ", file_forec_in, " mon", sep = "") 
			   system (cdo_comm)
               ncforecin <- nc_open (paste ("mon", strtarmth, ".nc", sep = ""))
               forecyearmem <- ncvar_get (ncforecin, varid = var)

               if (year == fyear & mem == 1 ) {
                  if (var == variables[1] & inimth == finimth & 
                      leadmth == flead ) {
                     lon <- ncvar_get(ncforecin, varid = "lon")
                     nlon <- length (lon)
                     lat <- ncvar_get(ncforecin, varid = "lat")
                     nlat <- length (lat)
                     forecall <- array (NA, dim = c(nyear, nmem, nlon, nlat, maxdmth))
                     obsall   <- array (NA, dim = c(nyear,       nlon, nlat, maxdmth))
                     obscellallens <- array (NA, dim = c(nyear, nmem, maxdmth))
                  } else {
                     forecall[] <- NA
                     obsall[]   <- NA
                  }
               }
               
               if (mem == 1) {
                  dayhere <- ncvar_get(ncforecin, varid = "time")
                  ndayhere <- length (dayhere)
               }
                             				   
               forecall[iyear, mem, , ,1:ndayhere] <- forecyearmem
               
               nc_close(ncforecin)
               system ("rm mon*")
               
			}   # Einde loop over members
			
			# Get the observations
			file_obs <- paste (dir_obs, var, "_", year, strtarmth, ".nc", sep = "")
            ncobs <- nc_open(file_obs)
			obsyear <- ncvar_get(ncobs, varid = var)
			obsall[iyear, , ,1:ndayhere] <- obsyear 
			nc_close(ncobs)
	        
         }   # Einde loop over jaren 
         
minobs = 28 * nyear * nmem      # 28 is the minimum number of days for the 12 months
epsilon = 0.00001
         
# Due to set.seed, the same random numbers are generated each time
#    the routine is run
set.seed (423)
rannumdis <- runif(npred, -0.5, 0.5)	     
set.seed (187)
rannum0   <- runif(npred,  0.0, 1.0)

iplot <- 0	     

for (ilon in (1:nlon)) {
	
print (paste (ilon, Sys.time(), sep = "   "))

for (ilat in (1:nlat)) {

   # Selection of all data for a single cell	
   obscellall <- obsall  [ ,   ilon, ilat, ]
   frccellall <- forecall[ , , ilon, ilat, ]

   retFunc <- biasCorr (obscellall, frccellall, neg_poss = F, cross_val = T, 
                        nBin = 100, graph_check = T, remove_neg = T)
             
   if (is.null (retFunc)) {
	  next
   } else {
	  corcellall <- retFunc
   }
   
      # Checks 
      #meansimbin = sumsimbin / nsimbin
      #diffmean = abs (mean (corcellall, na.rm = T) - mean (obscell, na.rm = T)) 
      #diffbinmax  = max (abs (meansimbin - meanobsbin), na.rm = T) 	
      #if (diffmean > 0.01) {
      #   print (paste (ilon, ilat, diffmean, diffbinmax, morepred0, length(indbel0), sep = "   "))
      #}

   iplot <- iplot + 1
   
   # a graphical check can be made
   if (graph_check & iplot == 1) {

	  bounnsamall <- seq(0, nobsall, length.out = nbin + 1)
	  ibtsall <- floor(bounnsamall[1:nbin]   + 1)
	  ietsall <- floor(bounnsamall[2:(nbin+1)])
	  meanobsbinall <- vector ("double", nbin)
	  meanfrcbinall <- vector ("double", nbin)
	  meancorbinall <- vector ("double", nbin)

      sortobsall <- sort (obscellallens)
      sortfrcall <- sort (frccellall, index.return = T)
      sortcorall <- sort (corcellall)
      for (ibin in 1:nbin) {
	     obsbinall = sortobsall [ibtsall[ibin]:ietsall[ibin]]
	     meanobsbinall[ibin] = mean(obsbinall)
	     # In the case of February there are problems here.
	     # I assume that there is a bug in the saved indices
	     indfrcbin <- sortfrcall$ix[ibtsall[ibin]:ietsall[ibin]]
	     frcbinall <- frccellall [indfrcbin]
	     meanfrcbinall[ibin] = mean(frcbinall)
	     corbinall <- corcellall [indfrcbin]
	     meancorbinall[ibin] = mean(corbinall)
      }
      
      minall <- min (c (meanobsbinall, meanfrcbinall, meancorbinall), na.rm = T)
      maxall <- max (c (meanobsbinall, meanfrcbinall, meancorbinall), na.rm = T)

      print (meanobsbinall)
      print (maxall)
      
      plot (1, type = "n", xlab = "var", 
            ylab = "Cumulative fraction of the data", 
            xlim = c (minall, maxall), ylim = c (0, 1)) 
      lowy  <- 0.5 / nbin
      highy <- 1 - lowy     
      yplot <- seq (lowy, highy, length.out = nbin)
      lines (meanobsbinall, yplot, col = "red")
      lines (meanfrcbinall, yplot, col = "blue")
      lines (meancorbinall, yplot, col = "green")
 
      readline (prompt = "Press [enter] to continue")     
      iplot <- 0
      
   }   # End if-statement graphical check    

}   # Loop over lat
}   # Loop over lon

stop ("plop")

			                        	  
      }   # Einde loop over lead months
      
   }   # Einde loop over inimth
   
}   # Einde loop over variabelen	  
