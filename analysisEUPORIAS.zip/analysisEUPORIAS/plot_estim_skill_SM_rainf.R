# Dit programma maakt kaartjes zoals in Figuur 12
# Er is een optie om de data ruimtelijk te middelen
#    smoothdata (T of F)
# Omdat dat weinig opleverde staat smoothdata op F(ALSE)

rm(list=ls())	#remove all the variables from the workspace

library (SpecsVerification)
library (ncdf4)
library (fields)
library (verification)
library (RColorBrewer)
library(maps)

library(devtools)
find_rtools()

#devtools::install_github("MeteoSwiss/easyVerification")
library (easyVerification)

ls (pos = "package:easyVerification")

model = "VIC"
NWPsyst = "seas15"
domain = "EU"
typerun = "BC"
varname = "runoff"
typeobs = "pseudo_obs"

smoothdata <- F

nmthyr <- 12
nlead <- 7
finimth <- 1
linimth <- nmthyr
ntpl <- 5

ncolSMRF <- 6
maxSMRF <- 75
breaksSMRF <- seq(0, maxSMRF, length.out = ncolSMRF + 1)

ncolES <- ncolSMRF
breaksES <- c(0.0, 0.17, 0.33, 0.5, 0.67, 0.83, 1.0)

ncolWUSHP <- ncolSMRF
minWUSHP <- 0.1
breaksWUSHP <- seq(minWUSHP, 1.0, length.out = ncolWUSHP + 1)

mthname <- c("Jan", "Feb", "Mar", "Apr", "May", "June",
             "July", "Aug", "Sep", "Oct", "Nov", "Dec")

dirlustre = "/lustre/backup/WUR/ESG/greue002/"
fig.dir <- paste (dirlustre, "verif_seas/figures/estim_skill/", sep = "")
system (paste ("mkdir -p ", fig.dir, sep = "")) 
dirinES <- paste (dirlustre, "EUPOR_est_skill/", sep = "")
dirinTS <- paste (dirlustre, "verif_seas/statdata/", varname, "/", model,
                  "/", sep = "")

for (inimth in (finimth:linimth)) { 
	
   print (mthname[inimth])

   strinimth <- toString(inimth)
   if (inimth < 10) strinimth <- paste ("0", inimth, sep = "")
   
   # Initialize a plot to be written to a png-file
   # width en height zijn default in pixels
   # pointsize bepaalt de grootte van letters
   png (file = paste (fig.dir, "inimth_", inimth, ".png", sep=""), 
                      width = 7500, height = 7000, pointsize =12, 
                      bg = "white")

   # Set parameters for the plot
   # oma determines size of margins
   # mar also (what is the difference with oma?)
   # cex.main: the magnification to be used for main titles 
   #           relative to the current setting of cex.
   # xpd determines clipping
   # las = 1: all axis labels horizontal
   # lheight determines space between lines of text
   # mgp determines space between axes, its labels etc. ?
   par (mfrow = c(nlead, ntpl), oma = c(5,5,5,5), 
        mar = c(5,5,10,20), cex.main = 5, cex.axis = 5, cex.lab = 2.5,
        xpd = NA, las = 1, lheight = 1.2, mgp = c(3,3,0))

   fileSMvar <- paste (dirinES, "SM_var_", strinimth, "-01.nc", sep = "")
   ncSMvar <- nc_open(fileSMvar)
   SMvar <- ncvar_get (ncSMvar, varid = "soilmoisttotal")
   
   if (inimth == finimth) {
      lat <- ncvar_get (ncSMvar, varid = "lat")
      lon <- ncvar_get (ncSMvar, varid = "lon")
      nlat <- length(lat)
      nlon <- length(lon)
   }

   dataSM <- sqrt (SMvar)
   dataSM[which (dataSM > maxSMRF, arr.ind = T)] <- maxSMRF
   titleSM <- paste ("Std of SM", mthname[inimth], "(mm)", sep = " ")
	  
   for (ilead in (1:nlead)) {
	   
	  print (ilead)
	   
	  tarmth <- inimth + ilead - 1
      if (tarmth > nmthyr) tarmth <- tarmth - nmthyr
	      
      # lab.breaks zorgt ervoor dat de labels in de kleurenbar
      #    bij de kleurenovergangen staan
      image.plot (lon, lat, dataSM, 
                  xlab = "", breaks = breaksSMRF, 
                  col = brewer.pal (ncolSMRF, "YlOrRd"),
                  smallplot = c (0.87, 0.9, 0.05, 0.9), ylab = "", 
                  lab.breaks = format (breaksSMRF, digits = 2),   
                  oldstyle = F, main = titleSM)
      map ("world", add = T)
    
      fileRFvar <- paste (dirinES, "sum_ini_", strinimth, "_lead_",
                         ilead, "_var_rainf.nc", sep = "")
      ncRFvar <- nc_open(fileRFvar)
      RFvar <- ncvar_get (ncRFvar, varid = "Rainf")
   
      dataRF <- sqrt (RFvar)
      dataRF[which (dataRF > maxSMRF, arr.ind = T)] <- maxSMRF
      titleRF <- paste ("Std of rain fall sum", mthname[inimth], 
                        "-", mthname[tarmth], "(mm)", sep = " ")
	  
      image.plot (lon, lat, dataRF, 
                  xlab = "", breaks = breaksSMRF, 
                  col = brewer.pal (ncolSMRF, "YlOrRd"),
                  smallplot = c (0.87, 0.9, 0.05, 0.9), ylab = "", 
                  lab.breaks = format (breaksSMRF, digits = 2),   
                  oldstyle = F, main = titleRF)
      map ("world", add = T)

      dataES <- exp (-RFvar / SMvar)
      # dataES <- exp (-dataRF / dataSM)

      if (smoothdata) {
		        
         # Smooth dataES
         smdist <- 2
         bs <- 3 * smdist
         nae <- 2 * bs + 1
         indmid <- bs + 1
      
         totw       <- array(0,  dim = c(nlon, nlat))
         sm_dataES  <- array(NA, dim = c(nlon, nlat))
         locw       <- array(0,  dim = c(nae , nae ))
         dataES_mar <- array(NA, dim = c(nlon + 2 * bs, nlat + 2 * bs))
         dataES_mar[(bs+1):(bs+nlon), (bs+1):(bs+nlat)] <- dataES[1:nlon, 1:nlat]
      
         for (i in (1:nae)){
		    disi <- i - indmid
            for (j in (1:nae)){
		       disj <- j - indmid
		       locw[i,j] <- exp (-0.5 * (disi^2 + disj^2) / smdist^2)
		    }
         }

         for (ilon in (1:nlon)) {
	        print (ilon)

         for (ilat in (1:nlat)) {
		  
            if (is.na (dataES[ilon,ilat])) next
         
            locdata <- dataES_mar[ilon:(ilon+2*bs), ilat:(ilat+2*bs)]
            w_locdata <- locw * locdata
            sumlocw <- sum (locw[which (!is.na(locdata), arr.ind = T)]) 

		    sm_dataES[ilon,ilat] <- sum (w_locdata, na.rm = T) / sumlocw
		    totw[ilon,ilat]      <- sumlocw
		 
	     }
	     } 
	  
      }
      
      titleES <- "Exp (-varRF / varSM)"
	  
      image.plot (lon, lat, dataES, 
                  xlab = "", breaks = breaksES, 
                  col = brewer.pal (ncolES, "YlOrRd"),
                  smallplot = c (0.87, 0.9, 0.05, 0.9), ylab = "", 
                  lab.breaks = format (breaksES, digits = 2),   
                  oldstyle = F, main = titleES)
      map ("world", add = T)

      # Plot the skill of the ESPsoilm simulations
      fileESP <- paste (dirinTS, "cc_", model, "_ESPsoilm_", 
                        typerun, "_", varname, ".txt", sep = "")
      load (file = fileESP)
      
      dataESP <- aperm (corr_coeff_all[ , , inimth, ilead])
      dataESP [which (dataESP < minWUSHP, arr.ind = T)] <- minWUSHP
      titleESP <- paste ("Corr. coeff.", model, varname, "ESPsoilm tar",
                         mthname[tarmth], "lead", (ilead - 1), sep = " ")
      
      image.plot (lon, lat, dataESP, 
                  xlab = "", breaks = breaksWUSHP, 
                  col = brewer.pal (ncolWUSHP, "YlOrRd"),
                  smallplot = c (0.87, 0.9, 0.05, 0.9), ylab = "", 
                  lab.breaks = format (breaksWUSHP, digits = 2),   
                  oldstyle = F, main = titleESP)
      map ("world", add = T)
      
      ccpatt <- cor (as.vector(dataES), as.vector(dataESP), 
                     use = "pairwise.complete.obs")
      strccp <- format (ccpatt, digits = 2)
      # text (-2, 66, labels = c (paste( "R with est.skill: ",
      #                                 strccp)), cex = 5)

      # Plot the skill of the full hindcast
      fileHC <- paste (dirinTS, "cc_", model, "_", 
                       typerun, "_", varname, ".txt", sep = "")
      load (file = fileHC)
      
      dataHC <- aperm (corr_coeff_all[ , , inimth, ilead])
      dataHC [which (dataHC < minWUSHP, arr.ind = T)] <- minWUSHP
      titleHC <- paste ("Corr. coeff.", model, varname, "fullHC tar",
                         mthname[tarmth], "lead", (ilead - 1), sep = " ")
      
      image.plot (lon, lat, dataHC, 
                  xlab = "", breaks = breaksWUSHP, 
                  col = brewer.pal (ncolWUSHP, "YlOrRd"),
                  smallplot = c (0.87, 0.9, 0.05, 0.9), ylab = "", 
                  lab.breaks = format (breaksWUSHP, digits = 2),   
                  oldstyle = F, main = titleHC)
      map ("world", add = T)
      
      ccpatt <- cor (as.vector(dataES), as.vector(dataHC), 
                     use = "pairwise.complete.obs")
      strccp <- format (ccpatt, digits = 2)
      print (strccp)
      # text (-2, 66, labels = c (paste( "R with est.skill: ",
      #                                  strccp)), cex = 5)

   } # Einde van de loop over de looptijd van de verwachtingen   

   dev.off ()
   
} # Einde van de loop over de maanden van initialisatie   
  
      







