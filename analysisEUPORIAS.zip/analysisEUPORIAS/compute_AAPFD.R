rm(list=ls())	#remove all the variables from the workspace

library (ncdf4)
library (maps)
library (fields)
library (RColorBrewer)

versnr <- 2

nmthyr <- 12
dirlustre = "/lustre/backup/WUR/ESG/greue002/"

dirinbase <- "/lustre/backup/WUR/ESG/data/PROJECT_DATA/EUPORIAS/MODEL_OUTPUT/LPJml/0.50deg/"

dirinnohumi <- "EU_REFERENCE_rev1.7/"
if (versnr == 1) {
   dirinhumimp <- "EU_REFERENCE_rev4.0_humanimpact/"
} else if (versnr == 2) {
   dirinhumimp <- "EU_REFERENCE_rev4.1_humanimpact/"
}

filenohumi <- paste (dirinbase, dirinnohumi, "statistics/",
                     "Outputwatermodels_stats_LPJml_WFDEI_EU_1979_2010.nc4",
                     sep = "")
ncfilenohumi <- nc_open(filenohumi)
disnohumiread <- ncvar_get (ncfilenohumi, varid = "dis_mean")

filehumimp <- paste (dirinbase, dirinhumimp, "statistics/",
                     "Outputwatermodels_stats_LPJml_WFDEI_EU_1979_2010.nc4",
                     sep = "")
ncfilehumimp <- nc_open(filehumimp)
dishumimpread <- ncvar_get (ncfilehumimp, varid = "dis_mean")

# Remove first two years, which are spin up!
disnohumiread <- disnohumiread[ , , 25:384]  
dishumimpread <- dishumimpread[ , , 25:384]

dimarr <- dim(disnohumiread)
nlon <- dimarr[1]  
nlat <- dimarr[2]  
nmth <- dimarr[3]  

nyears <- nmth / nmthyr
disnohumi <- array(data = disnohumiread, dim = c(nlon, nlat, nmthyr, nyears))
dishumimp <- array(data = dishumimpread, dim = c(nlon, nlat, nmthyr, nyears))

aapfd <- array(NA, dim = c(nlon, nlat))

for (ilon in (1:nlon)) {
for (ilat in (1:nlat)) {
	
   disnat <- disnohumi [ilon, ilat, , ]
   dishum <- dishumimp [ilon, ilat, , ]
   
   nna <- sum (is.na(disnat) | is.na(dishum))
   
   if (nna == 0) {

      # Compute annual mean natural discharge
      disyearnat <- apply (disnat, 2, mean)

      sumyears <- 0.0

      for (iyear in (1:nyears)) {
		 summths <- 0.0
		 for (mth in (1:nmthyr)) {
			summths <- summths + ((dishum[mth,iyear] - disnat[mth,iyear]) / disyearnat[iyear])^2 }
		 sumyears <- sumyears + sqrt(summths)
      }
      aapfd[ilon, ilat] <- sumyears / nyears
		  
   }   
  
}
}

nint <- 9
lon <- seq (-24.25, 39.75, length.out = 129)
lat <- seq ( 33.25, 71.75, length.out =  78)
bps <- seq (0.0, 3.6, length.out =  (nint+1) )
image.plot (lon, lat, aapfd, breaks = bps, col = brewer.pal(nint, "YlOrRd"))

fileout <- paste (dirlustre, "verif_seas/AAPFD_v", versnr, ".txt", sep = "") 
save (aapfd,  file = fileout)

