rm(list=ls())	#remove all the variables from the workspace

library (ncdf4)

toscreen = F

varall <- c( "swe", "runoff", "precip", "evap" )
compwhatall <- c( "globwarmlow", "globwarmhigh", "lowwithhigh" )

if (toscreen) {
   widthscreen = 7.5
   dev.new (width = widthscreen, height = widthscreen) 
} 

for (var in varall) {
	
   if (var == "runoff")   { statall <- c( "avgyearmax", "perc10", "periodavg" ) }
   else if (var == "swe") { statall <- c( "avgyearmax" ) }
   else                   { statall <- c( "periodavg" ) }
   
for (stat in statall) {
	
   if (stat == "avgyearmax")  { titstat = "annual max" }
   else if (stat == "perc10") { titstat = "Q10" }
   else if (stat == "periodavg") { titstat = "mean" }
   
for (compwhat in compwhatall) {
for (boxplotnr in (1:2)) {
	
if (boxplotnr == 1) { 
   boxplot = F
   if (stat == "periodavg") { 
	  minall <- -0.35
      maxall <- 0.65
   } else if (stat == "perc10") { 
	  minall <- -0.3
      maxall <- 0.6
   } else if (stat == "avgyearmax") { 
	  if (var == "runoff") {
		 minall <- -10.0
         maxall <- 10.0
      } else if (var == "swe") {
		 minall <- -500.0
		 maxall <- 50.0
	  }
   }
} else {
   boxplot = T
   if (stat == "periodavg") { 
	  minall <- -0.2
      maxall <- 0.45
   } else if (stat == "perc10") { 
	  minall <- -0.15
      maxall <- 0.25
   } else if (stat == "avgyearmax") { 
	  if (var == "runoff") {
		 minall <- -5.0
         maxall <- 5.0
      } else if (var == "swe") {
		 minall <- -200.0
		 maxall <- 50.0
	  }
   }
}

dirlustre <- "/lustre/backup/WUR/ESG/greue002/"
dirimp2Cens <- paste (dirlustre, "IMP2Censemble/netcdfout/", sep = "")
dirout <- paste (dirlustre, "IMP2Censemble/epsplots/publication/compareglobwarm/",
                 sep = "")
system (paste ("mkdir -p ", dirout, sep = ""))

nsday <- 24 * 3600

titlebeg <- paste ("Change in", titstat, var, sep = " ")

for (xy in 1:2) {
	
   if (compwhat == "globwarmlow") {
      title <- paste (titlebeg, " for lower RCPs") 
	  RCP <- "low"
	  if (xy == 1) {
		 globwarm <- "+1p5C"
		 xtext <- "+1.5C global warming"
      }
	  if (xy == 2) {
		 globwarm <- "+2C"
		 ytext <- "+2C global warming"
      }
   }

   if (compwhat == "globwarmhigh") {
      title <- paste (titlebeg, " for RCP8.5s") 
	  RCP <- "high"
	  if (xy == 1) {
		 globwarm <- "+2C"
		 xtext <- "+2C global warming"
      }
	  if (xy == 2) {
		 globwarm <- "+3C"
		 ytext <- "+3C global warming"
      }
   }

   if (compwhat == "lowwithhigh") {
      title <- paste (titlebeg, " at +2C warming") 
	  if (xy == 1) {
		 globwarm <- "+2C"
		 xtext <- "lower RCPs"
	     RCP <- "low"
      }
	  if (xy == 2) {
		 globwarm <- "+2C"
		 ytext <- "high RCPs"
	     RCP <- "high"
      }
   }

   filein <- paste (dirimp2Cens, var, "/", var, "_stats_", RCP, "_nat_",
                    globwarm, "_all_avg_abschange_", stat, ".nc", sep = "")
   ncfilein <- nc_open(filein)
   varread <- ncvar_get (ncfilein, varid = var)
   
   if (var != "swe") varread <- varread * nsday
   
   if (xy == 1) x <- varread
   if (xy == 2) y <- varread
   
}

if (!toscreen) {
   if (boxplot) {
	  typeplot = "box"
   } else {
	  typeplot = "scatter"
   }
   fileout = paste (dirout, var, "_", stat, "_", compwhat, "_",
                    typeplot, ".png", sep = "")
   widthpng = 500
   png (file = fileout, width = widthpng, height = widthpng,
	    pointsize = 12, bg = "white")
}
	    
# minx <- min(x, na.rm = T)
# miny <- min(y, na.rm = T)
# minall <- min(minx, miny)
# maxx <- max(x, na.rm = T)
# maxy <- max(y, na.rm = T)
# maxall <- max(maxx, maxy)

par (cex = 0.7)        # was 0.5 before
par (cex.main = 2.5)   # was 3.0 before
# par (cex.lab = 1.0)    # was 3.0 before
# cex.axis gaat over tick mark labels
par (cex.axis = 2.5) 
par (mai = c(1.0, 1.2, 0.7, 0.7))
# mgp:
# The first value represents the location of the labels (i.e. xlab and ylab in plot)
# The second the tick-mark labels
# The third the tick marks.
# par (mgp = c(20, 1.5, 0))
par (mgp = c(20, 2, 0))

if (boxplot) {

   indval <- which (!is.na(x) & !is.na(y))
   xval <- x[indval]
   yval <- y[indval]
   xsort <- sort(xval, index.return = T)

   np <- length(indval)
   nbins <- 30
   npbin <- ceiling(np / nbins)
   begbin <- seq (1, (nbins - 1) * npbin + 1, length.out = nbins)
   endbin <- begbin + npbin - 1
   endbin[nbins] <- np
   arr_boxplot <- array(NA, dim = c(npbin, nbins))
   meanx_bin   <- vector ("double", nbins)
   mediany_bin <- vector ("double", nbins)
   
   for (ibin in (1:nbins)) {
	  xbin <- xval[xsort$ix[begbin[ibin]:endbin[ibin]]]
	  meanx_bin[ibin] <- mean(xbin)
	  ybin <- yval[xsort$ix[begbin[ibin]:endbin[ibin]]]
	  npthisbin <- length(ybin)
      arr_boxplot[1:npthisbin, ibin] <- ybin
      mediany_bin[ibin] <- median(ybin)
   }

   boxwidth <- 0.015 * (maxall - minall)
   boxplot (arr_boxplot, at = meanx_bin, col = "blue",
	        boxwex = boxwidth, outline = F, range = 0.01,  
		    xlim = c(minall, maxall), ylim = c(minall, maxall),
            main = title, xlab = NA, ylab = NA, xaxt = 'n',
            cex.lab = 0.5)
             
   # Compute derivative of line fitted to medians and through origin
   deriv <- sum (meanx_bin * mediany_bin) / sum (meanx_bin^2)
   xline <- c( meanx_bin[1],         meanx_bin[nbins])
   yline <- c( deriv * meanx_bin[1], deriv * meanx_bin[nbins]) 
   # abline (a = 0.0, b = deriv)
   lines (xline, yline, lty = 5)
    
} else {
   plot (x, y, xlim = c(minall, maxall), ylim = c(minall, maxall),
         main = title, xlab = NA, ylab = NA)
}

limax <- c(minall, maxall)   
lines (limax, limax)
abline (h = 0.0, lty = 3)
abline (v = 0.0, lty = 3)

# ratmean <- mean(y, na.rm = T) / mean(x, na.rm = T)
# strratmean <- format (ratmean, digits = 3)

# bxleg <- minall + 0.15
# textleg <- paste ("Ratio y/x =", strratmean)
# text (xleg, maxall - 0.03, textleg, cex = 3.0) 

indval <- which (!is.na(x) & !is.na(y))
# regrxy <- lm (y[indval] ~ x[indval])
# a <- regrxy$coefficients[[1]]
# b <- regrxy$coefficients[[2]]
# yregrmin <- a + b * minx  
# yregrmax <- a + b * maxx 
# pointmin <- c( minx, yregrmin) 
# pointmax <- c( maxx, yregrmax) 
# abline (pointmin, pointmax)

xleg  <- minall + 0.15 * (maxall - minall)
yleg1 <- maxall - 0.1  * (maxall - minall)
yleg2 <- maxall - 0.2  * (maxall - minall)

corrcoeff <- cor(x[indval], y[indval])
strcorrcoeff <- format (corrcoeff, digits = 3)
textcc <- paste ("R = ", strcorrcoeff)
text (xleg, yleg1, textcc, cex = 2.5)

strderiv <- format (deriv, digits = 3)
textderiv <- paste ("b = ", strderiv)
if (boxplot) text (xleg, yleg2, textderiv, cex = 2.5)

mtext (side = 1, xtext, line = 5, cex = 2.0)
mtext (side = 2, ytext, line = 5, cex = 2.0)

axis (side = 1, tick = T)

if (toscreen) {
   print ("Enter something to continue")
   entval <- scan (file = "", what = "", nmax = 1)
} else { dev.off () } 

}
}
}
}
