# Maakt figuur 5d uit het evaluatiepaper
# Ik heb dit programma nooit met verschillende settings gebruikt

rm(list=ls())	#remove all the variables from the workspace

library (maps)
library (RColorBrewer)
library (fields)

# Leadmth is volgens onze definitie (eerste lead month = 0)
model <- "VIC"
stat  <- "cc"
typerun <- "BC"
toscreen <- T
ESP <- "noESP"
alllead <- c(0,1,2)
leadtext <- paste ("lead month", alllead, sep = " ")
colleads <- c("blue", "red", "green")
onlysumplot <- T

nmthyr <- 12
mthname <- c("Jan", "Feb", "Mar", "Apr", "May", "June",
             "July", "Aug", "Sep", "Oct", "Nov", "Dec", "allmth")

dirlustre <- "/lustre/backup/WUR/ESG/greue002/"
dirstats  <- paste (dirlustre, "verif_seas/statdata/", sep = "")

var <- "runoff"
load (file = paste (dirstats, var, "/", model, "/", stat, "_", model,
                       "_", typerun, "_", var, ".txt", sep = ""))
if (stat == "cc") statrunoff <- corr_coeff_all

var <- "dis"
load (file = paste (dirstats, var, "/", model, "/", stat, "_", model,
                    "_", typerun, "_", var, "_pseudo_obs_allcells.txt",
                    sep = ""))
if (stat == "cc") statdis <- corr_coeff_all

# De volgende drie arrays zijn 4D, namelijk (lat, lon, tarmth, leadmth)
d_stat <- statdis - statrunoff

if (stat == "cc") {
   sst <- "corr. coeff."
   limax <- 0.28}

nlat = 78
nlon = 130
lat <- seq (33.25,  71.75, length.out = nlat)
lon <- seq (-24.75, 39.75, length.out = nlon)
ncel <- nlat * nlon

# ncelcatch is een 2D array met het aantal cellen van het 
#    afvoergebied van elke cel van het domein
dircatch <- paste (dirlustre, "routing/catchment_area/", sep = "")
filencel = paste (dircatch, "ncelcatch_CORDEX.txt", sep = "")
ncelvec <- scan (file = filencel) 
ncelcatch <- aperm (matrix(ncelvec, nrow = nlon, ncol = nlat)) 

nbr <- 12
eps <- 0.0001

fig.dir <- paste (dirlustre, "verif_seas/figures/dis-runoff/",
                  model, "/", sep = "")
system (paste ("mkdir -p ", fig.dir, sep = "")) 

if (toscreen) dev.new (width = 7.0, height = 6.0)

if (!toscreen) {
   png (file = paste (fig.dir, model, "_", stat, "_dis-runoff_catcharea", 
                               "_", ESP, "_", typerun, ".png", sep="") ,
                               width = 700, height = 600, pointsize = 12, 
                               bg = "white")}
                               
for (leadmth in alllead) {
	
   # Over alle maanden en het jaargemiddelde 
   for (inimth in 13:(nmthyr+1)) {
	
      if (inimth <= nmthyr) {
	     tarmth <- inimth + leadmth
         if (tarmth > nmthyr) tarmth <- tarmth - nmthyr
         datamap <- d_stat[ , ,inimth, leadmth+1]
         if (stat == "cc") maxval <- 0.55
      }
      else {
	     tarmth <- "all"
	     # Eerst worden de data voor de gekozen lead maand geselecteerd (datallmth)
	     # Daarna wordt er per roosterpunt gemiddeld over alle target maanden
	     dataallmth <- d_stat[ , , , leadmth+1]
         datamap <- apply (dataallmth, c(1,2), mean, na.rm = TRUE)
         if (stat == "cc") maxval <- 0.33
      }
      
      datamap[which (datamap >  maxval, arr.ind = T)] <- (maxval  - eps)
      datamap[which (datamap < -maxval, arr.ind = T)] <- (-maxval + eps)

      if (!onlysumplot) {   
      
         if (!toscreen) {
	        png (file = paste (fig.dir, model, "_", stat, "_dis-runoff_tarmth_", 
                               tarmth, "_leadmth_", leadmth, "_", ESP, "_", 
                               typerun, ".png", sep="") ,
                               width = 1500, height = 1000, pointsize = 12, 
                               bg = "white")
            # Set parameters for the plot
            par (mfrow=c(1,1), oma=c(5,5,5,5), mar=c(5,5,10,20), cex.main=5,
                 cex.axis=5, cex.lab=2.5, xpd=NA, las=1, lheight = 1.2, mgp = c(3,3,0))
         }
   
         title <- paste ("dis-runoff", model, typerun, "tar", mthname[tarmth],
                         "lead", leadmth, stat, sep = " ")
         breakp <- seq (-maxval, maxval, length.out = nbr)

         image.plot (lon, lat, aperm (datamap), zlim = c (0,0.05),
                     xlab = "", breaks = breakp, col = rev(brewer.pal(nbr - 1, "Spectral")),
                     smallplot = c (.87,.9,0.05,0.9), ylab = "",
                     lab.breaks = c (format (breakp, digits = 2)), 
                     oldstyle = F, main = title)
         map ("world", add = T)

      }
   
      binmax <- c(1, 2, 4, 8, 16, 32, 64, 128, 256)
      nbin <- length(binmax)
      arr_boxplot <- array(NA, dim = c(ncel, nbin))
      dxbox <- 0.28
      w_box <- 0.2
      if (toscreen) mulfac = 1.3
      else {
		 mulfac = 1.85
		 par (mai = c(1.1, 1.1, 0.5, 0.5))
      }

      par (cex.axis = mulfac, cex.lab = mulfac)
      ytekst <- paste (sst, "discharge -", sst, "runoff", sep = " ") 

      # arr_boxplot is 2D (totaal aantal roostercellen x aantal bins)
      # en is leeg behalve voor het bin waarin de cel valt
      # nind zijn alle cellen in een bin, inclusief cellen waar de waarde nan is
      # nfin is kleiner dan nind omdat de cellen met waarde nan niet meegeteld worden.
      for (ibin in 1:nbin) {
         if (ibin == 1) {binlow = 0}
         else {binlow = binmax[ibin - 1]}
         ind <- which (ncelcatch > binlow & ncelcatch <= binmax[ibin], arr.ind = T)
         n_ind <- length(ind)
         if (n_ind > 0) arr_boxplot [1:n_ind, ibin] <- datamap[ind]
         indval <- which (is.finite(datamap[ind]))
         nfin <- length (indval)
      }
      
      if (leadmth == alllead[1]) {
		 xbox <- seq (1 - dxbox, nbin - dxbox, length.out = nbin)
		 boxplot (arr_boxplot, at = xbox, col = colleads[1],
		          boxwex = w_box, outline = F, 
#		          xlab = "log2(catchment size in #grid cells)", xaxt = "n",
		          xlab = expression (log~{}^2*(catchment_size_in_number_of_cells)), xaxt = "n",
		          ylab = ytekst, ylim = c(-limax, limax), 
		          xlim = c(0.5, nbin + 0.5)) 
		 abline (h = 0.0, lwd = 3.0)
      }
		 
      if (leadmth == alllead[2]) {
		 xbox <- seq (1 , nbin , length.out = nbin)
		 boxplot (arr_boxplot, at = xbox, col = colleads[2],
		          boxwex = w_box, outline = F, add = T) }
   
      if (leadmth == alllead[3]) {
		 xbox <- seq (1 + dxbox, nbin + dxbox, length.out = nbin)
		 boxplot (arr_boxplot, at = xbox, col = colleads[3],
		          boxwex = w_box, outline = F, xaxt = "n", add = T) }
   
      print (mean (arr_boxplot, na.rm = T))

  }
   
}

legend(0.4, -0.12, leadtext, fill = colleads, cex = mulfac)

if (!toscreen) dev.off()
      




