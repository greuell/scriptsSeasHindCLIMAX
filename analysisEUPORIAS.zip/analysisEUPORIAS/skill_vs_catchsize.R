rm(list=ls())	#remove all the variables from the workspace

library (ncdf4)

toscreen = TRUE
nmth = 12
thrsign = 0.306

model = "VIC"
stat = "cc"
typerun = "BC"
typeobs <- "pseudo_obs"
typereal = "allcells"
lead = 2
finimth = 1
linimth = nmth

limxaxis <- c(-0.2, 1.0)
limyaxis = limxaxis

dirlustre = "/lustre/backup/WUR/ESG/greue002/"
dirstats <- paste (dirlustre, "verif_seas/statdata/dis/", 
                   model, "/", sep = "")

mthname <- c("Jan", "Feb", "Mar", "Apr", "May", "June",
             "July", "Aug", "Sep", "Oct", "Nov", "Dec")

dirlustre = "/lustre/backup/WUR/ESG/greue002/"
fig.dir <- paste (dirlustre, "verif_seas/figures/dis/",
                  model, "/", sep = "")
system (paste ("mkdir -p ", fig.dir, sep = ""))

# Lees de file met het oppervlak van het stroomopwaartse gebied
#    volgens de waarnemingen
# dirmeas = paste ("/lustre/backup/WUR/ESG/greue002/dischargedata/", 
#                  "GRDC-EWA/", typereal, "/1981-2010/", sep = "")
# filearea = paste (dirmeas, "monthly_catchmentarea_EU.nc", sep = "")
# ncareaobs <- nc_open(filearea)
# readareaobs <- ncvar_get (ncareaobs, varid = "carea")
# areaobs = aperm (readareaobs)

# Lees de files met het aantal stroomopwaartse cellen en het 
#    oppervlak van het stroomopwaartse gebied volgens VIC        
dircatch = "/lustre/backup/WUR/ESG/greue002/routing/catchment_area/"
filencel = paste (dircatch, "ncelcatch_CORDEX.txt", sep = "")
ncelvec <- scan (file = filencel) 
fileareamod = paste (dircatch, "areacatch_CORDEX.txt", sep = "")
areamodvec <- scan (file = fileareamod)  

nlat = 78
nlon = 130
nmthyr = 12

ncelcatch <- aperm (matrix(ncelvec,    nrow = nlon, ncol = nlat)) 
areamod   <- aperm (matrix(areamodvec, nrow = nlon, ncol = nlat)) 

sizepng = 400

mean_skill_small <- vector ("double", nmthyr)
mean_skill_large <- vector ("double", nmthyr)

for (inimth in finimth:linimth) {

   tarmth = inimth + lead 
   if (tarmth > 12) tarmth = tarmth - 12
	
   if (toscreen) {
      widthwindow = 6.0}
      # dev.new (width = widthwindow, height = widthwindow)  
   else {
	  fileout <- paste (fig.dir, typereal, "_stat_", stat, "_ini_", 
	                    mthname[inimth], "_tar_", mthname[tarmth], ".png") 
      png (file = fileout, width = sizepng, height = sizepng,
                  pointsize =12, bg = "white")
   }

   par (mar = c(5,5,2,2), cex = 1.25)
   
   filein = paste (dirstats, stat, "_", model, "_", typerun, 
                   "_dis_", typeobs, "_", typereal, 
                   ".txt", sep = "")
   load (filein)
                          
   skill_all = corr_coeff_all[ , , inimth, lead + 1]

   indsmall <- which (!is.na(areamod) & !is.na(skill_all) & 
                      areamod < 2500.0 & areamod > 0.0)
   # xplot <- log(areamod[indval])
   # yplot <- skill_all[indval]      
   # plot (xplot, yplot)
   nsmall = length(indsmall)
   mean_skill_small[tarmth] = mean(skill_all[indsmall])
   n_small_sign = sum (skill_all[indsmall] > thrsign)
   perc_sign_small = n_small_sign / nsmall * 100
   
   indlarge <- which (!is.na(areamod) & !is.na(skill_all) & 
                      areamod > 10000.0)
   nlarge = length(indlarge)
   mean_skill_large[tarmth] = mean(skill_all[indlarge])
   n_large_sign = sum (skill_all[indlarge] > thrsign)
   perc_sign_large = n_large_sign / nlarge * 100
   
   print (paste (tarmth, format (mean_skill_small[tarmth], digits = 3), 
                 format (mean_skill_large[tarmth], digits = 3), 
                 format (perc_sign_small, digits = 3), 
                 format (perc_sign_large, digits = 3), sep = " "))
 
}
