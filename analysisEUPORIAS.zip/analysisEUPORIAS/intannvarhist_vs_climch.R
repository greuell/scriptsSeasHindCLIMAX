# Dit programma vergelijkt de geprojecteerde klimaatverandering
#    met de interjaarlijkse variabiliteit tijdens de historische periode

rm(list=ls())	#remove all the variables from the workspace

library (ncdf4)

# Eigenlijk moet je je wel beperken tot runoff
#    omdat ik van Lisflood het oppervlak van de catchments niet heb
# Ik kan dan geen specifieke discharge berekenen
varname <- "runoff"
models_all <- c("EHYPE", "LIS", "LPJ", "VIC", "WBM")
forc_hist_all <- c("EOBS", "WFDEI")
forc_cc <- "allsimuls"
per_cc <- "+3C"
hist_per <- "1979-2000"
toscreen <- F

dirlustre <- "/lustre/backup/WUR/ESG/greue002/"

nsecyr <- 60 * 60 * 24 * 365.25

xwidth  <- 3.7
yheight <- 2 * xwidth
lowmar   <- 0.9
leftmar  <- 0.9
uppmar   <- 0.7
rightmar <- 0.5
horwidth  <- xwidth +  leftmar + rightmar
verheight <- yheight + lowmar  + uppmar

if (toscreen) dev.new (width = horwidth, height = verheight) 

for (model in models_all) {
for (forc_hist in forc_hist_all) {

model_hist <- model
CO2 <- ""	
if (model == "EHYPE") model_long <- "E-HYPE21"
if (model == "LIS")   model_long <- "Lisflood"
if (model == "LPJ") {
   model_long <- "LPJmL35"
   model_hist <- "LPJCO2"
   CO2        <- "co2_"
}
if (model == "VIC")   model_long <- "VIC421"
if (model == "WBM")   model_long <- "WBMplus"

if (forc_hist == "EOBS") {
   forc_hist_long <- "EOBSv9"
   vers_model <- "vers9band"
} else if (forc_hist == "WFDEI") {
   forc_hist_long <- "WFDEI"
   vers_model <- "CORDEX"
}

if (model == "VIC") {
   dir_hist <- paste (dirlustre, model_hist, "/netcdfout/", forc_hist, "/",
                      vers_model, "/", varname, "/stats/", sep = "")
} else {
   dir_hist <- paste (dirlustre, model_hist, "/netcdfout/", forc_hist, "/",
                      varname, "/stats/", sep = "")
}
file_hist <- paste (dir_hist, varname, "_daily_", model_long, 
                    "_nat_", forc_hist_long, "_", CO2, hist_per, 
                    "_stdyearavg.nc", sep = "")
nc_hist <- nc_open(file_hist)
std_hist <- ncvar_get (nc_hist, varid = varname)

dir_cc <- paste (dirlustre, "IMP2Censemble/netcdfout/", varname, "/",
                 sep = "")
file_cc <- paste (dir_cc, varname, "_stats_", forc_cc, "_nat_",
                  per_cc, "_", model, "_avg_abschange_periodavg.nc",
                  sep = "")
nc_cc <- nc_open(file_cc)
cc <- ncvar_get (nc_cc, varid = varname)

if (varname == "dis") {
   mulf <- 1.0
} else if (varname == "runoff") { 
   mulf <- nsecyr
   unit <- "mm/yr"
}

std_hist_yr <- mulf * std_hist
cc_yr       <- mulf * cc

abs_cc <- abs(cc_yr)

min_ax <- 0.0
max_ax <- 400.0   
lim_xax <- c( min_ax, max_ax)   
lim_yax <- c(-max_ax, max_ax)

range <- max_ax - min_ax
xleg  <- min_ax + 0.4 * range
yleg  <- max_ax - 0.1  * range
dyleg <- 0.1 * range

title <- paste (varname, " (", unit, ")  ", model, "  ", forc_hist,
                sep = "") 
ytext <- paste ("Climate change at", per_cc, sep = " ") 

if (!toscreen) {
   dirout <- paste (dirlustre, "climch_vs_intvar/figures/", sep = "")
   fileout = paste (dirout, varname, "_", model, "_", forc_hist, "_",
                    per_cc, ".png", sep = "")
   facpng = 72
   widthpng =  facpng * horwidth
   heightpng = facpng * verheight
   png (file = fileout, width = widthpng, height = heightpng,
	    pointsize = 12, bg = "white")
}
	    
par (cex = 0.5, cex.main = 2.5, cex.lab = 2.5, cex.axis = 2.5)
par (mai = c(lowmar, leftmar, uppmar, rightmar))
# mgp:
# The first value represents the location of the labels (i.e. xlab and ylab in plot)
# The second the tick-mark labels
# The third the tick marks.
# par (mgp = c(20, 1.5, 0))
par (mgp = c(5, 2, 0))        

plot (std_hist_yr, cc_yr, xlim = lim_xax, ylim = lim_yax,
      xlab = "Standard deviation of annual values 1979-2000",
      ylab = ytext, main = title, xaxs = "i", yaxs = "i")
lines (lim_xax, lim_xax, lty = 2)
lines (lim_xax, c(min_ax, -max_ax), lty = 2)

indmean <- which (!is.na(std_hist_yr) & !is.na(abs_cc))
n_comp <- length(indmean)

rat_cc_std <- mean(abs_cc[indmean]) / mean(std_hist_yr[indmean])
str_ratsc <- format (rat_cc_std, digits = 3)
text_leg1 <- paste ("Ratio abs(CC)/IV = ", str_ratsc, sep = "")
text (xleg, yleg, text_leg1, cex = 2.5)

print (mean   (std_hist_yr[indmean]))
print (mean   (abs_cc[indmean]))
print (median (std_hist_yr[indmean]))
print (median (abs_cc[indmean]))

ind_std_lar <- which (!is.na(std_hist_yr) & !is.na(abs_cc) & 
                      std_hist_yr > abs_cc)
n_lar <- length(ind_std_lar)
frac_lar <- 100 * n_lar / n_comp
str_lar <- format (frac_lar, digits = 3)
yleg2 <- yleg - dyleg
text_leg2 <- paste ("abs(CC)<IV =", str_lar, "%", sep = " ")
text (xleg, yleg2, text_leg2, cex = 2.5)
                       
print (n_comp)
print (n_lar)
print (frac_lar)

if (toscreen) {
   print ("Enter something to continue")
   entval <- scan (file = "", what = "", nmax = 1)
} else { dev.off () } 

}
}



