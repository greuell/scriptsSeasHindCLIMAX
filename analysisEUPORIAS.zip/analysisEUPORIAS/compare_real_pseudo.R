rm(list=ls())	#remove all the variables from the workspace

toscreen = 1
nmth = 12

model = "VIC"
stat = "cc"
typerun = "BC"
typereal = "subcell"
typeobs <- c("pseudo_obs", "real_obs")
ntypeobs <- length(typeobs)
lead = 2
finimth = 1
linimth = 12

# Define region boundaries
nreg = 5
reg_bound <- array(999.0, dim = c(nreg, 4))
reg_bound[1, ] <- c(56.0, 68.0,   4.0, 30.0)   # Fennoscandia
reg_bound[2, ] <- c(33.0, 40.0, -25.0, 40.0)   # southern Mediteraanean
reg_bound[3, ] <- c(50.5, 55.0,   7.0, 23.0)   # Poland - North Germany
reg_bound[4, ] <- c(41.5, 48.0,  22.0, 30.0)   # Romania - Bulgaria
reg_bound[5, ] <- c(45.5, 50.5,  -2.5,  5.0)   # West France
col_reg   <- c("blue", "red", "purple", "orange", "green")
shortname_reg <- c("Fenscan", "S-Medter", "PL/N-Ger", "Rom/Bulg", "W-Fra")
mth_skill <- array(0, dim = c(nreg, nmth))
mth_skill[1, 1:10] = 1
mth_skill[2, 6: 8] = 1
mth_skill[3, 1] = 1; mth_skill[3, 11:12] = 1
mth_skill[4, 1] = 1; mth_skill[4, 12] = 1
mth_skill[5, 1:5] = 1; mth_skill[5, 12] = 1

# The palette with grey:
cbbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
ncolors <- length(cbbPalette)

noskill = 0.306
if (typereal == "largebasins") {
   thraap <- 0.3
} else if (typereal == "subcell") {
   thraap <- 0.05
} 

limxaxis <- c(-0.2, 1.0)
limyaxis = limxaxis

dirlustre = "/lustre/backup/WUR/ESG/greue002/"
dirstats <- paste (dirlustre, "verif_seas/statdata/dis/", 
                   model, "/", sep = "")

mthname <- c("Jan", "Feb", "Mar", "Apr", "May", "June",
             "July", "Aug", "Sep", "Oct", "Nov", "Dec")

dirlustre = "/lustre/backup/WUR/ESG/greue002/"
fig.dir <- paste (dirlustre, "verif_seas/figures/comprealpseudo/",
                  model, "/", sep = "")
system (paste ("mkdir -p ", fig.dir, sep = ""))

# Lees AAPFD
diraapfd <- paste (dirlustre, "verif_seas/", sep = "")
fileaapfd <- paste (diraapfd, "AAPFD_v2.txt", sep = "")
load (file = fileaapfd)

# Voeg een kolom toe en permuteer
# Is gecontroleerd en correct bevonden.
nlon <- 130
nlat <- 78
aapfd_VIC <- array (NA, dim = c(nlon, nlat))
aapfd_VIC [2:nlon, ] <- aapfd
aapfd_VIC <- aperm (aapfd_VIC)

sizepng = 400

freg = 0
lreg = 5

for (inimth in finimth:linimth) {

   tarmth = inimth + lead 
   if (tarmth > 12) tarmth = tarmth - 12
	
   for (iobs in 1:ntypeobs) {

      load (file = paste (dirstats, stat, "_", model, "_", typerun, 
                          "_dis_", typeobs[iobs], "_", typereal, 
                          ".txt", sep = ""))
                          
      print (typeobs[iobs])

      if (iobs == 1) {
	     dimstat <- dim(corr_coeff_all)
	     nlat  = dimstat[1]
	     nlon  = dimstat[2]
	     nmth  = dimstat[3]
	     nlead = dimstat[4]
	     statcomp <- array(NA, dim = c(nlat, nlon, ntypeobs))
         lat <- seq( 33.25, 71.75, length.out = nlat)
         lon <- seq(-24.75, 39.75, length.out = nlon)
         arrreg <- array(0, dim = c(nlat, nlon))
         for (ilat in 1:nlat) {
         for (ilon in 1:nlon) {
		 for (ireg in 1:nreg) {
			if (lat[ilat] > reg_bound[ireg, 1] &
			    lat[ilat] < reg_bound[ireg, 2] &
			    lon[ilon] > reg_bound[ireg, 3] &
			    lon[ilon] < reg_bound[ireg, 4]) {
			   if (lead == 2 & mth_skill[ireg, tarmth] == 1) arrreg[ilat, ilon] = ireg}
		 }}}
      }
      
      statcomp[ , , iobs] = corr_coeff_all[ , , inimth, lead + 1]
      
   }
      
   xall = statcomp[ , , 1]
   yall = statcomp[ , , 2]

   if (toscreen == 1) {
      widthwindow = 6.0
      dev.new (width = widthwindow, height = widthwindow) } 
   else if (toscreen == 0) {
	  fileout <- paste (fig.dir, typereal, "_stat_", stat, "_ini_", 
	                    mthname[inimth], "_tar_", mthname[tarmth], ".png") 
      png (file = fileout, width = sizepng, height = sizepng,
                  pointsize =12, bg = "white")
   }

   par (mar = c(5,5,2,2), cex = 1.25)

   nregwp <- 0
      
   for (ireg in (freg:lreg)) {

      indreg <- which (!is.na(xall) & !is.na(yall) & arrreg == ireg, arr.ind = T)
      xplot <- xall[indreg]
      yplot <- yall[indreg]
      aapfdreg <- aapfd_VIC[indreg]	
      
      if (ireg == freg) {
		 plot (xplot, yplot, xlim = limxaxis, xaxs = "i",
	      	                 ylim = limyaxis, yaxs = "i",
		                     xlab = "Statistic using pseudo observations", 
		                     ylab = "Statistic using real observations",
		                     main = paste (stat, model, typerun, "ini", 
		                                   mthname[inimth], "tar", mthname[tarmth],
		                                   typereal, sep = " " ))
         abline (a = 0.0, b = 1.0)
         abline (v = noskill, lty = 2)
         abline (h = noskill, lty = 2)
      }
      
      np <- length (xplot)
      if (np == 0) {
		 next
	  } else {
		 nregwp <- nregwp + 1
	  }
	  
	  if (ireg == 0) {
		 textleg <- ""
		 colhere <- "black"
	  } else {
		 textleg <- shortname_reg[ireg]
		 colhere <- col_reg[ireg]
	  }

      points (xplot, yplot, col = colhere)
      indlowaap <- which (aapfdreg < thraap)
      points (xplot[indlowaap], yplot[indlowaap], col = colhere, 
              pch = 21, bg = colhere)
      print (paste (length(xplot), length(indlowaap), sep = "    "))
      legend (-0.2, 1.08 - 0.08 * nregwp, textleg, 
              bty = "n", text.col = colhere)
            
      # indstr <- which (yplot > 0.5 & (yplot - xplot) > 0.15, arr.ind = T)
      # dimind <- dim(indstr)
      # if (dimind[1] > 0) {
	  #    for (istr in 1:dimind[1]) { 
	  #       ilat = indstr[istr, 1]
	  #       ilon = indstr[istr, 2]
	  #       latstr = 33.25  + (ilat - 1) * 0.5 
	  #       lonstr = -24.75 + (ilon - 1) * 0.5 
	  #       print ( paste (ilat, ilon, "lat =", latstr, "   lon =", lonstr, 
	  #                      xplot[ilat, ilon], yplot[ilat, ilon], sep = " "))
	  #    }
      # }
      
   }

   if (freg == 0) legend (-0.2, 1.08 - 0.08 * (nregwp + 1), "other reg", 
                          bty = "n", text.col = "black")
	   	   
   if (toscreen == 1) {
      print ("Enter something to continue")
      entval <- scan (file = "", what = "", nmax = 1) 
   }
   
   dev.off()

}
