rm(list=ls())	#remove all the variables from the workspace

argum <- commandArgs (TRUE)

# Hier begint de input, die loopt tot ### Einde input. 
# Je kunt ver komen door alleen hier te variëren
fpart <- argum[1]   # Er is een do-loop over een deel van de (40) parts
                    #    waarin VIC gerund is. Dit is het eerste part.                 
lpart <- argum[2]   # En dit het laatste.

# alltypesESP <- c ("ESPsnow", "ESPsoilm", "revESP")
alltypesESP <- c ("revESP")

### Einde input

dirlustre = "/lustre/backup/WUR/ESG/greue002/"
dirVICinput  = "/lustre/backup/WUR/ESG/frans004/PROJECTS/EUPORIAS/VIC/INPUT/"
dirinitin  = paste (dirVICinput, "initstates/", sep = "")
dirVICoutput = paste (dirlustre, "tempstatefiles/", sep = "")

nparts = 40
fmth = 1
lmth = 12
fyearsim = 1981
lyearsim = 2010 

ndaymthnorm = c (31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
maxcell = 300
maxband = 30
maxveg  = 20

nyear = (lyearsim - fyearsim) + 1

# Lees gegevens over hoogtebanden en vegetatiefracties
dirVICinp <- paste (dirlustre, "VIC/VICprog/LibsAndParams/", sep = "")
filebands <- paste (dirVICinp, "global_snowbands_precgrad30.txt", sep = "")
arr_bands <- read.table (filebands)

for (part in fpart:lpart) {
	
   dirinpart =  paste (dirinitin,  "Part_", part, "/", sep = "")
   dirRAMbase = paste ("/dev/shm/EUPORIAS/part", part, "/", sep = "")
   
   for (mth in fmth:lmth) {
	  
       system (paste ("mkdir -p ", dirRAMbase, sep = ""))
       
	   namemth <- toString(mth)
       if (mth < 10) namemth <- paste ("0", namemth, sep = "")

       # Initiële toestand-files hebben een naam met de laatste dag van
       #    de voorgaande maand
       # Voor de middeling van de initiële toestanden van 31 december
       #    moeten we dus een jaar terug      
       if (mth != 12) {
		  fyearini = fyearsim
		  lyearini = lyearsim }
	   else {
		  fyearini = fyearsim - 1
		  lyearini = lyearsim - 1 }
       
       for (year in fyearini:lyearini) {
		   
		  iyear = year - fyearini + 1 
		  print (paste ("read", year, "month", mth, "Part", part, sep = " "))

          leapyr <- (((year %% 4 == 0) & (year %% 100 != 0)) | (year %% 400 == 0))
          if (mth == 2 & leapyr) {ndaymth = 29}
          else ndaymth = ndaymthnorm[mth]
           		   
		  filein = paste (dirinpart, "state_", year, namemth, ndaymth, sep = "")
		  
		  arr <- scan (filein)
		  
		  yearini <- arr[1]
		  mthini  <- arr[2]
		  dayini  <- arr[3]

		  nlay    <- arr[4]
		  nnod    <- arr[5]

          if (year == fyearini) {		  
             cellnr <- array(0, dim = c(nyear, maxcell))
             nveg   <- array(0, dim = c(nyear, maxcell))
             nband  <- vector (mode = "integer", length = maxcell)
             distT  <- array(NA, dim = c(maxcell, nnod))
             depthT <- array(NA, dim = c(maxcell, nnod))
             anoint <- array(0, dim = c(nyear, maxcell, maxveg))
             
             vegseqn  <- array(NA, dim = c(maxcell, maxveg))
             totsm    <- array(NA, dim = c(nyear, maxcell, maxveg, maxband, nlay))
             totice   <- array(NA, dim = c(nyear, maxcell, maxveg, maxband, nlay))
             dew      <- array(NA, dim = c(nyear, maxcell, maxveg, maxband))
             nstss    <- array(NA, dim = c(nyear, maxcell, maxveg, maxband))
             flagacc  <- array(NA, dim = c(nyear, maxcell, maxveg, maxband))
             frsnow   <- array(NA, dim = c(nyear, maxcell, maxveg, maxband))
             swe      <- array(NA, dim = c(nyear, maxcell, maxveg, maxband))
             tempss   <- array(NA, dim = c(nyear, maxcell, maxveg, maxband))
             liqws    <- array(NA, dim = c(nyear, maxcell, maxveg, maxband))
             temppck  <- array(NA, dim = c(nyear, maxcell, maxveg, maxband))
             liqwpck  <- array(NA, dim = c(nyear, maxcell, maxveg, maxband))
             denssn   <- array(NA, dim = c(nyear, maxcell, maxveg, maxband))
             coldct   <- array(NA, dim = c(nyear, maxcell, maxveg, maxband))
             swecan   <- array(NA, dim = c(nyear, maxcell, maxveg, maxband))
             soiltemp <- array(NA, dim = c(nyear, maxcell, maxveg, maxband, nnod))
          }
 
		  fel = 5
		  totnel = length(arr)
		  icell = 0
		  
		  while (fel < totnel) {
			  
			 icell = icell + 1
			 cellnr[iyear, icell] <- arr[fel + 1]
			 nveg[iyear,icell]    <- arr[fel + 2]
			 nband[icell]         <- arr[fel + 3]
			 distT[icell,]        <- arr[(fel + 4): (fel + nnod + 3)] 
			 depthT[icell,]       <- arr[(fel + nnod + 4): (fel + 2* nnod + 3)] 

		     fel = fel + 2 * nnod + 3
		     
			 for (iveg in (1:(nveg[iyear, icell] + 1))) {
				 
				check1 <- arr[fel + 1] 
				anoint[iyear, icell, iveg] <- arr[fel + 2] 
				check3 <- arr[fel + 3] 
				if (check1 != 1.0 | check3 != -999) stop ("Error")
				
				fel = fel + 3
				
				for (iband in (1:nband[icell])) {

                   # This is the vegetation sequential number
                   # The last one for each cell is bare soil				   
				   vegseqn[icell, iveg] <- arr[fel + 1]
				   bandnr               <- arr[fel + 2]
				   totsm[iyear, icell, iveg, iband, ]  <- arr[(fel + 3): (fel + 2 + nlay)]
				   totice[iyear, icell, iveg, iband, ] <- arr[(fel + 3 + nlay): (fel + 2 + 2 * nlay)]
				   fel = fel + 2 + 2 * nlay
				   # Dew is not available for bare soil
				   if (iveg != (nveg[iyear, icell]+1)) {
					  dew[iyear, icell, iveg, iband]   <- arr[fel + 1]
					  fel = fel + 1
				   }
				   nstss[iyear, icell, iveg, iband]    <- arr[fel + 1]
				   flagacc[iyear, icell, iveg, iband]  <- arr[fel + 2]
		           frsnow[iyear, icell, iveg, iband]   <- arr[fel + 3]
				   swe[iyear, icell, iveg, iband]      <- arr[fel + 4]
				   tempss[iyear, icell, iveg, iband]   <- arr[fel + 5]
				   liqws[iyear, icell, iveg, iband]    <- arr[fel + 6]
				   temppck[iyear, icell, iveg, iband]  <- arr[fel + 7]
				   liqwpck[iyear, icell, iveg, iband]  <- arr[fel + 8]
				   denssn[iyear, icell, iveg, iband]   <- arr[fel + 9]
				   coldct[iyear, icell, iveg, iband]   <- arr[fel + 10]
				   swecan[iyear, icell, iveg, iband]   <- arr[fel + 11]
				   soiltemp[iyear, icell, iveg, iband, ] <- arr[(fel + 12) : (fel + 11 + nnod)]

				   fel = fel + 11 + nnod
				   
				}   # Einde loop over de banden

			 } # Einde van de loop over de vegetatietypes
			 
	      } # Einde van de while-loop over de cellen
      	      
	   }   # Einde van de loop over de jaren (inlezen)
	   
	   ncell = icell
	   print ("Reading finished")
	   
       # Bereken gemiddeldes over de jaren
       # Voor ESPsnow en revESP moeten de bodemvochteigenschappen gemiddeld worden
       totsm_avg    <- apply (totsm,    c(2,3,4,5), mean)
       totice_avg   <- apply (totice,   c(2,3,4,5), mean)
       dew_avg      <- apply (dew,      c(2,3,4),   mean)
       soiltemp_avg <- apply (soiltemp, c(2,3,4,5), mean)
       
       # Voor ESPsoilm en revESP moeten de sneeuweigenschappen gemiddeld worden
       nstss_avg    <- round (apply (nstss,   c(2,3,4), mean, na.rm = T))
       # flagacc is 0 of 1; we nemen de, over de jaren genomen, meest voorgekomen waarde
       flagacc_mfr  <- round (apply (flagacc, c(2,3,4), mean, na.rm = T))
       frsnow_avg   <- apply (frsnow,  c(2,3,4),    mean)
       swe_avg      <- apply (swe,     c(2,3,4),    mean)
       tempss_avg   <- apply (tempss,  c(2,3,4),    mean)
       liqws_avg    <- apply (liqws,   c(2,3,4),    mean)
       temppck_avg  <- apply (temppck, c(2,3,4),    mean)
       liqwpck_avg  <- apply (liqwpck, c(2,3,4),    mean)
       denssn_avg   <- apply (denssn,  c(2,3,4),    mean)
       coldct_avg   <- apply (coldct,  c(2,3,4),    mean)
       swecan_avg   <- apply (swecan,  c(2,3,4),    mean)
       
       print ("Averaging finished")

       # Wegschrijven
       
       formatsnow = "%i %i %f %f %f %f %f %f %f %f %f"
       
       for (typeESP in alltypesESP) {
    
          for (year in fyearini:lyearini) {

		     print (paste ("write", typeESP, year, "month", mth, "Part", part, sep = " "))
		   
		     iyear = year - fyearini + 1
             leapyr <- (((year %% 4 == 0) & (year %% 100 != 0)) | (year %% 400 == 0))
             if (mth == 2 & leapyr) {ndaymth = 29}
             else ndaymth = ndaymthnorm[mth]

             dirinitout = paste (dirRAMbase, "initstates_", typeESP, "/", sep = "")           		   
             diroutpart = paste(dirinitout, "Part_", part, "/", sep = "")
             system (paste ("mkdir -p ", diroutpart, sep = ""))
		     fileout = paste (diroutpart, "state_", year, namemth, ndaymth, sep = "")

             strwr1 <- sprintf("%i %i %i", year, mth, ndaymth)		  
		     write (strwr1, file = fileout, ncolumns = 1)
             strwr2 <- sprintf("%i %i", nlay, nnod)		  
		     write (strwr2, file = fileout, ncolumns = 1, append = T)
		  
		     for (icell in (1:ncell)) {
			  
                strdist  <- paste (sprintf ("%f", distT[icell, ]),  collapse = " ")
                strdepth <- paste (sprintf ("%f", depthT[icell, ]), collapse = " ")
                strwr3 <- sprintf("%i %i %i %s %s", 
                          cellnr[iyear,icell], nveg[iyear,icell], nband[icell], 
		                  strdist, strdepth)		  
		        write (strwr3, file = fileout, ncolumns = 1, append = T)
		        
			    for (iveg in (1:(nveg[iyear, icell] + 1))) {
                   strwr4 <- sprintf("%f %i %i", 1.0, anoint[iyear, icell, iveg], -999)		  
		           write (strwr4, file = fileout, ncolumns = 1, append = T)

		           for (iband in (1:nband[icell])) {
					
	                  if (typeESP == "ESPsnow") {
                         strsm   <- paste (sprintf ("%f", totsm_avg[icell, iveg, iband, ]),     collapse = " ")
                         strice  <- paste (sprintf ("%f", totice_avg[icell, iveg, iband, ]),    collapse = " ")
                         strtemp <- paste (sprintf ("%f", soiltemp_avg[icell, iveg, iband, ]), collapse = " ")
                         dewveg  <-                       dew_avg[icell, iveg, iband]
					  }
	                  if (typeESP == "ESPsoilm") {
                         strsm   <- paste (sprintf ("%f", totsm[iyear, icell, iveg, iband, ]),     collapse = " ")
                         strice  <- paste (sprintf ("%f", totice[iyear, icell, iveg, iband, ]),    collapse = " ")
                         strtemp <- paste (sprintf ("%f", soiltemp[iyear, icell, iveg, iband, ]), collapse = " ")
                         dewveg  <-                       dew[iyear, icell, iveg, iband]
				      }
	                  if (typeESP == "revESP") {
                         strsm   <- paste (sprintf ("%f", totsm_avg[icell, iveg, iband, ]),     collapse = " ")
                         strice  <- paste (sprintf ("%f", totice_avg[icell, iveg, iband, ]),    collapse = " ")
                         strtemp <- paste (sprintf ("%f", soiltemp_avg[icell, iveg, iband, ]), collapse = " ")
                         dewveg <-                        dew_avg[icell, iveg, iband]
				      }
				      
	                  if (typeESP == "ESPsnow") {
					     strsnow <- sprintf (formatsnow,
					                   nstss  [iyear, icell, iveg, iband],
					                   flagacc[iyear, icell, iveg, iband], 
					                   frsnow [iyear, icell, iveg, iband], 
					                   swe    [iyear, icell, iveg, iband], 
					                   tempss [iyear, icell, iveg, iband], 
					                   liqws  [iyear, icell, iveg, iband], 
	    				               temppck[iyear, icell, iveg, iband], 
					                   liqwpck[iyear, icell, iveg, iband], 
					                   denssn [iyear, icell, iveg, iband], 
					                   coldct [iyear, icell, iveg, iband], 
					                   swecan [iyear, icell, iveg, iband])
				      }
	                  if (typeESP == "ESPsoilm") {
					     strsnow <- sprintf (formatsnow,
					                   nstss_avg  [icell, iveg, iband],
					                   flagacc_mfr[icell, iveg, iband], 
					                   frsnow_avg [icell, iveg, iband], 
					                   swe_avg    [icell, iveg, iband], 
					                   tempss_avg [icell, iveg, iband], 
					                   liqws_avg  [icell, iveg, iband], 
					                   temppck_avg[icell, iveg, iband], 
					                   liqwpck_avg[icell, iveg, iband], 
					                   denssn_avg [icell, iveg, iband], 
					                   coldct_avg [icell, iveg, iband], 
					                   swecan_avg [icell, iveg, iband])
				      }
	                  if (typeESP == "revESP") {
					     strsnow <- sprintf (formatsnow,
					                   nstss_avg  [icell, iveg, iband],
					                   flagacc_mfr[icell, iveg, iband], 
					                   frsnow_avg [icell, iveg, iband], 
					                   swe_avg    [icell, iveg, iband], 
					                   tempss_avg [icell, iveg, iband], 
					                   liqws_avg  [icell, iveg, iband], 
					                   temppck_avg[icell, iveg, iband], 
					                   liqwpck_avg[icell, iveg, iband], 
					                   denssn_avg [icell, iveg, iband], 
					                   coldct_avg [icell, iveg, iband], 
					                   swecan_avg [icell, iveg, iband])
				      }

                      # Dauw wordt niet weggeschreven voor kale bodem
				      if (iveg != (nveg[iyear, icell]+1)) {
	                     strwr5 <- sprintf ("%i %i %s %s %f %s %s", iveg - 1, iband - 1, 
	                                        strsm, strice, dewveg, strsnow, strtemp)
				      }
				      else {
	                     strwr5 <- sprintf ("%i %i %s %s %s %s", iveg - 1, iband - 1, 
	                                        strsm, strice, strsnow, strtemp)
				      }
				   				   
		              write (strwr5, file = fileout, ncolumns = 1, append = T)
		              
			       }   # Einde van de loop over de hoogtebanden
		        }   # Einde van de loop over de vegetatietiles		               		        
		     }   # Einde van de loop over de cellen (binnen 1 part)			  
          }   # Einde van de loop over de jaren
       }   # Einde van de loop over de types ESP 
 
       system (paste ("cp -rf ", dirRAMbase, "/* ", dirVICoutput, sep = ""))
       system (paste ("rm -rf ", dirRAMbase, sep = ""))
       
   }   # Einde van de loop over de maanden 

}   # Einde van de loop over de parts
	
	
	
