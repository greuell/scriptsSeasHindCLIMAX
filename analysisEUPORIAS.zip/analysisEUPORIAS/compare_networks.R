rm(list=ls())	#remove all the variables from the workspace

library (ncdf4)
library (fields)
library (RColorBrewer)

toscreen = F

dirlustre <- "/lustre/backup/WUR/ESG/greue002/"
dirin <- paste (dirlustre, "routing/catchment_area/", sep = "")

file_EHYPE <- paste (dirin, "uparea_E-HYPE21.nc", sep = "")
ncfile_EHYPE <- nc_open(file_EHYPE)
catch_EHYPE <- ncvar_get (ncfile_EHYPE, varid = "uparea")
lon         <- ncvar_get (ncfile_EHYPE, varid = "lon")
lat         <- ncvar_get (ncfile_EHYPE, varid = "lat")

dimgrid <- dim (catch_EHYPE)
nlon <- dimgrid[1]
nlat <- dimgrid[2]

file_VIC <- paste (dirin, "areacatch_CORDEX.txt", sep = "")

catch_VIC_vec <- scan (file = file_VIC)
catch_VIC <- matrix (catch_VIC_vec, nrow = nlon, ncol = nlat, byrow = F)

ind0 <- which (catch_VIC == 0, arr.ind = T)
catch_VIC[ind0] <- NA

absdiff <- catch_EHYPE - catch_VIC
reldiff <- abs(100.0 * (catch_EHYPE - catch_VIC) / catch_VIC)

ind100 <- which (reldiff >= 100.0, arr.ind = T)
reldiff[ind100] <- 100.0

colnames <- c("cyan", "blue", "purple2", "red", "black")
ncol <- length(colnames)

breaks <- c (0, 15, 25, 50, 75, 100)
n_breaks <- length(breaks)

ni <- 256
bcn <- 0
nwhbl <- 7
ndb <- 139
fbl <- 30
# red   <- c(seq (ni-fbl, 0,       length.out = nwhbl), seq (0, 0, length.out = ncol - nwhbl))
# green <- c(seq (ni-fbl, 0,       length.out = nwhbl), seq (0, 0, length.out = ncol - nwhbl))
# blue  <- c(seq (ni-fbl, ni-fbl , length.out = nwhbl), seq (ni-1, ndb, length.out = ncol - nwhbl))
# colnames <- c("lightblue1", "darkslategray1", "cyan", "cyan2", "deepskyblue1", "blue", "blue2", 
#               "purple2", "red", "red3", "brown", "black")

widthscreen = 7.5
widthpng = 500
rathw = 5.5 / 7.5

if (toscreen) {
   dev.new (width = widthscreen, height = rathw * widthscreen) 
} else {
   fileout <- paste (dirin, "reldiff_EHYPE_VIC.png", sep = "")
   png (file = fileout, width = widthpng, height = rathw * widthpng,
   pointsize =12, bg = "white")
}

par (oma = c(2,2,1,3), mar = c(1, 1, 1, 1), 
     cex.axis = 1, xpd=NA, las = 1, lheight = 2.4, mgp = c(3,1,0))

image.plot (lon, lat, reldiff, 
            xlab = "", ylab = "", oldstyle = F, breaks = breaks, col = colnames,
            smallplot = c(.87, .9, 0.05, 0.9))
map ("world", add = T)

if (toscreen) {
   print ("Enter something to continue")
   entval <- scan (file = "", what = "", nmax = 1) }

dev.off ()

