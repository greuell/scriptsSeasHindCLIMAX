rm(list=ls())	#remove all the variables from the workspace

library (fields)
library (RColorBrewer)
library (maps)

var <- "runoff"
model<- "VIC"
stat <- "cc"
typerun <- "BC"

mthname <- c("Jan", "Feb", "Mar", "Apr", "May", "June",
             "July", "Aug", "Sep", "Oct", "Nov", "Dec")

dirlustre = "/lustre/backup/WUR/ESG/greue002/"
dirstatdata <- paste (dirlustre, "verif_seas/statdata/", var, "/", model, "/", sep = "")

fileESPall <- paste (dirstatdata, stat, "_", model, "_ESPall_", typerun,
                     "_", var, ".txt", sep = "")
load (file = fileESPall)
stat_all_ESPall <- corr_coeff_all

filerevESP <- paste (dirstatdata, stat, "_", model, "_revESP_", typerun,
                     "_", var, ".txt", sep = "")
load (file = filerevESP)
stat_all_revESP <- corr_coeff_all

dimstat <- dim(stat_all_ESPall)
nlat   <- dimstat[1]
nlon   <- dimstat[2]
nmthyr <- dimstat[3]
nlead  <- dimstat[4]

# Select first lead month
stat_ESPall_lead1 <- stat_all_ESPall [ , , , 1]
stat_revESP_lead1 <- stat_all_revESP [ , , , 1]

# Number of cells and ini months with two valid stats
indval <- which (!is.na(stat_ESPall_lead1) & !is.na(stat_revESP_lead1))
nval <- length(indval)
print (paste (nval, "cells and months with valid ESPall and revESP for lead 0", sep = " "))

thrsign <- 0.306
# Select grid cells and ini months with stat greater than threshold
#    and greater than opponent
indall <- which (stat_ESPall_lead1 > thrsign & 
                 stat_ESPall_lead1 > stat_revESP_lead1 &
                !is.na(stat_revESP_lead1), arr.ind = T)
print ("Lead 0")
dimindall <- dim(indall)
str <- format (100.0 * dimindall[1] / nval, digits = 3)
print (paste (str, 
    "% of cells and months with ESPall > revESP and ESPall significant", sep = " ")) 

# How frequently does the order of ESPall and revESP switch?
print ("Percentage of these cases that for longer leads switched order and revESP significant")
for (ilead in (2:nlead)) {
   stat_ESPall_lead <- stat_all_ESPall [ , , , ilead]
   stat_revESP_lead <- stat_all_revESP [ , , , ilead]
   indswall <- which (stat_revESP_lead[indall] > thrsign &
                      stat_revESP_lead[indall] > stat_ESPall_lead[indall])
   str <- format (100.0 * length (indswall) / dimindall[1], digits = 2)
   print (paste ("Lead", ilead, "   ", str, sep = " "))
}
                                  
indrev <- which (stat_revESP_lead1 > thrsign & 
                 stat_revESP_lead1 > stat_ESPall_lead1 &
                 !is.na(stat_ESPall_lead1), arr.ind = T)
print ("Lead 0")
dimindrev <- dim(indrev)
str <- format (100.0 * dimindrev[1] / nval, digits = 3)
print (paste (str, 
    "% of cells and months with revESP > ESPall and revESP significant", sep = " ")) 
               
# How frequently does the order of ESPall and revESP switch?
print ("Percentage of these cases that for longer leads switched order and ESPall significant")
for (ilead in (2:nlead)) {
   stat_ESPall_lead <- stat_all_ESPall [ , , , ilead]
   stat_revESP_lead <- stat_all_revESP [ , , , ilead]
   indswrev <- which (stat_ESPall_lead[indrev] > thrsign &
                      stat_ESPall_lead[indrev] > stat_revESP_lead[indrev])
   str <- format (100.0 * length (indswrev) / dimindrev[1], digits = 2)
   print (paste ("Lead", ilead, "   ", str, sep = " "))
}

fileout <- paste (dirlustre, "verif_seas/figures/enddomforc.png", sep = "")
png (file = fileout, width = 4500, height = 4000, pointsize = 12, bg = "white")
# Set parameters for the plot
par (mfrow=c(4,3), oma=c(5,5,5,5), mar=c(5,5,10,20), cex.main=5,
     cex.axis=5, cex.lab=2.5, xpd=NA, las=1, lheight = 1.2, mgp = c(3,3,0))

# Compute the last lead month when ESPrev > ESPall and ESPrev significant
last_rev_best <- array(NA, dim = c(nlat, nlon, nmthyr))

lon <- seq(-24.75, 39.75, length.out = 130)
lat <- seq( 33.25, 71.75, length.out =  78)
nbreaks = 5
breaks_bar <- seq( -1.5, nbreaks - 2.5, length.out =  nbreaks)
colhere <- c( brewer.pal(nbreaks - 1, "YlOrRd"))

for (mth  in (1:nmthyr)) {
for (ilat in (1:nlat))   {
for (ilon in (1:nlon))   {
	
   stat_ESPall_here <- stat_all_ESPall [ilat, ilon, mth, ]
   stat_revESP_here <- stat_all_revESP [ilat, ilon, mth, ]
   if (sum(is.na(stat_ESPall_here)) > 0 |  sum(is.na(stat_revESP_here)) > 0) next 
	   
   for (ilead in (1:nlead)) {
	   
	  statall <- stat_ESPall_here[ilead]
	  statrev <- stat_revESP_here[ilead]
	  
	  lrb_here <- nlead - 1
	   
	  if (statall > statrev | statrev < thrsign) {
		 lrb_here <- ilead - 2
		 break
	  }
	  
	}
	
	last_rev_best [ilat, ilon, mth] <- lrb_here
	
}
}

title <- paste ("Last lead month when FORC > IC, ini ", mthname[mth], sep = "") 		
image.plot (lon, lat, aperm (last_rev_best[ , , mth]), zlim = c (0,0.05),
            xlab = "", breaks = breaks_bar, col = colhere,
            smallplot = c (.87,.9,0.05,0.9), ylab = "",
            lab.breaks = c (" ", format (breaks_bar[2:nbreaks], digits = 1)), 
            oldstyle = F, main = title)
map ("world", add = T)

}

dev.off()
                                 
stop ("check")
                     

 
