# Dit programma maakt kaartjes van de trends en de 
#    correlatiecoëfficiënt tussen de betreffende variabele en de tijd.
# Dit wordt zowel voor de waarnemingen als voor de hindcasts
#    (voor 7 verschillende lead maanden) gedaan.
# Is tot nog toe alleen voor temperatuur (varname ="airtemp") gebruikt 

rm(list=ls())	#remove all the variables from the workspace

library (SpecsVerification)
library (ncdf4)
library (fields)
library (verification)
library (RColorBrewer)
library(maps)

library(devtools)
find_rtools()

#devtools::install_github("MeteoSwiss/easyVerification")
library (easyVerification)

ls (pos = "package:easyVerification")

model = "seas15"
NWPsyst = "seas15"
domain = "EU"
varname = "airtemp"
nlead <- 7

mthname <- c("Jan", "Feb", "Mar", "Apr", "May", "June",
             "July", "Aug", "Sep", "Oct", "Nov", "Dec")
nmthyr <- length (mthname)

frsign <- array (NA, dim = c(nmthyr, nlead))
             
thr_sign_cc  = 0.306
epsthr = 0.001

dirlustre = "/lustre/backup/WUR/ESG/greue002/"
fig.dir <- paste (dirlustre, "verif_seas/figures/", varname, "/", sep = "")
system (paste ("mkdir -p ", fig.dir, sep = "")) 

dirstats <- paste (dirlustre, "verif_seas/statdata/", varname, 
                   "_detr/", model, "/", sep = "")

altvarname = varname
if (varname == "airtemp") altvarname = "tas"

# Read WFDEI file for getting lat and lon arrays                 
dirWFDEI <- paste (dirlustre, "GCM2VIC/WFDEI/version_Nov15/", 
                   altvarname, "/", sep = "")
fileWFDEI = "monthlymeans.nc"
     
ncobs <- nc_open( paste (dirWFDEI, fileWFDEI, sep = ""))
lat <- ncvar_get(ncobs, varid = "lat")
lon <- ncvar_get(ncobs, varid = "lon")
nlon <- length(lon)
lon = lon[2:nlon]
nc_close(ncobs)

for (ilead in (1:nlead)) {
	
   leadmth <- ilead - 1
                   
for (ifig in 1:4) {
	
   print (paste ("ifig = ", ifig, sep = ""))

   if (ifig == 1) {	
      load (file = paste (dirstats, "trend_obs_", varname, ".txt", sep = ""))
      dataset <- trend_obs_all
      figname = "obs_trend.png"
      titpart1 = "Trend in observed "
      titpart2 = ""
      phunit = " (˚C/yr)"
      breakpoints <- c (-0.1, -0.05, 0.0, 0.05, 0.1, 0.15, 0.2, 0.25)
      ncolors = 7
   }
   if (ifig == 2) {	
      minval <- -0.012
      maxval <- 0.072
      load (file = paste (dirstats, "trend_hind_", varname, ".txt", sep = ""))
      dataset <- trend_hind_all[ , , , ilead]
      dataset [which (dataset > maxval, arr.ind = T)] <- (maxval - epsthr)
      dataset [which (dataset < minval, arr.ind = T)] <- (minval + epsthr)
      figname <- paste ("hind_lead_", leadmth, "_trend.png", sep = "")
      titpart1 = "Trend in predicted "
      titpart2 <- paste ("lead", leadmth, sep = " ")
      phunit = " (˚C/yr)"
      ncolors = 7
      breakpoints <- seq(minval, maxval, length.out = ncolors + 1)
   }
   if (ifig == 3) {	
      load (file = paste (dirstats, "cc_obs_trend_", varname, ".txt", sep = ""))
      load (file = paste (dirstats, "pvalue_obs_trend_", varname, ".txt", sep = ""))
      dataset <- corr_coeff_obs_trend
      pvalues <- pvalue_cc_obs_trend
      dataset [which (pvalues > 0.05, arr.ind = T)] <- (thr_sign_cc - epsthr)
      figname = "cc_obs_trend.png"
      titpart1 = "R of observed "
      titpart2 = ""
      phunit = ""
      breakpoints <- c (0.2, thr_sign_cc, 0.4, 0.55, 0.7, 0.85, 1.0)
      ncolors = 6
   }
   if (ifig == 4) {	
      load (file = paste (dirstats, "cc_hind_trend_", varname, ".txt", sep = ""))
      load (file = paste (dirstats, "pvalue_hind_trend_", varname, ".txt", sep = ""))
      dataset <- corr_coeff_hind_trend[ , , , ilead]
      pvalues <- pvalue_cc_hind_trend[ , , , ilead]
      dataset [which (pvalues > 0.05, arr.ind = T)] <- (thr_sign_cc - epsthr)
      figname <- paste ("cc_hind_lead_", leadmth, "_trend.png", sep = "")
      titpart1 = "R of predicted "
      titpart2 <- paste ("lead", leadmth, sep = " ")
      phunit = ""
      breakpoints <- c (0.2, thr_sign_cc, 0.4, 0.55, 0.7, 0.85, 1.0)
      ncolors = 6
   }

   png (file = paste (fig.dir, figname, sep=""), 
                      width = 4500, height = 4000, pointsize =12, 
                      bg = "white")

   # Set parameters for the plot
   # oma determines size of margins
   # mar also (what is the difference with oma?)
   # cex.main: the magnification to be used for main titles 
   #           relative to the current setting of cex.
   # xpd determines clipping
   # las = 1: all axis labels horizontal
   # lheight determines space between lines of text
   # mgp determines space between axes, its labels etc. ?
   # zlim: the minimum and maximum z values for which colors should be plotted
   # smallplot gaat over de positie van de kleurenschaal
   par (mfrow = c(4,3), oma = c(5,5,5,5), 
        mar = c(5,5,10,20), cex.main = 5, cex.axis = 5, cex.lab = 2.5,
        xpd = NA, las = 1, lheight = 1.2, mgp = c(3,3,0))

   for (mth in 1:nmthyr) {

      print (mthname[mth])
	                       
      data_mth <- aperm(dataset[ , , mth])
      title <- paste (titpart1, mthname[mth], " ",varname ,
                      "1981-2010 ", titpart2, " ", phunit, sep="")

      # lab.breaks zorgt ervoor dat de labels in de kleurenbar
      #    bij de kleurenovergangen staan
      image.plot (lon, lat, data_mth, 
                  xlab = "", breaks = breakpoints, 
                  col = brewer.pal (ncolors, "YlOrRd"), 
                  smallplot = c (0.87, 0.9, 0.05, 0.9), ylab = "",
                  lab.breaks = format (breakpoints, digits = 2), 
                  oldstyle = F, main = title)

      map ("world", add = T)

      if (ifig == 3 | ifig == 4) {      
          # Bepaal het percentage cellen met een significante trend
	      ncellsign <- sum(!is.na(data_mth) & data_mth > thr_sign_cc)
	      ncellval  <- sum(!is.na(data_mth))
	      if (ncellval > 0) {frsignhere = ncellsign / ncellval * 100.0
          } else {frsignhere = NA}
          text (-1, 67.5, labels = c (paste( "Cells signif. R: ",
                                    round (frsignhere), "%")), cex = 5)
          if (ifig == 4) frsign[mth, ilead] = frsignhere
       }

    
   }   # Einde loop over de maanden

   dev.off ()

}   # Einde van de loop over de figuren

}   # Einde van de loop over de lead months

mthmeanfrsign <- apply (frsign, 1, mean)
print ("Significant R (%) in hindcasts across all lead months for 12 target months:")
print (mthmeanfrsign)
mthmeanfrsign <- apply (frsign[ , 2:nlead], 1, mean)
print ("Significant R (%) in hindcasts across all lead months 1-6 for 12 target months:")
print (mthmeanfrsign)

stop ("hhh")
    
  
   
