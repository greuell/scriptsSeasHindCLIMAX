IntToStrWith0 <- function (int_in, n_pos) {

   # This function converts the integer int_in to a string str_out.
   # The length of str_out is n_pos.
   # If the integer has int_pos positions,
   #    it fills the final int_pos positions of the string
   # The other positions of the string are filled with 0
   
   if (one_sided) {
      factor <- 0.5
   } else {
      factor <- 1.0
   }

   cc <- 0 
   dStep <- 0.0001
   pValue <- 0.5
 
   # The equation for the t value is from 
   #    http://www.sthda.com/english/wiki/correlation-test-between-two-variables-in-r 
   # df are the degrees of freedom
   # Equation for p-value is from 
   #    https://stackoverflow.com/questions/46186115/calculating-p-values-for-given-t-value-in-r
   # and has been checked with a table
   
   while(pValue > pThres) {
      cc <- cc + dStep
      tValue <- cc * sqrt (n - 2) / sqrt (1 - cc^2)
      df <- n - 2
      pValue <- factor * (1 - pt(q = abs(tValue), df = df))*2
   }
   
   return (cc)
   
}
   
