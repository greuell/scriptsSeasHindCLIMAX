ccAtPValue <- function (n, pThres, one_sided = T) {

   # The output of the function is a threshold correlation coefficient (Rt).
   #    For a one-sided test, the chance is pThres that Rt is exceeded
   #       in the case of the null-hypothesis (no correlation)
   #    For a two-sided test, the chance is pThres that Rt is exceeded
   #       or that R is less than -Rt
   #       in the case of the null-hypothesis (no correlation)
   #    Hence, in the second case Rt will be greater then in the first case
   #    Also, ccAtPValue (n, pThres, one_sided) = ccAtPValue (n, 2 * pThres, two_sided)
   
   if (one_sided) {
      factor <- 0.5
   } else {
      factor <- 1.0
   }

   cc <- 0 
   dStep <- 0.0001
   pValue <- 0.5
 
   # The equation for the t value is from 
   #    http://www.sthda.com/english/wiki/correlation-test-between-two-variables-in-r 
   # df are the degrees of freedom
   # Equation for p-value is from 
   #    https://stackoverflow.com/questions/46186115/calculating-p-values-for-given-t-value-in-r
   # and has been checked with a table
   
   while(pValue > pThres) {
      cc <- cc + dStep
      tValue <- cc * sqrt (n - 2) / sqrt (1 - cc^2)
      df <- n - 2
      pValue <- factor * (1 - pt(q = abs(tValue), df = df))*2
   }
   
   return (cc)
   
}
   
